import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';


import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/number_ball.dart';
import '../../../core/widgets/primary_button.dart';
import '../../generator/domain/lotto_tip.dart';
import '../../generator/provider/lotto_app_state.dart';
import 'westlotto_submission_screen.dart';

class MyTipsScreen extends StatefulWidget {
  const MyTipsScreen({super.key});

  @override
  State<MyTipsScreen> createState() => _MyTipsScreenState();
}

class _MyTipsScreenState extends State<MyTipsScreen> {
  final TextEditingController _searchController = TextEditingController();

  int _filterIndex = 0;
  String _searchText = '';
  Set<String> _selectedTipIds = {};
  bool _selectionMode = false;

  @override
  void initState() {
    super.initState();
    _searchController.addListener(() {
      if (!mounted) return;
      setState(() {
        _searchText = _searchController.text.trim();
      });
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _showMessage(String message) async {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  List<LottoTip> _resolveTips(LottoAppState state) {
    List<LottoTip> base;
    switch (_filterIndex) {
      case 1:
        base = state.favoriteTips;
        break;
      case 2:
        base = state.regularTips;
        break;
      default:
        base = state.savedTips;
    }

    if (_searchText.isEmpty) return base;

    final query = _searchText.toLowerCase();
    return base.where((tip) {
      final numbersText = tip.numbers.join(' ');
      final superText = tip.superNumber?.toString() ?? '';
      final sourceText = tip.source.toLowerCase();
      final dateText = _formatDateTime(tip.createdAt).toLowerCase();

      return numbersText.contains(query) ||
          superText.contains(query) ||
          sourceText.contains(query) ||
          dateText.contains(query);
    }).toList();
  }

  List<LottoTip> _selectedTipsFromState(LottoAppState state) {
    return state.savedTips
        .where((tip) => _selectedTipIds.contains(tip.id))
        .toList();
  }

  void _toggleSelection(LottoTip tip) {
    setState(() {
      _selectionMode = true;

      if (_selectedTipIds.contains(tip.id)) {
        _selectedTipIds.remove(tip.id);
      } else {
        _selectedTipIds.add(tip.id);
      }

      if (_selectedTipIds.isEmpty) {
        _selectionMode = false;
      }
    });
  }

  void _clearSelection() {
    setState(() {
      _selectedTipIds.clear();
      _selectionMode = false;
    });
  }

  void _selectAll(List<LottoTip> tips) {
    setState(() {
      _selectionMode = true;
      _selectedTipIds = tips.map((e) => e.id).toSet();
    });
  }

  Future<void> _copyTip(LottoTip tip) async {
    final text = tip.superNumber == null
        ? tip.numbers.join(', ')
        : '${tip.numbers.join(', ')} | SZ: ${tip.superNumber}';

    await Clipboard.setData(ClipboardData(text: text));
    await _showMessage('Tipp wurde kopiert.');
  }

  Future<void> _copySelected() async {
    final state = context.read<LottoAppState>();
    final tips = _selectedTipsFromState(state);

    if (tips.isEmpty) {
      await _showMessage('Keine Tipps ausgewählt.');
      return;
    }

    final text = tips
        .asMap()
        .entries
        .map(
          (e) =>
      'Tipp ${e.key + 1}: ${e.value.numbers.join(', ')}${e.value.superNumber == null ? '' : ' | SZ: ${e.value.superNumber}'}',
    )
        .join('\n');

    await Clipboard.setData(ClipboardData(text: text));
    await _showMessage('Ausgewählte Tipps wurden kopiert.');
  }

  Future<void> _openWestlottoSubmission() async {
    final state = context.read<LottoAppState>();
    final tips = _selectedTipsFromState(state);

    if (tips.isEmpty) {
      await _showMessage('Keine Tipps ausgewählt.');
      return;
    }

    if (!mounted) return;

    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => WestlottoSubmissionScreen(
          tips: tips,
          stakePerTip: 1.20,
        ),
      ),
    );
  }

  Future<void> _applyTip(LottoTip tip) async {
    context.read<LottoAppState>().setGeneratedNumbers(
      tip.numbers,
      superNumber: tip.superNumber,
    );
    await _showMessage('Tipp wurde in den Generator übernommen.');
  }

  Future<void> _toggleFavorite(LottoTip tip) async {
    await context.read<LottoAppState>().toggleTipFavorite(tip.id);
    await _showMessage(
      tip.isFavorite ? 'Favorit entfernt.' : 'Als Favorit gespeichert.',
    );
  }

  Future<void> _deleteTip(LottoTip tip) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Tipp löschen'),
        content: Text(
          'Soll der Tipp ${tip.numbers.join(", ")} wirklich gelöscht werden?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Abbrechen'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Löschen'),
          ),
        ],
      ),
    ) ??
        false;

    if (!confirmed) return;

    await context.read<LottoAppState>().removeTip(tip.id);
    _selectedTipIds.remove(tip.id);

    if (_selectedTipIds.isEmpty) {
      _selectionMode = false;
    }

    await _showMessage('Tipp wurde gelöscht.');

    if (mounted) {
      setState(() {});
    }
  }

  Future<void> _deleteSelected() async {
    if (_selectedTipIds.isEmpty) {
      await _showMessage('Keine Tipps ausgewählt.');
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Auswahl löschen'),
        content: Text(
          'Sollen ${_selectedTipIds.length} ausgewählte Tipps wirklich gelöscht werden?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Abbrechen'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Löschen'),
          ),
        ],
      ),
    ) ??
        false;

    if (!confirmed) return;

    final state = context.read<LottoAppState>();
    final ids = _selectedTipIds.toList();

    for (final id in ids) {
      await state.removeTip(id);
    }

    _clearSelection();
    await _showMessage('Ausgewählte Tipps gelöscht.');
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();
    final filteredTips = _resolveTips(state);
    final favoriteCount = state.favoriteTips.length;
    final totalCount = state.savedTips.length;
    final regularCount = state.regularTips.length;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: _selectionMode
            ? Text('${_selectedTipIds.length} ausgewählt')
            : const Text('Gespeicherte Tipps Pro'),
        backgroundColor: AppColors.background,
        elevation: 0,
        foregroundColor: AppColors.textPrimary,
        actions: [
          if (_selectionMode)
            IconButton(
              tooltip: 'Auswahl beenden',
              onPressed: _clearSelection,
              icon: const Icon(Icons.close_rounded),
            ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: _MetricTile(
                          title: 'Gesamt',
                          value: '$totalCount',
                          icon: Icons.bookmarks_rounded,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _MetricTile(
                          title: 'Favoriten',
                          value: '$favoriteCount',
                          icon: Icons.star_rounded,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _MetricTile(
                          title: 'Normal',
                          value: '$regularCount',
                          icon: Icons.grid_view_rounded,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: TextField(
                      controller: _searchController,
                      decoration: const InputDecoration(
                        hintText: 'Suche nach Zahlen, Superzahl, Quelle oder Datum',
                        prefixIcon: Icon(Icons.search_rounded),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 14,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _FilterTabs(
                    index: _filterIndex,
                    onChanged: (value) {
                      setState(() {
                        _filterIndex = value;
                      });
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            if (_selectionMode)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: filteredTips.isEmpty
                            ? null
                            : () => _selectAll(filteredTips),
                        icon: const Icon(Icons.select_all_rounded),
                        label: const Text('Alle'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _selectedTipIds.isEmpty ? null : _copySelected,
                        icon: const Icon(Icons.copy_rounded),
                        label: const Text('Kopieren'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _selectedTipIds.isEmpty ? null : _deleteSelected,
                        icon: const Icon(Icons.delete_outline_rounded),
                        label: const Text('Löschen'),
                      ),
                    ),
                  ],
                ),
              ),
            if (_selectionMode)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: SizedBox(
                  width: double.infinity,
                  child: PrimaryButton(
                    label: 'Zur WestLotto Abgabe',
                    icon: Icons.send_rounded,
                    onPressed: _selectedTipIds.isEmpty
                        ? null
                        : _openWestlottoSubmission,
                  ),
                ),
              ),
            Expanded(
              child: filteredTips.isEmpty
                  ? _EmptyTipsState(
                hasAnyTips: state.savedTips.isNotEmpty,
              )
                  : ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 18),
                itemCount: filteredTips.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, index) {
                  final tip = filteredTips[index];
                  final hitCount = state.hitCountForTip(tip.id);
                  final matchedNumbers = state.matchedNumbersForTip(tip.id);

                  return _TipCard(
                    tip: tip,
                    hitCount: hitCount,
                    matchedNumbers: matchedNumbers,
                    isSelected: _selectedTipIds.contains(tip.id),
                    selectionMode: _selectionMode,
                    onSelect: () => _toggleSelection(tip),
                    onCopy: () => _copyTip(tip),
                    onApply: () => _applyTip(tip),
                    onDelete: () => _deleteTip(tip),
                    onToggleFavorite: state.gate.canUseFavorites
                        ? () => _toggleFavorite(tip)
                        : null,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatDateTime(DateTime value) {
    final day = value.day.toString().padLeft(2, '0');
    final month = value.month.toString().padLeft(2, '0');
    final hour = value.hour.toString().padLeft(2, '0');
    final minute = value.minute.toString().padLeft(2, '0');
    return '$day.$month.${value.year} • $hour:$minute';
  }
}

class _MetricTile extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _MetricTile({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowLight,
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: AppColors.primary),
          const SizedBox(height: 10),
          Text(
            value,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            title,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

class _FilterTabs extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;

  const _FilterTabs({
    required this.index,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          _FilterButton(
            label: 'Alle',
            selected: index == 0,
            onTap: () => onChanged(0),
          ),
          _FilterButton(
            label: 'Favoriten',
            selected: index == 1,
            onTap: () => onChanged(1),
          ),
          _FilterButton(
            label: 'Normal',
            selected: index == 2,
            onTap: () => onChanged(2),
          ),
        ],
      ),
    );
  }
}

class _FilterButton extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _FilterButton({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            gradient: selected
                ? const LinearGradient(
              colors: [AppColors.primary, AppColors.primaryDark],
            )
                : null,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Center(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: selected ? Colors.white : AppColors.textSecondary,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _TipCard extends StatelessWidget {
  final LottoTip tip;
  final int hitCount;
  final List<int> matchedNumbers;
  final bool isSelected;
  final bool selectionMode;
  final VoidCallback onSelect;
  final VoidCallback onCopy;
  final VoidCallback onApply;
  final VoidCallback onDelete;
  final VoidCallback? onToggleFavorite;

  const _TipCard({
    required this.tip,
    required this.hitCount,
    required this.matchedNumbers,
    required this.isSelected,
    required this.selectionMode,
    required this.onSelect,
    required this.onCopy,
    required this.onApply,
    required this.onDelete,
    required this.onToggleFavorite,
  });

  @override
  Widget build(BuildContext context) {
    final sourceLabel = _sourceLabel(tip.source);

    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onLongPress: onSelect,
      onTap: selectionMode ? onSelect : null,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isSelected
              ? AppColors.primary.withOpacity(0.08)
              : AppColors.surface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: isSelected ? AppColors.primary : AppColors.border,
          ),
          boxShadow: const [
            BoxShadow(
              color: AppColors.shadowLight,
              blurRadius: 16,
              offset: Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                if (selectionMode)
                  Checkbox(
                    value: isSelected,
                    onChanged: (_) => onSelect(),
                  ),
                Expanded(
                  child: Text(
                    sourceLabel,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ),
                if (onToggleFavorite != null)
                  IconButton(
                    onPressed: onToggleFavorite,
                    icon: Icon(
                      tip.isFavorite
                          ? Icons.star_rounded
                          : Icons.star_border_rounded,
                      color: tip.isFavorite
                          ? Colors.amber
                          : AppColors.textSecondary,
                    ),
                  ),
              ],
            ),
            Text(
              _formatDateTime(tip.createdAt),
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: AppColors.textSecondary,
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: tip.numbers.map((n) => NumberBall(number: n)).toList(),
            ),
            if (tip.superNumber != null) ...[
              const SizedBox(height: 10),
              Text(
                'Superzahl: ${tip.superNumber}',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: Colors.orange,
                ),
              ),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                _InfoBadge(
                  icon: Icons.analytics_rounded,
                  label: '$hitCount Richtige',
                ),
                const SizedBox(width: 8),
                _InfoBadge(
                  icon: Icons.touch_app_rounded,
                  label: matchedNumbers.isEmpty
                      ? 'Keine Treffer'
                      : matchedNumbers.join(', '),
                ),
              ],
            ),
            if (!selectionMode) ...[
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: PrimaryButton(
                      label: 'Übernehmen',
                      icon: Icons.playlist_add_check_circle_rounded,
                      onPressed: onApply,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: onCopy,
                      icon: const Icon(Icons.copy_rounded),
                      label: const Text('Kopieren'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: onDelete,
                  icon: const Icon(Icons.delete_outline_rounded),
                  label: const Text('Löschen'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _sourceLabel(String raw) {
    switch (raw) {
      case 'manual':
        return 'Manuell gespeichert';
      case 'analysis':
        return 'Analyse Tipp';
      default:
        if (raw.startsWith('voll_')) {
          return 'Vollsystem ${raw.replaceFirst('voll_', '')}';
        }
        if (raw.startsWith('vew_')) {
          return 'VEW ${raw.replaceFirst('vew_', '')}';
        }
        return raw;
    }
  }

  String _formatDateTime(DateTime value) {
    final day = value.day.toString().padLeft(2, '0');
    final month = value.month.toString().padLeft(2, '0');
    final hour = value.hour.toString().padLeft(2, '0');
    final minute = value.minute.toString().padLeft(2, '0');
    return '$day.$month.${value.year} • $hour:$minute';
  }
}

class _InfoBadge extends StatelessWidget {
  final IconData icon;
  final String label;

  const _InfoBadge({
    required this.icon,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        decoration: BoxDecoration(
          color: AppColors.surfaceSoft,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Icon(icon, size: 16, color: AppColors.primary),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                label,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyTipsState extends StatelessWidget {
  final bool hasAnyTips;

  const _EmptyTipsState({
    required this.hasAnyTips,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.inbox_rounded,
                size: 48,
                color: AppColors.primary,
              ),
              const SizedBox(height: 14),
              Text(
                hasAnyTips
                    ? 'Kein Treffer für deinen aktuellen Filter.'
                    : 'Noch keine gespeicherten Tipps vorhanden.',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                hasAnyTips
                    ? 'Passe Suche oder Filter an.'
                    : 'Speichere im Generator einen Tipp, dann erscheint er hier.',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textSecondary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
