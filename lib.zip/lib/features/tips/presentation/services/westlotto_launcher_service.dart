import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

class WestlottoOpenResult {
  final bool success;
  final String message;

  const WestlottoOpenResult({
    required this.success,
    required this.message,
  });
}

class WestlottoLauncherService {
  static const String _url = 'https://www.westlotto.de/lotto6aus49';

  static Future<WestlottoOpenResult> open(String text) async {
    await Clipboard.setData(ClipboardData(text: text));

    final uri = Uri.parse(_url);
    final opened = await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    );

    if (opened) {
      return const WestlottoOpenResult(
        success: true,
        message:
        'WestLotto wurde geöffnet. Die Abgabe ist in der Zwischenablage.',
      );
    }

    return const WestlottoOpenResult(
      success: false,
      message:
      'WestLotto konnte nicht geöffnet werden. Abgabe wurde kopiert.',
    );
  }
}