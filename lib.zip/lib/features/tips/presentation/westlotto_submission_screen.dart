import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/number_ball.dart';
import '../../generator/domain/lotto_tip.dart';
import 'package:lotto_davenport/features/tips/presentation/services/westlotto_launcher_service.dart';

class WestlottoSubmissionScreen extends StatefulWidget {
  final List<LottoTip> tips;
  final double stakePerTip;

  const WestlottoSubmissionScreen({
    super.key,
    required this.tips,
    this.stakePerTip = 1.20,
  });

  @override
  State<WestlottoSubmissionScreen> createState() =>
      _WestlottoSubmissionScreenState();
}

class _WestlottoSubmissionScreenState extends State<WestlottoSubmissionScreen> {
  late int _activeTipIndex;
  late List<List<int>> _editableTips;
  late List<int?> _editableSuperNumbers;

  @override
  void initState() {
    super.initState();
    _activeTipIndex = 0;
    _editableTips = widget.tips
        .map((tip) => List<int>.from(tip.numbers)..sort())
        .toList();
    _editableSuperNumbers = widget.tips
        .map((tip) => tip.superNumber)
        .toList();
  }

  List<int> get _activeNumbers => _editableTips[_activeTipIndex];
  int? get _activeSuperNumber => _editableSuperNumbers[_activeTipIndex];

  void _toggleMainNumber(int number) {
    final current = List<int>.from(_editableTips[_activeTipIndex]);

    if (current.contains(number)) {
      current.remove(number);
    } else {
      if (current.length >= 6) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Pro Tipp sind maximal 6 Zahlen möglich.')),
        );
        return;
      }
      current.add(number);
    }

    current.sort();
    setState(() {
      _editableTips[_activeTipIndex] = current;
    });
  }

  void _setSuperNumber(int number) {
    setState(() {
      _editableSuperNumbers[_activeTipIndex] =
      _editableSuperNumbers[_activeTipIndex] == number ? null : number;
    });
  }

  String _buildWestlottoText() {
    final buffer = StringBuffer();
    final totalStake = _editableTips.length * widget.stakePerTip;
    buffer.writeln('WestLotto Abgabe');
    buffer.writeln('Anzahl Tipps: ${_editableTips.length}');
    buffer.writeln('Einsatz pro Tipp: ${widget.stakePerTip.toStringAsFixed(2).replaceAll('.', ',')} €');
    buffer.writeln('Gesamt-Einsatz: ${totalStake.toStringAsFixed(2).replaceAll('.', ',')} €');
    buffer.writeln('');

    for (int i = 0; i < _editableTips.length; i++) {
      final numbers = List<int>.from(_editableTips[i])..sort();
      final superNumber = _editableSuperNumbers[i];
      buffer.writeln(
        'Tipp ${i + 1}: ${numbers.join(', ')}${superNumber == null ? '' : ' | SZ: $superNumber'}',
      );
    }

    return buffer.toString().trimRight();
  }

  Future<void> _copyAll() async {
    await Clipboard.setData(
      ClipboardData(text: _buildWestlottoText()),
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('WestLotto Abgabe wurde kopiert.')),
    );
  }

  Future<void> _copyCurrentTip() async {
    final numbers = List<int>.from(_activeNumbers)..sort();
    final superNumber = _activeSuperNumber;
    final text = superNumber == null
        ? numbers.join(', ')
        : '${numbers.join(', ')} | SZ: $superNumber';

    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Tipp ${_activeTipIndex + 1} wurde kopiert.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final exportText = _buildWestlottoText();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('WestLotto Spielschein'),
        backgroundColor: AppColors.background,
        elevation: 0,
        foregroundColor: AppColors.textPrimary,
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: _HeaderCard(
                tipCount: _editableTips.length,
                activeTipIndex: _activeTipIndex,
                selectedCount: _activeNumbers.length,
                superNumber: _activeSuperNumber,
                stakePerTip: widget.stakePerTip,
              ),
            ),
            const SizedBox(height: 12),
            _TipSelectorBar(
              tipCount: _editableTips.length,
              activeTipIndex: _activeTipIndex,
              onSelected: (index) {
                setState(() {
                  _activeTipIndex = index;
                });
              },
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 18),
                children: [
                  _PanelCard(
                    title: 'Spielschein Zahlenfeld',
                    subtitle:
                    'Tippe auf die Zahlen 1–49. Pro Tipp sind genau 6 Zahlen vorgesehen.',
                    child: _MainNumberGrid(
                      selectedNumbers: _activeNumbers,
                      onTap: _toggleMainNumber,
                    ),
                  ),
                  const SizedBox(height: 14),
                  _PanelCard(
                    title: 'Superzahl',
                    subtitle:
                    'Die empfohlene Superzahl kann direkt übernommen oder manuell angepasst werden.',
                    child: _SuperNumberRow(
                      selectedNumber: _activeSuperNumber,
                      onTap: _setSuperNumber,
                    ),
                  ),
                  const SizedBox(height: 14),
                  _PanelCard(
                    title: 'Aktiver Tipp',
                    subtitle:
                    'Vorschau des aktuell gewählten Tipps in Abgabe-Reihenfolge.',
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: _activeNumbers
                              .map((n) => NumberBall(number: n))
                              .toList(),
                        ),
                        const SizedBox(height: 12),
                        _InfoLine(
                          label: 'Superzahl',
                          value: _activeSuperNumber?.toString() ?? '-',
                        ),
                        const SizedBox(height: 8),
                        _InfoLine(
                          label: 'Status',
                          value: _activeNumbers.length == 6
                              ? 'Spielbereit'
                              : '${_activeNumbers.length}/6 Zahlen gewählt',
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _PanelCard(
                    title: 'Abgabe Text',
                    subtitle:
                    'Diese kompakte Darstellung kannst du direkt für Übergabe oder Prüfung verwenden.',
                    child: SelectableText(
                      exportText,
                      style: const TextStyle(
                        fontSize: 12,
                        height: 1.45,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(Icons.arrow_back_rounded),
                          label: const Text('Zurück'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _copyCurrentTip,
                          icon: const Icon(Icons.copy_rounded),
                          label: const Text('Aktiven Tipp kopieren'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _copyAll,
                          icon: const Icon(Icons.copy_all_rounded),
                          label: const Text('Gesamte Abgabe kopieren'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () async {
                            final text = _buildWestlottoText();
                            final result =
                            await WestlottoLauncherService.open(text);
                            if (!mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text(result.message)),
                            );
                          },
                          icon: const Icon(Icons.open_in_new_rounded),
                          label: const Text('Bei WestLotto öffnen'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HeaderCard extends StatelessWidget {
  final int tipCount;
  final int activeTipIndex;
  final int selectedCount;
  final int? superNumber;
  final double stakePerTip;

  const _HeaderCard({
    required this.tipCount,
    required this.activeTipIndex,
    required this.selectedCount,
    required this.superNumber,
    required this.stakePerTip,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowLight,
            blurRadius: 16,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'WestLotto Abgabe-Vorschau',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            '$tipCount Tipp(s) geladen • Aktiver Tipp ${activeTipIndex + 1}',
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: AppColors.textSecondary,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _MiniMetric(
                  title: 'Zahlen',
                  value: '$selectedCount / 6',
                  icon: Icons.pin_outlined,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _MiniMetric(
                  title: 'Superzahl',
                  value: superNumber?.toString() ?? '-',
                  icon: Icons.looks_one_rounded,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _MiniMetric(
                  title: 'Einsatz',
                  value: '${stakePerTip.toStringAsFixed(2).replaceAll('.', ',')} €',
                  icon: Icons.euro_rounded,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MiniMetric extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _MiniMetric({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surfaceSoft,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: AppColors.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TipSelectorBar extends StatelessWidget {
  final int tipCount;
  final int activeTipIndex;
  final ValueChanged<int> onSelected;

  const _TipSelectorBar({
    required this.tipCount,
    required this.activeTipIndex,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        scrollDirection: Axis.horizontal,
        itemCount: tipCount,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final selected = index == activeTipIndex;
          return InkWell(
            borderRadius: BorderRadius.circular(999),
            onTap: () => onSelected(index),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                gradient: selected
                    ? const LinearGradient(
                  colors: [AppColors.primary, AppColors.primaryDark],
                )
                    : null,
                color: selected ? null : AppColors.surface,
                borderRadius: BorderRadius.circular(999),
                border: Border.all(
                  color: selected ? AppColors.primaryDark : AppColors.border,
                ),
              ),
              alignment: Alignment.center,
              child: Text(
                'Tipp ${index + 1}',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: selected ? Colors.white : AppColors.textSecondary,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _PanelCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;

  const _PanelCard({
    required this.title,
    required this.subtitle,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowLight,
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            style: const TextStyle(
              fontSize: 12,
              height: 1.35,
              fontWeight: FontWeight.w600,
              color: AppColors.textSecondary,
            ),
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class _MainNumberGrid extends StatelessWidget {
  final List<int> selectedNumbers;
  final ValueChanged<int> onTap;

  const _MainNumberGrid({
    required this.selectedNumbers,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(49, (index) {
        final number = index + 1;
        final selected = selectedNumbers.contains(number);

        return InkWell(
          borderRadius: BorderRadius.circular(999),
          onTap: () => onTap(number),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            width: 42,
            height: 42,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: selected
                  ? const LinearGradient(
                colors: [AppColors.primary, AppColors.primaryDark],
              )
                  : null,
              color: selected ? null : Colors.white,
              border: Border.all(
                color: selected ? AppColors.primaryDark : AppColors.border,
              ),
              boxShadow: selected
                  ? const [
                BoxShadow(
                  color: AppColors.shadowMedium,
                  blurRadius: 8,
                  offset: Offset(0, 4),
                ),
              ]
                  : null,
            ),
            child: Text(
              '$number',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: selected ? Colors.white : AppColors.textPrimary,
              ),
            ),
          ),
        );
      }),
    );
  }
}

class _SuperNumberRow extends StatelessWidget {
  final int? selectedNumber;
  final ValueChanged<int> onTap;

  const _SuperNumberRow({
    required this.selectedNumber,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(10, (index) {
        final selected = selectedNumber == index;

        return InkWell(
          borderRadius: BorderRadius.circular(999),
          onTap: () => onTap(index),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            width: 44,
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: selected ? Colors.orange : Colors.white,
              border: Border.all(
                color: selected ? Colors.orange : AppColors.border,
              ),
            ),
            child: Text(
              '$index',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w900,
                color: selected ? Colors.white : AppColors.textPrimary,
              ),
            ),
          ),
        );
      }),
    );
  }
}

class _InfoLine extends StatelessWidget {
  final String label;
  final String value;

  const _InfoLine({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 90,
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: AppColors.textSecondary,
            ),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
        ),
      ],
    );
  }
}
