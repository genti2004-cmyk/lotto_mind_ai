import 'dart:math';

import '../../draws/domain/draw_result.dart';

class PredictionEngineResult {
  final List<int> primaryTip;
  final int? recommendedSuperNumber;
  final double overallScore;
  final double score3Plus;
  final List<PredictionCandidate> topCandidates;
  final List<String> reasons;

  const PredictionEngineResult({
    required this.primaryTip,
    required this.recommendedSuperNumber,
    required this.overallScore,
    required this.score3Plus,
    required this.topCandidates,
    required this.reasons,
  });

  factory PredictionEngineResult.empty() {
    return const PredictionEngineResult(
      primaryTip: [],
      recommendedSuperNumber: null,
      overallScore: 0,
      score3Plus: 0,
      topCandidates: [],
      reasons: ['Noch nicht genug Ziehungen für eine belastbare Prognose.'],
    );
  }
}

class PredictionCandidate {
  final List<int> tip;
  final double totalScore;
  final double score3Plus;
  final double pairScore;
  final double tripleScore;
  final double recencyScore;
  final double overdueScore;
  final double structureScore;
  final List<String> reasons;

  const PredictionCandidate({
    required this.tip,
    required this.totalScore,
    required this.score3Plus,
    required this.pairScore,
    required this.tripleScore,
    required this.recencyScore,
    required this.overdueScore,
    required this.structureScore,
    required this.reasons,
  });
}

class ProPredictionEngine {
  final Random _random;

  ProPredictionEngine({Random? random}) : _random = random ?? Random();

  PredictionEngineResult build({
    required List<DrawResult> draws,
    required String profileLabel,
    int candidateCount = 420,
  }) {
    final normalizedDraws = draws
        .map((d) => d.numbers.where((n) => n >= 1 && n <= 49).toSet().toList()..sort())
        .where((d) => d.length == 6)
        .toList();

    if (normalizedDraws.length < 12) {
      return PredictionEngineResult.empty();
    }

    final frequency = _buildFrequency(normalizedDraws);
    final recentWindow = min(26, normalizedDraws.length);
    final mediumWindow = min(52, normalizedDraws.length);
    final recencyFrequency = _buildRecencyFrequency(normalizedDraws, recentWindow: recentWindow);
    final mediumFrequency = _buildRecencyFrequency(normalizedDraws, recentWindow: mediumWindow);
    final lastSeen = _buildLastSeenIndex(normalizedDraws);
    final pairCounts = _buildPairCounts(normalizedDraws);
    final tripleCounts = _buildTripleCounts(normalizedDraws);
    final repeatHistogram = _buildRepeatHistogram(normalizedDraws);
    final superNumber = _buildSuperNumberRecommendation(draws);

    final ranking = _buildBaseRanking(
      freq: frequency,
      recency: recencyFrequency,
      medium: mediumFrequency,
      lastSeen: lastSeen,
      profileLabel: profileLabel,
    );

    final candidates = <PredictionCandidate>[];

    for (int i = 0; i < candidateCount; i++) {
      final tip = _buildCandidateTip(
        ranking: ranking,
        pairCounts: pairCounts,
        tripleCounts: tripleCounts,
        profileLabel: profileLabel,
      );

      candidates.add(
        _scoreTip(
          tip: tip,
          draws: normalizedDraws,
          pairCounts: pairCounts,
          tripleCounts: tripleCounts,
          freq: frequency,
          recency: recencyFrequency,
          medium: mediumFrequency,
          lastSeen: lastSeen,
          repeatHistogram: repeatHistogram,
        ),
      );
    }

    candidates.sort((a, b) => b.totalScore.compareTo(a.totalScore));

    final unique = <String, PredictionCandidate>{};
    for (final candidate in candidates) {
      unique.putIfAbsent(candidate.tip.join('-'), () => candidate);
      if (unique.length >= 24) break;
    }

    final topCandidates = unique.values.toList()..sort((a, b) => b.totalScore.compareTo(a.totalScore));

    if (topCandidates.isEmpty) {
      return PredictionEngineResult.empty();
    }

    final best = topCandidates.first;

    final reasons = <String>[
      'Beste Rücktest-Kombination aus 3+ Trefferpotenzial, Struktur und Wiederkehrmustern.',
      'Superzahl-Empfehlung gewichtet Häufigkeit, letzte Dynamik und Überfälligkeit.',
      ...best.reasons.take(4),
    ];

    return PredictionEngineResult(
      primaryTip: best.tip,
      recommendedSuperNumber: superNumber,
      overallScore: best.totalScore,
      score3Plus: best.score3Plus,
      topCandidates: topCandidates,
      reasons: reasons,
    );
  }

  Map<int, int> _buildFrequency(List<List<int>> draws) {
    final map = {for (int i = 1; i <= 49; i++) i: 0};
    for (final draw in draws) {
      for (final n in draw) {
        map[n] = (map[n] ?? 0) + 1;
      }
    }
    return map;
  }

  Map<int, int> _buildRecencyFrequency(List<List<int>> draws, {required int recentWindow}) {
    final map = {for (int i = 1; i <= 49; i++) i: 0};
    for (final draw in draws.take(recentWindow)) {
      for (final n in draw) {
        map[n] = (map[n] ?? 0) + 1;
      }
    }
    return map;
  }

  Map<int, int> _buildLastSeenIndex(List<List<int>> draws) {
    final map = <int, int>{};
    for (int number = 1; number <= 49; number++) {
      map[number] = draws.length + 99;
    }
    for (int i = 0; i < draws.length; i++) {
      for (final n in draws[i]) {
        map.putIfAbsent(n, () => i);
      }
    }
    return map;
  }

  Map<String, int> _buildPairCounts(List<List<int>> draws) {
    final map = <String, int>{};
    for (final draw in draws) {
      for (int i = 0; i < draw.length; i++) {
        for (int j = i + 1; j < draw.length; j++) {
          final key = '${draw[i]}-${draw[j]}';
          map[key] = (map[key] ?? 0) + 1;
        }
      }
    }
    return map;
  }

  Map<String, int> _buildTripleCounts(List<List<int>> draws) {
    final map = <String, int>{};
    for (final draw in draws) {
      for (int i = 0; i < draw.length; i++) {
        for (int j = i + 1; j < draw.length; j++) {
          for (int k = j + 1; k < draw.length; k++) {
            final key = '${draw[i]}-${draw[j]}-${draw[k]}';
            map[key] = (map[key] ?? 0) + 1;
          }
        }
      }
    }
    return map;
  }

  Map<int, int> _buildRepeatHistogram(List<List<int>> draws) {
    final hist = {for (int i = 0; i <= 6; i++) i: 0};
    for (int i = 1; i < draws.length; i++) {
      final prev = draws[i - 1].toSet();
      final curr = draws[i].toSet();
      final overlap = curr.where(prev.contains).length;
      hist[overlap] = (hist[overlap] ?? 0) + 1;
    }
    return hist;
  }

  int? _buildSuperNumberRecommendation(List<DrawResult> draws) {
    if (draws.isEmpty) return null;
    final totalCounts = {for (int i = 0; i <= 9; i++) i: 0};
    final recentCounts = {for (int i = 0; i <= 9; i++) i: 0};
    final lastSeen = {for (int i = 0; i <= 9; i++) i: draws.length + 99};
    final recentWindow = min(18, draws.length);
    for (int i = 0; i < draws.length; i++) {
      final sn = draws[i].superNumber;
      if (sn == null || sn < 0 || sn > 9) continue;
      totalCounts[sn] = (totalCounts[sn] ?? 0) + 1;
      if (i < recentWindow) recentCounts[sn] = (recentCounts[sn] ?? 0) + 1;
      if (lastSeen[sn] == draws.length + 99) lastSeen[sn] = i;
    }
    final ranked = <MapEntry<int, double>>[];
    for (int n = 0; n <= 9; n++) {
      final total = (totalCounts[n] ?? 0).toDouble();
      final recent = (recentCounts[n] ?? 0).toDouble();
      final overdue = (lastSeen[n] ?? draws.length).toDouble();
      ranked.add(MapEntry(n, (total * 1.2) + (recent * 2.4) + (overdue * 0.22)));
    }
    ranked.sort((a, b) => b.value.compareTo(a.value));
    return ranked.isEmpty ? null : ranked.first.key;
  }

  List<_RankedNumber> _buildBaseRanking({
    required Map<int, int> freq,
    required Map<int, int> recency,
    required Map<int, int> medium,
    required Map<int, int> lastSeen,
    required String profileLabel,
  }) {
    final aggressive = profileLabel.toLowerCase().contains('aggressiv');
    final defensive = profileLabel.toLowerCase().contains('defensiv');
    final ranked = <_RankedNumber>[];
    for (int number = 1; number <= 49; number++) {
      final total = (freq[number] ?? 0).toDouble();
      final recent = (recency[number] ?? 0).toDouble();
      final mid = (medium[number] ?? 0).toDouble();
      final overdueIndex = (lastSeen[number] ?? 0).toDouble();
      final trend = ((recent * 2.2) + (mid * 0.8)) - (total * 0.25);
      final rebound = overdueIndex * 0.16;
      double score = (total * 0.9) + (recent * 2.0) + (mid * 0.9) + trend + rebound;
      if (aggressive) {
        score += rebound * 1.35;
        score += recent * 0.7;
      } else if (defensive) {
        score += total * 0.9;
        score -= overdueIndex * 0.06;
      } else {
        score += recent * 0.4;
        score += overdueIndex * 0.08;
      }
      ranked.add(_RankedNumber(number: number, score: score));
    }
    ranked.sort((a, b) => b.score.compareTo(a.score));
    return ranked;
  }

  List<int> _buildCandidateTip({
    required List<_RankedNumber> ranking,
    required Map<String, int> pairCounts,
    required Map<String, int> tripleCounts,
    required String profileLabel,
  }) {
    final aggressive = profileLabel.toLowerCase().contains('aggressiv');
    final defensive = profileLabel.toLowerCase().contains('defensiv');
    final selected = <int>{};
    final topPool = ranking.take(24).map((e) => e.number).toList();
    final midPool = ranking.skip(10).take(20).map((e) => e.number).toList();
    while (selected.length < 2 && topPool.isNotEmpty) {
      selected.add(topPool[_random.nextInt(min(topPool.length, 10))]);
    }
    final blendedPool = <int>[...topPool, ...midPool.where((n) => !topPool.contains(n))];
    for (final candidate in blendedPool) {
      if (selected.length >= 6 || selected.contains(candidate)) continue;
      final probe = [...selected, candidate].toList()..sort();
      final pairStrength = _probePairStrength(probe, pairCounts);
      final tripleStrength = _probeTripleStrength(probe, tripleCounts);
      final shouldTake = aggressive
          ? (pairStrength >= 1.6 || tripleStrength >= 0.7 || _random.nextDouble() < 0.36)
          : defensive
          ? (pairStrength >= 1.0 || tripleStrength >= 0.4 || _random.nextDouble() < 0.18)
          : (pairStrength >= 1.2 || tripleStrength >= 0.5 || _random.nextDouble() < 0.24);
      if (shouldTake) selected.add(candidate);
    }
    for (final item in ranking) {
      if (selected.length >= 6) break;
      selected.add(item.number);
    }
    return _normalizeStructure(selected.take(6).toList());
  }

  double _probePairStrength(List<int> tip, Map<String, int> pairCounts) {
    if (tip.length < 2) return 0;
    double sum = 0; int count = 0;
    for (int i = 0; i < tip.length; i++) {
      for (int j = i + 1; j < tip.length; j++) {
        sum += (pairCounts['${tip[i]}-${tip[j]}'] ?? 0).toDouble();
        count++;
      }
    }
    return count == 0 ? 0 : sum / count;
  }

  double _probeTripleStrength(List<int> tip, Map<String, int> tripleCounts) {
    if (tip.length < 3) return 0;
    double sum = 0; int count = 0;
    for (int i = 0; i < tip.length; i++) {
      for (int j = i + 1; j < tip.length; j++) {
        for (int k = j + 1; k < tip.length; k++) {
          sum += (tripleCounts['${tip[i]}-${tip[j]}-${tip[k]}'] ?? 0).toDouble();
          count++;
        }
      }
    }
    return count == 0 ? 0 : sum / count;
  }

  List<int> _normalizeStructure(List<int> rawTip) {
    final tip = rawTip.toSet().where((n) => n >= 1 && n <= 49).toList()..sort();
    if (tip.length != 6) {
      final fallback = <int>{...tip};
      while (fallback.length < 6) fallback.add(_random.nextInt(49) + 1);
      return fallback.toList()..sort();
    }
    final result = List<int>.from(tip);
    int loopGuard = 0;
    while (loopGuard < 120) {
      loopGuard++;
      final even = result.where((n) => n.isEven).length;
      final low = result.where((n) => n <= 24).length;
      final sum = result.fold<int>(0, (a, b) => a + b);
      final spread = result.last - result.first;
      final uniqueEnds = result.map((e) => e % 10).toSet().length;
      final good = even >= 2 && even <= 4 && low >= 2 && low <= 4 && sum >= 95 && sum <= 190 && spread >= 18 && spread <= 42 && uniqueEnds >= 4;
      if (good) break;
      result.removeAt(_random.nextInt(result.length));
      result.add(_random.nextInt(49) + 1);
      final unique = result.toSet().toList()..sort();
      result..clear()..addAll(unique);
      while (result.length < 6) {
        result.add(_random.nextInt(49) + 1);
        final next = result.toSet().toList()..sort();
        result..clear()..addAll(next);
      }
      result.sort();
    }
    return result.take(6).toList()..sort();
  }

  PredictionCandidate _scoreTip({
    required List<int> tip,
    required List<List<int>> draws,
    required Map<String, int> pairCounts,
    required Map<String, int> tripleCounts,
    required Map<int, int> freq,
    required Map<int, int> recency,
    required Map<int, int> medium,
    required Map<int, int> lastSeen,
    required Map<int, int> repeatHistogram,
  }) {
    final backtest = _backtestTip(tip, draws);
    final score3Plus = _score3Plus(backtest, draws.length);
    final pairScore = _pairScore(tip, pairCounts);
    final tripleScore = _tripleScore(tip, tripleCounts);
    final recencyScore = _recencyScore(tip, freq, recency, medium);
    final overdueScore = _overdueScore(tip, lastSeen);
    final structureScore = _structureScore(tip, repeatHistogram);
    final totalScore = (score3Plus * 0.34) + (pairScore * 0.18) + (tripleScore * 0.12) + (recencyScore * 0.16) + (overdueScore * 0.10) + (structureScore * 0.10);
    return PredictionCandidate(
      tip: tip,
      totalScore: totalScore,
      score3Plus: score3Plus,
      pairScore: pairScore,
      tripleScore: tripleScore,
      recencyScore: recencyScore,
      overdueScore: overdueScore,
      structureScore: structureScore,
      reasons: [
        '3+ Rücktest: ${score3Plus.toStringAsFixed(1)}',
        'Paarmuster: ${pairScore.toStringAsFixed(1)}',
        'Dreiermuster: ${tripleScore.toStringAsFixed(1)}',
        'Trend + Dynamik: ${recencyScore.toStringAsFixed(1)}',
        'Überfälligkeit: ${overdueScore.toStringAsFixed(1)}',
        'Strukturfit: ${structureScore.toStringAsFixed(1)}',
      ],
    );
  }

  Map<int, int> _backtestTip(List<int> tip, List<List<int>> draws) {
    final hist = {for (int i = 0; i <= 6; i++) i: 0};
    final set = tip.toSet();
    for (final draw in draws) {
      final hits = draw.where(set.contains).length;
      hist[hits] = (hist[hits] ?? 0) + 1;
    }
    return hist;
  }

  double _score3Plus(Map<int, int> backtest, int totalDraws) {
    if (totalDraws == 0) return 0;
    final weighted = ((backtest[2] ?? 0) * 0.7) + ((backtest[3] ?? 0) * 2.8) + ((backtest[4] ?? 0) * 5.4) + ((backtest[5] ?? 0) * 8.8) + ((backtest[6] ?? 0) * 12.5);
    return (weighted / totalDraws) * 10.0;
  }

  double _pairScore(List<int> tip, Map<String, int> pairCounts) => _probePairStrength(tip, pairCounts);
  double _tripleScore(List<int> tip, Map<String, int> tripleCounts) => _probeTripleStrength(tip, tripleCounts);

  double _recencyScore(List<int> tip, Map<int, int> freq, Map<int, int> recency, Map<int, int> medium) {
    double sum = 0;
    for (final n in tip) {
      sum += ((recency[n] ?? 0) * 2.0) + ((medium[n] ?? 0) * 1.0) + ((freq[n] ?? 0) * 0.45);
    }
    return sum / tip.length;
  }

  double _overdueScore(List<int> tip, Map<int, int> lastSeen) {
    double sum = 0;
    for (final n in tip) sum += (lastSeen[n] ?? 0).toDouble();
    return sum / tip.length;
  }

  double _structureScore(List<int> tip, Map<int, int> repeatHistogram) {
    final even = tip.where((n) => n.isEven).length;
    final low = tip.where((n) => n <= 24).length;
    final sum = tip.fold<int>(0, (a, b) => a + b);
    final spread = tip.last - tip.first;
    final endDigits = tip.map((e) => e % 10).toSet().length;
    double score = 0;
    if (even >= 2 && even <= 4) score += 8;
    if (low >= 2 && low <= 4) score += 8;
    if (sum >= 95 && sum <= 190) score += 10;
    if (spread >= 18 && spread <= 42) score += 8;
    if (endDigits >= 4) score += 4;
    if ((repeatHistogram[1] ?? 0) >= (repeatHistogram[2] ?? 0)) score += 2;
    return score;
  }
}

class _RankedNumber {
  final int number;
  final double score;
  const _RankedNumber({required this.number, required this.score});
}
