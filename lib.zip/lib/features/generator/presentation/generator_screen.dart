import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/number_ball.dart';
import '../../../core/widgets/primary_button.dart';
import '../../analysis/presentation/ai_max_mode_screen.dart';
import '../../analysis/presentation/win_simulation_screen.dart';
import '../provider/lotto_app_state.dart';

class GeneratorScreen extends StatefulWidget {
  const GeneratorScreen({super.key});

  @override
  State<GeneratorScreen> createState() => _GeneratorScreenState();
}

class _GeneratorScreenState extends State<GeneratorScreen> {
  int _tabIndex = 0;

  Future<void> _showMessage(String message) async {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _generateRandom() async {
    await context.read<LottoAppState>().generateRandomTip();
    await _showMessage('Zufallstipp wurde erstellt.');
  }

  Future<void> _saveLastTip() async {
    await context.read<LottoAppState>().saveLastTip(source: 'manual');
    await _showMessage('Tipp wurde gespeichert.');
  }

  Future<void> _generateAnalysis() async {
    try {
      await context.read<LottoAppState>().generateAnalysisTip();
      await _showMessage('Analyse-Tipp wurde erstellt.');
    } catch (e) {
      await _showMessage(e.toString());
    }
  }

  Future<void> _applyBestTip() async {
    await context.read<LottoAppState>().applyBestAnalyzedTip();
    await _showMessage('AI Pro Tipp wurde übernommen.');
  }

  Future<void> _generateSystem() async {
    try {
      await context.read<LottoAppState>().generateSystemTip();
      if (!mounted) return;
      final rows = context.read<LottoAppState>().systemRows.length;
      await _showMessage('$rows Systemreihen wurden erzeugt.');
    } catch (e) {
      await _showMessage(e.toString());
    }
  }

  Future<void> _saveSystemRows() async {
    final added = await context.read<LottoAppState>().saveSystemRowsAsTips();
    await _showMessage('$added Systemreihen wurden gespeichert.');
  }

  Future<void> _copyLastTip() async {
    final state = context.read<LottoAppState>();
    final tip = state.lastGeneratedTip;
    final superNumber = state.lastGeneratedSuperNumber;

    if (tip == null || tip.isEmpty) {
      await _showMessage('Noch kein Tipp vorhanden.');
      return;
    }

    final text = superNumber == null
        ? tip.join(', ')
        : '${tip.join(', ')} | SZ: $superNumber';

    await Clipboard.setData(ClipboardData(text: text));
    await _showMessage('Tipp wurde kopiert.');
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();
    final summary = state.analysisSummary;
    final ai = state.analysisAiSummary;
    final pro = state.analysisProSummary;
    final bestTip = state.bestAnalyzedTip;
    final lastTip = state.lastGeneratedTip;
    final lastSuper = state.lastGeneratedSuperNumber;
    final recommendedSuper = state.recommendedSuperNumber;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
              sliver: SliverList(
                delegate: SliverChildListDelegate(
                  [
                    const _GlassHeader(),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(
                          child: _TopMetricCard(
                            title: 'Ziehungen',
                            value: '${summary.drawCount}',
                            icon: Icons.dataset_rounded,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _TopMetricCard(
                            title: 'Profil',
                            value: state.analysisProfileLabel,
                            icon: Icons.psychology_alt_rounded,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _TopMetricCard(
                            title: 'Qualität',
                            value: state.analysisStrengthLabel,
                            icon: Icons.insights_rounded,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    _TabSwitcher(
                      index: _tabIndex,
                      labels: const ['Zufall', 'Analyse', 'System'],
                      onChanged: (value) {
                        setState(() {
                          _tabIndex = value;
                        });
                      },
                    ),
                    const SizedBox(height: 14),
                    if (_tabIndex == 0) ...[
                      _SubCard(
                        title: 'Zufallsgenerator',
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Erstellt einen klassischen Zufallstipp mit 6 Zahlen.',
                              style: TextStyle(
                                fontSize: 12,
                                height: 1.4,
                                color: AppColors.textSecondary,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 14),
                            PrimaryButton(
                              label: 'Zufallstipp generieren',
                              icon: Icons.casino_rounded,
                              onPressed: _generateRandom,
                            ),
                            const SizedBox(height: 10),
                            PrimaryButton(
                              label: 'Tipp speichern',
                              icon: Icons.bookmark_add_rounded,
                              onPressed: _saveLastTip,
                            ),
                          ],
                        ),
                      ),
                    ],
                    if (_tabIndex == 1) ...[
                      _SubCard(
                        title: 'Analyse Steuerung',
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const _ControlLabel('Analysezeitraum'),
                            const SizedBox(height: 8),
                            Slider(
                              value: state.analysisDrawCount.toDouble(),
                              min: 1,
                              max: state.maxAnalysisDrawCount.toDouble(),
                              divisions: state.maxAnalysisDrawCount > 1
                                  ? state.maxAnalysisDrawCount - 1
                                  : 1,
                              label: '${state.analysisDrawCount}',
                              onChanged: (value) {
                                context.read<LottoAppState>().setAnalysisDrawCount(
                                  value.round(),
                                );
                              },
                              onChangeEnd: (_) {
                                context.read<LottoAppState>().persistAnalysisWindow();
                              },
                            ),
                            Row(
                              children: [
                                const Text(
                                  '1',
                                  style: TextStyle(
                                    color: AppColors.textSecondary,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const Spacer(),
                                const Text(
                                  'Finger: 1er • Buttons: 1 / 10',
                                  style: TextStyle(
                                    color: AppColors.textSecondary,
                                    fontSize: 10.5,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const Spacer(),
                                Text(
                                  '${state.maxAnalysisDrawCount}',
                                  style: const TextStyle(
                                    color: AppColors.textSecondary,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                Expanded(
                                  child: OutlinedButton.icon(
                                    onPressed: () {
                                      context.read<LottoAppState>().setAnalysisToRecent52();
                                    },
                                    icon: const Icon(Icons.history_rounded),
                                    label: const Text('Letzte 52'),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: OutlinedButton.icon(
                                    onPressed: () {
                                      context.read<LottoAppState>().setAnalysisToAllHistory();
                                    },
                                    icon: const Icon(Icons.all_inclusive_rounded),
                                    label: const Text('Komplett'),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            const _ControlLabel('Profil'),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Expanded(
                                  child: _ChoiceButton(
                                    label: 'Defensiv',
                                    selected: state.analysisProfile == AnalysisProfile.defensive,
                                    onTap: () => context.read<LottoAppState>().setAnalysisProfile(
                                      AnalysisProfile.defensive,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: _ChoiceButton(
                                    label: 'Mittel',
                                    selected: state.analysisProfile == AnalysisProfile.balanced,
                                    onTap: () => context.read<LottoAppState>().setAnalysisProfile(
                                      AnalysisProfile.balanced,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: _ChoiceButton(
                                    label: 'Aggressiv',
                                    selected: state.analysisProfile == AnalysisProfile.aggressive,
                                    onTap: () => context.read<LottoAppState>().setAnalysisProfile(
                                      AnalysisProfile.aggressive,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 14),
                            _InlineInfo(label: 'Fenster', value: state.analysisWindowLabel),
                            const SizedBox(height: 6),
                            _InlineInfo(label: 'Ziehungen', value: '${state.analysisDrawCount}'),
                            const SizedBox(height: 6),
                            _InlineInfo(label: 'Qualität', value: state.analysisStrengthLabel),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      PrimaryButton(
                        label: 'Analyse-Tipp berechnen',
                        icon: Icons.auto_awesome_rounded,
                        onPressed: _generateAnalysis,
                      ),
                      const SizedBox(height: 10),
                      PrimaryButton(
                        label: 'AI Max Mode',
                        icon: Icons.psychology_alt_rounded,
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => const AiMaxModeScreen(),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 10),
                      PrimaryButton(
                        label: 'Gewinnsimulation',
                        icon: Icons.query_stats_rounded,
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => const WinSimulationScreen(),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 14),
                      _SubCard(
                        title: 'AI Bewertung',
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _InlineInfo(label: 'Titel', value: ai.title),
                            const SizedBox(height: 6),
                            _InlineInfo(label: 'Confidence', value: ai.confidence),
                            const SizedBox(height: 12),
                            _ConfidenceBar(confidenceText: ai.confidence),
                            if (recommendedSuper != null) ...[
                              const SizedBox(height: 12),
                              _InlineInfo(
                                label: 'Superzahl Prognose',
                                value: '$recommendedSuper',
                              ),
                            ],
                            const SizedBox(height: 12),
                            _BallRow(title: 'Empfohlen', numbers: ai.recommendedNumbers),
                            const SizedBox(height: 12),
                            _BallRow(title: 'Eher meiden', numbers: ai.avoidNumbers),
                            const SizedBox(height: 12),
                            Text(
                              ai.reasoning,
                              style: const TextStyle(
                                fontSize: 12,
                                height: 1.4,
                                color: AppColors.textSecondary,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      _SubCard(
                        title: 'AI Pro Bewertung',
                        child: bestTip.length != 6
                            ? const Text(
                          'Noch kein AI Pro Tipp verfügbar.',
                          style: TextStyle(
                            color: AppColors.textSecondary,
                            fontWeight: FontWeight.w600,
                          ),
                        )
                            : Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              pro.strategy,
                              style: const TextStyle(
                                fontSize: 12,
                                height: 1.4,
                                color: AppColors.textSecondary,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 12),
                            _BallRow(title: 'Bester Tipp', numbers: bestTip),
                            const SizedBox(height: 12),
                            PrimaryButton(
                              label: 'AI Pro Tipp übernehmen',
                              icon: Icons.download_done_rounded,
                              onPressed: _applyBestTip,
                            ),
                          ],
                        ),
                      ),
                    ],
                    if (_tabIndex == 2) ...[
                      _SubCard(
                        title: 'Systemgenerator',
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _InlineInfo(label: 'Spieltyp', value: state.systemPlayTypeLabel),
                            const SizedBox(height: 6),
                            _InlineInfo(label: 'Systemgröße', value: '${state.selectedSystemSize}'),
                            const SizedBox(height: 6),
                            _InlineInfo(label: 'Manuell gewählt', value: '${state.manualSystemNumbers.length}'),
                            const SizedBox(height: 6),
                            _InlineInfo(label: 'Reihen', value: '${state.systemRows.length}'),
                            const SizedBox(height: 14),
                            PrimaryButton(
                              label: 'System berechnen',
                              icon: Icons.grid_view_rounded,
                              onPressed: _generateSystem,
                            ),
                            const SizedBox(height: 10),
                            PrimaryButton(
                              label: 'Systemreihen speichern',
                              icon: Icons.save_alt_rounded,
                              onPressed: _saveSystemRows,
                            ),
                          ],
                        ),
                      ),
                    ],
                    const SizedBox(height: 14),
                    _SubCard(
                      title: 'Aktueller Tipp',
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (lastTip == null || lastTip.isEmpty)
                            const Text(
                              'Noch kein Tipp generiert.',
                              style: TextStyle(
                                color: AppColors.textSecondary,
                                fontWeight: FontWeight.w600,
                              ),
                            )
                          else ...[
                            _BallRow(
                              title: 'Zahlen',
                              numbers: lastTip,
                            ),
                            const SizedBox(height: 10),
                            _InlineInfo(
                              label: 'Superzahl',
                              value: lastSuper?.toString() ?? '-',
                            ),
                            const SizedBox(height: 12),
                            _GainEstimateCard(
                              simulation: state.lastTipSimulation,
                            ),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Expanded(
                                  child: PrimaryButton(
                                    label: 'Speichern',
                                    icon: Icons.bookmark_add_rounded,
                                    onPressed: _saveLastTip,
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: OutlinedButton.icon(
                                    onPressed: _copyLastTip,
                                    icon: const Icon(Icons.copy_rounded),
                                    label: const Text('Kopieren'),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GlassHeader extends StatelessWidget {
  const _GlassHeader();

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.white.withOpacity(0.90),
                Colors.white.withOpacity(0.72),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Colors.white.withOpacity(0.65)),
            boxShadow: const [
              BoxShadow(
                color: AppColors.shadowLight,
                blurRadius: 18,
                offset: Offset(0, 10),
              ),
            ],
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Generator',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  color: AppColors.textPrimary,
                ),
              ),
              SizedBox(height: 6),
              Text(
                'Zufall, Analyse und Systemerzeugung in einer klaren Oberfläche.',
                style: TextStyle(
                  fontSize: 13,
                  height: 1.4,
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TopMetricCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _TopMetricCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowLight,
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, color: AppColors.primary, size: 20),
          const SizedBox(height: 10),
          Text(
            value,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

class _TabSwitcher extends StatelessWidget {
  final int index;
  final List<String> labels;
  final ValueChanged<int> onChanged;

  const _TabSwitcher({
    required this.index,
    required this.labels,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: List.generate(labels.length, (i) {
          final selected = i == index;
          return Expanded(
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => onChanged(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  gradient: selected
                      ? const LinearGradient(
                    colors: [AppColors.primary, AppColors.primaryDark],
                  )
                      : null,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  labels[i],
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: selected ? Colors.white : AppColors.textSecondary,
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _SubCard extends StatelessWidget {
  final String title;
  final Widget child;

  const _SubCard({
    required this.title,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowLight,
            blurRadius: 16,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class _ControlLabel extends StatelessWidget {
  final String text;

  const _ControlLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w800,
        color: AppColors.textSecondary,
      ),
    );
  }
}

class _ChoiceButton extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _ChoiceButton({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          gradient: selected
              ? const LinearGradient(
            colors: [AppColors.primary, AppColors.primaryDark],
          )
              : null,
          color: selected ? null : AppColors.surfaceSoft,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? Colors.transparent : AppColors.border,
          ),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w800,
            color: selected ? Colors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }
}

class _InlineInfo extends StatelessWidget {
  final String label;
  final String value;

  const _InlineInfo({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: AppColors.textSecondary,
            fontWeight: FontWeight.w700,
          ),
        ),
        const Spacer(),
        Text(
          value,
          style: const TextStyle(
            fontSize: 12,
            color: AppColors.textPrimary,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

class _BallRow extends StatelessWidget {
  final String title;
  final List<int> numbers;

  const _BallRow({
    required this.title,
    required this.numbers,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 12,
            color: AppColors.textSecondary,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: numbers.map((n) => NumberBall(number: n)).toList(),
        ),
      ],
    );
  }
}


class _GainEstimateCard extends StatelessWidget {
  final TipSimulationSummary? simulation;

  const _GainEstimateCard({
    required this.simulation,
  });

  @override
  Widget build(BuildContext context) {
    if (simulation == null || simulation!.totalDraws <= 0) {
      return const SizedBox.shrink();
    }

    final s = simulation!;
    final hit3 = s.getHitCount(3);
    final hit4 = s.getHitCount(4);
    final hit5 = s.getHitCount(5);
    final hit6 = s.getHitCount(6);

    final estimatedEuro =
        (hit3 * 12.0) + (hit4 * 55.0) + (hit5 * 1800.0) + (hit6 * 250000.0);
    final euroPerDraw = estimatedEuro / s.totalDraws;

    final weighted = (hit3 * 1.0) + (hit4 * 4.0) + (hit5 * 12.0) + (hit6 * 40.0);
    final riskLabel = hit4 + hit5 + hit6 > 0
        ? 'Chance-orientiert'
        : hit3 > 0
        ? 'Mittel'
        : 'Spekulativ';

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surfaceSoft,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Gewinn-Anzeige',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Modellwert auf Basis des aktuellen Rücktests im gewählten Analysefenster.',
            style: TextStyle(
              fontSize: 11.5,
              height: 1.35,
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _MetricMiniCard(
                  label: 'Modellwert',
                  value: '${estimatedEuro.toStringAsFixed(2).replaceAll('.', ',')} €',
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _MetricMiniCard(
                  label: 'Ø pro Ziehung',
                  value: '${euroPerDraw.toStringAsFixed(2).replaceAll('.', ',')} €',
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _MetricMiniCard(
                  label: 'Risiko',
                  value: riskLabel,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _MetricMiniCard(
                  label: 'Treffer-Score',
                  value: weighted.toStringAsFixed(0),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            '3er: $hit3 • 4er: $hit4 • 5er: $hit5 • 6er: $hit6',
            style: const TextStyle(
              fontSize: 11.5,
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _MetricMiniCard extends StatelessWidget {
  final String label;
  final String value;

  const _MetricMiniCard({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Text(
            value,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w700,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

class _ConfidenceBar extends StatelessWidget {
  final String confidenceText;

  const _ConfidenceBar({
    required this.confidenceText,
  });

  @override
  Widget build(BuildContext context) {
    double value;
    if (confidenceText.toLowerCase().contains('sehr')) {
      value = 1.0;
    } else if (confidenceText.toLowerCase().contains('stark')) {
      value = 0.8;
    } else if (confidenceText.toLowerCase().contains('mittel')) {
      value = 0.6;
    } else if (confidenceText.toLowerCase().contains('begrenzt')) {
      value = 0.35;
    } else {
      value = 0.18;
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(999),
      child: LinearProgressIndicator(
        value: value,
        minHeight: 10,
        backgroundColor: AppColors.surfaceSoft,
      ),
    );
  }
}
