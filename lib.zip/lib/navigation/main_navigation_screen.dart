import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../features/generator/presentation/system_ai_screen.dart';

import 'package:lotto_davenport/features/analysis/presentation/analysis_screen.dart';
import 'package:lotto_davenport/features/dashboard/presentation/dashboard_screen.dart';
import 'package:lotto_davenport/features/draws/presentation/draw_results_screen.dart';
import 'package:lotto_davenport/features/generator/presentation/generator_screen.dart';
import 'package:lotto_davenport/features/settings/presentation/settings_screen.dart';
import 'package:lotto_davenport/features/systems/presentation/system_generator_screen.dart';
import 'package:lotto_davenport/features/tips/presentation/my_tips_screen.dart';
import 'package:lotto_davenport/features/generator/provider/lotto_app_state.dart';

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  static final List<Widget> _mainScreens = <Widget>[
    const DashboardScreen(),
    const GeneratorScreen(),
    const DrawResultsScreen(),
    const AnalysisScreen(),
    const _MoreScreen(),
  ];

  void _onTabChanged(int index) {
    if (_currentIndex == index) return;

    setState(() {
      _currentIndex = index;
    });

    if (index == 3) {
      final state = context.read<LottoAppState>();
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      extendBody: true,
      body: Container(
        color: const Color(0xFFF5F7FB),
        child: IndexedStack(
          index: _currentIndex,
          children: _mainScreens,
        ),
      ),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(26),
            color: Colors.white.withValues(alpha: 0.95),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.08),
                blurRadius: 22,
                offset: const Offset(0, 10),
              ),
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.03),
                blurRadius: 6,
                offset: const Offset(0, 2),
              ),
            ],
            border: Border.all(
              color: Colors.black.withValues(alpha: 0.05),
            ),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(26),
            child: NavigationBarTheme(
              data: NavigationBarThemeData(
                height: 72,
                backgroundColor: Colors.transparent,
                elevation: 0,
                surfaceTintColor: Colors.transparent,
                indicatorColor: scheme.primary.withValues(alpha: 0.14),
                labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
                labelTextStyle: WidgetStateProperty.resolveWith<TextStyle?>(
                      (states) {
                    final selected = states.contains(WidgetState.selected);
                    return TextStyle(
                      fontSize: 11,
                      height: 1.0,
                      leadingDistribution: TextLeadingDistribution.even,
                      fontWeight:
                      selected ? FontWeight.w700 : FontWeight.w600,
                      color: selected
                          ? scheme.primary
                          : const Color(0xFF6B7280),
                    );
                  },
                ),
                iconTheme: WidgetStateProperty.resolveWith<IconThemeData?>(
                      (states) {
                    final selected = states.contains(WidgetState.selected);
                    return IconThemeData(
                      size: 23,
                      color: selected
                          ? scheme.primary
                          : const Color(0xFF7C8798),
                    );
                  },
                ),
              ),
              child: NavigationBar(
                selectedIndex: _currentIndex,
                onDestinationSelected: _onTabChanged,
                destinations: const [
                  NavigationDestination(
                    icon: Icon(Icons.dashboard_rounded),
                    selectedIcon: Icon(Icons.dashboard_customize_rounded),
                    label: 'Start',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.auto_awesome_rounded),
                    selectedIcon: Icon(Icons.auto_awesome),
                    label: 'Generator',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.fact_check_rounded),
                    selectedIcon: Icon(Icons.task_alt_rounded),
                    label: 'Prüfung',
                  ),

                  NavigationDestination(
                    icon: Icon(Icons.analytics_rounded),
                    selectedIcon: Icon(Icons.query_stats_rounded),
                    label: 'Analyse',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.widgets_rounded),
                    selectedIcon: Icon(Icons.widgets),
                    label: 'Mehr',
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _MoreScreen extends StatelessWidget {
  const _MoreScreen();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
        children: [
          const _MoreHeader(),
          const SizedBox(height: 20),
          _MoreEntryCard(
            title: 'Systemgenerator',
            subtitle: 'Lottosysteme und systembasierte Generierung öffnen',
            icon: Icons.grid_view_rounded,
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const SystemGeneratorScreen(),
                ),
              );
            },
          ),
          const SizedBox(height: 14),

          _MoreEntryCard(
            title: 'System AI',
            subtitle: 'AI optimierte VEW & Vollsystem Reihen mit Top-Auswahl',
            icon: Icons.auto_awesome_rounded,
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const SystemAiScreen(),
                ),
              );
            },
          ),
          const SizedBox(height: 14),
          _MoreEntryCard(
            title: 'Meine Tipps',
            subtitle: 'Gespeicherte Tipps, Übersicht und Verwaltung',
            icon: Icons.confirmation_number_rounded,
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => MyTipsScreen(),
                ),
              );
            },
          ),
          const SizedBox(height: 14),
          _MoreEntryCard(
            title: 'Einstellungen',
            subtitle: 'App-Konfiguration, Optionen und weitere Bereiche',
            icon: Icons.settings_rounded,
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const SettingsScreen(),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _MoreHeader extends StatelessWidget {
  const _MoreHeader();

  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Mehr',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.w800,
            color: Color(0xFF111827),
          ),
        ),
        SizedBox(height: 8),
        Text(
          'Zusätzliche Bereiche sauber gebündelt, damit die Hauptnavigation unten klar und intuitiv bleibt.',
          style: TextStyle(
            fontSize: 14,
            height: 1.45,
            color: Color(0xFF6B7280),
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

class _MoreEntryCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;

  const _MoreEntryCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: const Color(0xFFE5E7EB)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.03),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: const Color(0xFFF3F6FC),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(
                  icon,
                  color: const Color(0xFF2563EB),
                  size: 24,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF111827),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        fontSize: 13,
                        height: 1.45,
                        color: Color(0xFF6B7280),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              const Icon(
                Icons.chevron_right_rounded,
                color: Color(0xFF9CA3AF),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
