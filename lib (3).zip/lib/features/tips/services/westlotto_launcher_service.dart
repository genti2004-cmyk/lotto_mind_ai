import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

class WestlottoActionResult {
  final bool success;
  final String message;

  const WestlottoActionResult({
    required this.success,
    required this.message,
  });
}

class WestlottoLauncherService {
  static const String _url = 'https://www.westlotto.de/lotto6aus49';

  static Future<WestlottoActionResult> copyOnly(String text) async {
    await Clipboard.setData(ClipboardData(text: text));
    return const WestlottoActionResult(
      success: true,
      message: 'Abgabe wurde in die Zwischenablage kopiert.',
    );
  }

  static Future<WestlottoActionResult> open(String text) async {
    await Clipboard.setData(ClipboardData(text: text));

    final uri = Uri.parse(_url);
    final opened = await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    );

    if (opened) {
      return const WestlottoActionResult(
        success: true,
        message: 'WestLotto wurde geöffnet. Die Abgabe wurde kopiert.',
      );
    }

    return const WestlottoActionResult(
      success: false,
      message: 'WestLotto konnte nicht geöffnet werden. Die Abgabe wurde aber kopiert.',
    );
  }
}