import 'package:flutter/material.dart';

import '../domain/full_system_pricing.dart';
import '../domain/system_models.dart';

class SystemPlayScreen extends StatefulWidget {
  const SystemPlayScreen({super.key});

  @override
  State<SystemPlayScreen> createState() => _SystemPlayScreenState();
}

class _SystemPlayScreenState extends State<SystemPlayScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  int _normalRows = 1;
  bool _withSpiel77 = false;
  bool _withSuper6 = false;
  bool _playWednesday = true;
  bool _playSaturday = true;
  int _weeks = 1;
  FullSystemType _selectedFullSystem = FullSystemType.fs007;
  VewPreset _selectedVew = defaultVewPresets.first;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this)
      ..addListener(() {
        if (mounted) setState(() {});
      });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  int get _drawCountPerWeek {
    final count = (_playWednesday ? 1 : 0) + (_playSaturday ? 1 : 0);
    return count == 0 ? 1 : count;
  }

  int get _totalDrawCount => _drawCountPerWeek * _weeks;

  double get _processingFee =>
      LottoSystemPricing.defaultProcessingFee(drawCount: _totalDrawCount);

  PriceBreakdown get _priceBreakdown {
    switch (_tabController.index) {
      case 0:
        return LottoSystemPricing.normalBreakdown(
          rows: _normalRows,
          withSpiel77: _withSpiel77,
          withSuper6: _withSuper6,
          drawCount: _totalDrawCount,
          processingFee: _processingFee,
        );
      case 1:
        return LottoSystemPricing.fullBreakdown(
          system: _selectedFullSystem,
          withSpiel77: _withSpiel77,
          withSuper6: _withSuper6,
          drawCount: _totalDrawCount,
          processingFee: _processingFee,
        );
      default:
        return LottoSystemPricing.vewBreakdown(
          rows: _selectedVew.reihen,
          withSpiel77: _withSpiel77,
          withSuper6: _withSuper6,
          drawCount: _totalDrawCount,
          processingFee: _processingFee,
        );
    }
  }

  String _currency(double value) => '${value.toStringAsFixed(2).replaceAll('.', ',')} €';

  @override
  Widget build(BuildContext context) {
    final breakdown = _priceBreakdown;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Systemspiel'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Normalschein'),
            Tab(text: 'Vollsystem'),
            Tab(text: 'VEW'),
          ],
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildModeHeader(),
            const SizedBox(height: 16),
            _buildDrawSelectionCard(),
            const SizedBox(height: 16),
            _buildAddonCard(),
            const SizedBox(height: 16),
            SizedBox(
              height: 360,
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildNormalTab(),
                  _buildFullTab(),
                  _buildVewTab(),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _buildSummaryCard(breakdown),
            const SizedBox(height: 16),
            _buildInfoCard(),
          ],
        ),
      ),
    );
  }

  Widget _buildModeHeader() {
    final titles = ['Normalschein', 'Vollsystem 007–010', 'VEW / Teilsystem'];
    final subtitles = [
      'Klassische Spielreihen mit 6 Zahlen.',
      '7 bis 10 Zahlen, alle Kombinationen werden gespielt.',
      'Verkürzte Systeme mit kontrollierter Reihenanzahl.',
    ];

    final index = _tabController.index;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              titles[index],
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 6),
            Text(
              subtitles[index],
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawSelectionCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Ziehungen & Laufzeit', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                FilterChip(
                  selected: _playWednesday,
                  label: const Text('Mittwoch'),
                  onSelected: (value) {
                    setState(() {
                      _playWednesday = value;
                      if (!_playWednesday && !_playSaturday) {
                        _playSaturday = true;
                      }
                    });
                  },
                ),
                FilterChip(
                  selected: _playSaturday,
                  label: const Text('Samstag'),
                  onSelected: (value) {
                    setState(() {
                      _playSaturday = value;
                      if (!_playWednesday && !_playSaturday) {
                        _playWednesday = true;
                      }
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                const Text('Laufzeit'),
                const Spacer(),
                Text('$_weeks Woche${_weeks == 1 ? '' : 'n'}'),
              ],
            ),
            Slider(
              value: _weeks.toDouble(),
              min: 1,
              max: 12,
              divisions: 11,
              label: '$_weeks',
              onChanged: (value) {
                setState(() => _weeks = value.round());
              },
            ),
            const SizedBox(height: 4),
            Text('Gesamtziehungen: $_totalDrawCount'),
          ],
        ),
      ),
    );
  }

  Widget _buildAddonCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Zusatzlotterien', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: _withSpiel77,
              title: const Text('Spiel 77'),
              subtitle: const Text('2,50 € pro Ziehung'),
              onChanged: (value) => setState(() => _withSpiel77 = value),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: _withSuper6,
              title: const Text('SUPER 6'),
              subtitle: const Text('1,25 € pro Ziehung'),
              onChanged: (value) => setState(() => _withSuper6 = value),
            ),
            const Divider(),
            const ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.info_outline),
              title: Text('Superzahl'),
              subtitle: Text('Die Superzahl ist bei LOTTO 6aus49 enthalten und kostet nichts extra.'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNormalTab() {
    final base = LottoSystemPricing.normalBasePrice(rows: _normalRows);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Anzahl Tippfelder', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            Row(
              children: [
                IconButton(
                  onPressed: _normalRows > 1 ? () => setState(() => _normalRows--) : null,
                  icon: const Icon(Icons.remove_circle_outline),
                ),
                Expanded(
                  child: Center(
                    child: Text(
                      '$_normalRows',
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: _normalRows < 12 ? () => setState(() => _normalRows++) : null,
                  icon: const Icon(Icons.add_circle_outline),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text('Grundpreis pro Ziehung: ${_currency(base)}'),
            const SizedBox(height: 12),
            const Text('Pro Tippfeld werden 6 Zahlen gespielt.'),
          ],
        ),
      ),
    );
  }

  Widget _buildFullTab() {
    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(),
      itemCount: FullSystemType.values.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final system = FullSystemType.values[index];
        final selected = system == _selectedFullSystem;
        final price = LottoSystemPricing.fullSystemBasePrices[system] ?? 0;

        return InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => setState(() => _selectedFullSystem = system),
          child: Ink(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: selected ? Theme.of(context).colorScheme.primary : Colors.grey.shade300,
                width: selected ? 2 : 1,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Radio<FullSystemType>(
                    value: system,
                    groupValue: _selectedFullSystem,
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => _selectedFullSystem = value);
                      }
                    },
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(system.title, style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 4),
                        Text(system.subtitle),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    _currency(price),
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildVewTab() {
    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(),
      itemCount: defaultVewPresets.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final preset = defaultVewPresets[index];
        final selected = preset.code == _selectedVew.code;
        final basePrice = preset.reihen * LottoSystemPricing.lottoRowPrice;

        return InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => setState(() => _selectedVew = preset),
          child: Ink(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: selected ? Theme.of(context).colorScheme.primary : Colors.grey.shade300,
                width: selected ? 2 : 1,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Radio<String>(
                        value: preset.code,
                        groupValue: _selectedVew.code,
                        onChanged: (_) => setState(() => _selectedVew = preset),
                      ),
                      Expanded(
                        child: Text(
                          '${preset.code} · ${preset.name}',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                      ),
                      Text(_currency(basePrice)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text('${preset.stammzahlen} Stammzahlen · ${preset.reihen} Reihen'),
                  const SizedBox(height: 4),
                  Text(preset.hinweis),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildSummaryCard(PriceBreakdown breakdown) {
    final modeLabel = switch (_tabController.index) {
      0 => 'Normalschein mit $_normalRows Feld${_normalRows == 1 ? '' : 'ern'}',
      1 => _selectedFullSystem.title,
      _ => '${_selectedVew.code} · ${_selectedVew.name}',
    };

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Preisübersicht', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            _summaryRow('Spielart', modeLabel),
            _summaryRow('LOTTO Grundpreis / Ziehung', _currency(breakdown.baseAmount)),
            _summaryRow('Spiel 77 / Ziehung', _currency(breakdown.spiel77Amount)),
            _summaryRow('SUPER 6 / Ziehung', _currency(breakdown.super6Amount)),
            _summaryRow('Zwischensumme / Ziehung', _currency(breakdown.subtotalPerDraw)),
            _summaryRow('Gesamtziehungen', '${breakdown.drawCount}'),
            _summaryRow('Zwischensumme gesamt', _currency(breakdown.totalWithoutProcessing)),
            _summaryRow('Bearbeitungsgebühr', _currency(breakdown.processingFee)),
            const Divider(height: 24),
            _summaryRow('Gesamtpreis', _currency(breakdown.total), emphasize: true),
          ],
        ),
      ),
    );
  }

  Widget _summaryRow(String label, String value, {bool emphasize = false}) {
    final style = emphasize
        ? Theme.of(context).textTheme.titleMedium
        : Theme.of(context).textTheme.bodyLarge;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(label, style: style)),
          Text(value, style: style),
        ],
      ),
    );
  }

  Widget _buildInfoCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text(
              'Hinweise',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 10),
            Text('• Vollsystem 007–010 zeigt die offiziellen Grundpreise pro Ziehung.'),
            SizedBox(height: 4),
            Text('• Spiel 77 und SUPER 6 werden zusätzlich pro Ziehung berechnet.'),
            SizedBox(height: 4),
            Text('• Superzahl ist bereits Bestandteil von LOTTO 6aus49.'),
            SizedBox(height: 4),
            Text('• Die Bearbeitungsgebühr ist hier als Standardwert modelliert und kann später an deine echte Buchungslogik gekoppelt werden.'),
            SizedBox(height: 4),
            Text('• VEW ist hier als vorbereitete Systemfläche eingebaut und kann im nächsten Schritt an deine Analyse-Engine gekoppelt werden.'),
          ],
        ),
      ),
    );
  }
}
