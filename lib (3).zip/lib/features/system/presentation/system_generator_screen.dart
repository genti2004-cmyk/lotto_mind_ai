import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/number_ball.dart';
import '../../../core/widgets/primary_button.dart';
import '../../generator/provider/lotto_app_state.dart';
import 'system_submission_screen.dart';

class SystemGeneratorScreen extends StatefulWidget {
  const SystemGeneratorScreen({super.key});

  @override
  State<SystemGeneratorScreen> createState() => _SystemGeneratorScreenState();
}

class _SystemGeneratorScreenState extends State<SystemGeneratorScreen> {
  int _step = 0;

  Future<void> _showMessage(String message) async {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _generateSystem() async {
    try {
      await context.read<LottoAppState>().generateSystemTip();
      if (!mounted) return;
      final rows = context.read<LottoAppState>().systemRows.length;
      await _showMessage('$rows Systemreihen wurden erzeugt.');
    } catch (e) {
      await _showMessage(e.toString());
    }
  }

  Future<void> _saveRows() async {
    try {
      final added = await context.read<LottoAppState>().saveSystemRowsAsTips();
      await _showMessage('$added Systemreihen wurden gespeichert.');
    } catch (e) {
      await _showMessage(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Systeme'),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
          children: [
            const _HeaderCard(),
            const SizedBox(height: 14),
            _StepTabs(
              step: _step,
              onChanged: (value) {
                setState(() {
                  _step = value;
                });
              },
            ),
            const SizedBox(height: 14),
            if (_step == 0) _SystemStepType(state: state),
            if (_step == 1) _SystemStepNumbers(state: state),
            if (_step == 2)
              _SystemStepResult(
                state: state,
                onGenerate: _generateSystem,
                onSaveRows: state.systemRows.isEmpty ? null : _saveRows,
              ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _step == 0
                        ? null
                        : () {
                      setState(() {
                        _step -= 1;
                      });
                    },
                    icon: const Icon(Icons.arrow_back_rounded),
                    label: const Text('Zurück'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _step == 2
                        ? null
                        : () {
                      setState(() {
                        _step += 1;
                      });
                    },
                    icon: const Icon(Icons.arrow_forward_rounded),
                    label: const Text('Weiter'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _HeaderCard extends StatelessWidget {
  const _HeaderCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.primary, AppColors.primaryDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(26),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowMedium,
            blurRadius: 16,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Systemgenerator',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w900,
              color: Colors.white,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Vollsystem und VEW in klaren drei Schritten: Typ wählen, Basiszahlen festlegen, Reihen erzeugen und zur Abgabe weitergehen.',
            style: TextStyle(
              fontSize: 12.5,
              height: 1.45,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}

class _StepTabs extends StatelessWidget {
  final int step;
  final ValueChanged<int> onChanged;

  const _StepTabs({
    required this.step,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    const labels = ['1. Typ', '2. Zahlen', '3. Ergebnis'];

    return Row(
      children: List.generate(labels.length, (index) {
        final selected = step == index;
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: index == labels.length - 1 ? 0 : 8),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => onChanged(index),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  gradient: selected
                      ? const LinearGradient(
                    colors: [AppColors.primary, AppColors.primaryDark],
                  )
                      : null,
                  color: selected ? null : AppColors.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.border),
                ),
                child: Center(
                  child: Text(
                    labels[index],
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: selected ? Colors.white : AppColors.textSecondary,
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}

class _SystemStepType extends StatelessWidget {
  final LottoAppState state;

  const _SystemStepType({
    required this.state,
  });

  @override
  Widget build(BuildContext context) {
    return _SectionCard(
      title: 'Systemart und Größe',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: _ChoiceButton(
                  label: 'Vollsystem',
                  selected: state.systemPlayType == SystemPlayType.full,
                  onTap: () => context.read<LottoAppState>().setSystemPlayType(
                    SystemPlayType.full,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _ChoiceButton(
                  label: 'VEW',
                  selected: state.systemPlayType == SystemPlayType.vew,
                  onTap: () => context.read<LottoAppState>().setSystemPlayType(
                    SystemPlayType.vew,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _InfoLine(
            label: 'Systemart',
            value: state.systemPlayTypeLabel,
          ),
          const SizedBox(height: 8),
          _InfoLine(
            label: 'Systemgröße',
            value: '${state.selectedSystemSize} Zahlen',
          ),
          const SizedBox(height: 12),
          Slider(
            value: state.selectedSystemSize.toDouble(),
            min: 7,
            max: 16,
            divisions: 9,
            label: '${state.selectedSystemSize}',
            onChanged: (value) {
              context.read<LottoAppState>().setSelectedSystemSize(value.round());
            },
          ),
          const SizedBox(height: 6),
          const Text(
            'Empfehlung: Vollsystem eher klein halten, VEW für größere Systeme nutzen.',
            style: TextStyle(
              fontSize: 11.5,
              fontWeight: FontWeight.w600,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

class _SystemStepNumbers extends StatelessWidget {
  final LottoAppState state;

  const _SystemStepNumbers({
    required this.state,
  });

  @override
  Widget build(BuildContext context) {
    return _SectionCard(
      title: 'Manuelle Basiszahlen',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _InfoLine(
            label: 'Gewählt',
            value: state.manualSystemNumbers.isEmpty
                ? 'Noch keine Zahlen'
                : state.manualSystemNumbers.join(' • '),
          ),
          const SizedBox(height: 8),
          _InfoLine(
            label: 'Freie Plätze',
            value: '${state.remainingManualSystemSlots}',
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: List.generate(49, (index) {
              final number = index + 1;
              final selected = state.manualSystemNumbers.contains(number);
              final disabled = !selected &&
                  state.manualSystemNumbers.length >= state.selectedSystemSize;

              return _SelectableNumberChip(
                number: number,
                selected: selected,
                disabled: disabled,
                onTap: () async {
                  try {
                    await context
                        .read<LottoAppState>()
                        .toggleManualSystemNumber(number);
                  } catch (_) {}
                },
              );
            }),
          ),
          const SizedBox(height: 14),
          OutlinedButton.icon(
            onPressed: state.manualSystemNumbers.isEmpty
                ? null
                : () {
              context.read<LottoAppState>().clearManualSystemNumbers();
            },
            icon: const Icon(Icons.backspace_outlined),
            label: const Text('Auswahl leeren'),
          ),
        ],
      ),
    );
  }
}

class _SystemStepResult extends StatelessWidget {
  final LottoAppState state;
  final Future<void> Function() onGenerate;
  final Future<void> Function()? onSaveRows;

  const _SystemStepResult({
    required this.state,
    required this.onGenerate,
    required this.onSaveRows,
  });

  @override
  Widget build(BuildContext context) {
    return _SectionCard(
      title: 'Ergebnis',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          PrimaryButton(
            label: 'Systemreihen berechnen',
            icon: Icons.grid_view_rounded,
            onPressed: onGenerate,
          ),
          const SizedBox(height: 10),
          PrimaryButton(
            label: 'Systemreihen speichern',
            icon: Icons.save_alt_rounded,
            onPressed: onSaveRows,
          ),
          const SizedBox(height: 10),
          PrimaryButton(
            label: 'Zur Abgabe',
            icon: Icons.send_rounded,
            onPressed: state.systemRows.isEmpty
                ? null
                : () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const SystemSubmissionScreen(),
                ),
              );
            },
          ),
          const SizedBox(height: 14),
          _InfoLine(
            label: 'Basiszahlen',
            value: state.systemBaseNumbers.isEmpty
                ? '-'
                : state.systemBaseNumbers.join(' • '),
          ),
          const SizedBox(height: 8),
          _InfoLine(
            label: 'Reihen',
            value: '${state.systemRows.length}',
          ),
          const SizedBox(height: 14),
          if (!state.hasSystemRows)
            const Text(
              'Noch keine Systemreihen erzeugt.',
              style: TextStyle(
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w600,
              ),
            )
          else
            ...state.systemRows.take(10).toList().asMap().entries.map((entry) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 28,
                      child: Text(
                        '${entry.key + 1}.',
                        style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: entry.value
                            .map((n) => NumberBall(number: n))
                            .toList(),
                      ),
                    ),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final String title;
  final Widget child;

  const _SectionCard({
    required this.title,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowLight,
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class _ChoiceButton extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _ChoiceButton({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          gradient: selected
              ? const LinearGradient(
            colors: [AppColors.primary, AppColors.primaryDark],
          )
              : null,
          color: selected ? null : AppColors.surfaceSoft,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: selected ? Colors.white : AppColors.textSecondary,
            ),
          ),
        ),
      ),
    );
  }
}

class _SelectableNumberChip extends StatelessWidget {
  final int number;
  final bool selected;
  final bool disabled;
  final VoidCallback onTap;

  const _SelectableNumberChip({
    required this.number,
    required this.selected,
    required this.disabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final active = selected;
    final inactive = disabled;

    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: inactive ? null : onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        width: 42,
        height: 42,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: active
              ? const LinearGradient(
            colors: [AppColors.primary, AppColors.primaryDark],
          )
              : null,
          color: active
              ? null
              : inactive
              ? Colors.grey.shade200
              : Colors.white,
          border: Border.all(
            color: active ? AppColors.primaryDark : AppColors.border,
          ),
        ),
        child: Text(
          '$number',
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w800,
            color: active
                ? Colors.white
                : inactive
                ? Colors.grey
                : AppColors.textPrimary,
          ),
        ),
      ),
    );
  }
}

class _InfoLine extends StatelessWidget {
  final String label;
  final String value;

  const _InfoLine({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 90,
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: AppColors.textSecondary,
            ),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
        ),
      ],
    );
  }
}