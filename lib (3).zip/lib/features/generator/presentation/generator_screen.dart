import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/number_ball.dart';
import '../../../core/widgets/primary_button.dart';
import '../../analysis/presentation/ai_max_mode_screen.dart';
import '../../analysis/presentation/win_simulation_screen.dart';
import '../../generator/provider/lotto_app_state.dart';
import '../../system/presentation/system_generator_screen.dart';

class GeneratorScreen extends StatefulWidget {
  const GeneratorScreen({super.key});

  @override
  State<GeneratorScreen> createState() => _GeneratorScreenState();
}

class _GeneratorScreenState extends State<GeneratorScreen> {
  int _tabIndex = 0;
  late final PageController _pageController;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: _tabIndex);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _goToTab(int index) {
    setState(() {
      _tabIndex = index;
    });
    _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOut,
    );
  }

  Future<void> _showMessage(String message) async {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _generateRandom() async {
    await context.read<LottoAppState>().generateRandomTip();
    await _showMessage('Zufallstipp wurde erstellt.');
  }

  Future<void> _saveLastTip() async {
    await context.read<LottoAppState>().saveLastTip(source: 'manual');
    await _showMessage('Tipp wurde gespeichert.');
  }

  Future<void> _generateAnalysis() async {
    try {
      await context.read<LottoAppState>().generateAnalysisTip();
      await _showMessage('Analyse-Tipp wurde erstellt.');
    } catch (e) {
      await _showMessage(e.toString());
    }
  }

  Future<void> _applyBestTip() async {
    await context.read<LottoAppState>().applyBestAnalyzedTip();
    await _showMessage('AI Pro Tipp wurde übernommen.');
  }

  Future<void> _copyLastTip() async {
    final state = context.read<LottoAppState>();
    final tip = state.lastGeneratedTip;
    final superNumber = state.lastGeneratedSuperNumber;

    if (tip == null || tip.isEmpty) {
      await _showMessage('Noch kein Tipp vorhanden.');
      return;
    }

    final text = superNumber == null
        ? tip.join(', ')
        : '${tip.join(', ')} | SZ: $superNumber';

    await Clipboard.setData(ClipboardData(text: text));
    await _showMessage('Tipp wurde kopiert.');
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();
    final summary = state.analysisSummary;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
          child: Column(
            children: [
              const _GlassHeader(),
              const SizedBox(height: 14),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                alignment: WrapAlignment.center,
                children: [
                  _TopMetricCard(
                    title: 'Ziehungen',
                    value: '${summary.drawCount}',
                    icon: Icons.dataset_rounded,
                  ),
                  _TopMetricCard(
                    title: 'Profil',
                    value: state.analysisProfileLabel,
                    icon: Icons.psychology_alt_rounded,
                  ),
                  _TopMetricCard(
                    title: 'Qualität',
                    value: state.analysisStrengthLabel,
                    icon: Icons.insights_rounded,
                  ),
                ],
              ),
              const SizedBox(height: 14),
              _GeneratorModeTabs(
                index: _tabIndex,
                onChanged: _goToTab,
              ),
              const SizedBox(height: 14),
              Expanded(
                child: PageView(
                  controller: _pageController,
                  onPageChanged: (value) {
                    setState(() {
                      _tabIndex = value;
                    });
                  },
                  children: [
                    _GeneratorTabPage(
                      child: _NormalPanel(
                        state: state,
                        onGenerate: _generateRandom,
                        onSave:
                        state.lastGeneratedTip == null ? null : _saveLastTip,
                        onCopy:
                        state.lastGeneratedTip == null ? null : _copyLastTip,
                      ),
                      currentTip: _CurrentTipPanel(
                        state: state,
                        onSave:
                        state.lastGeneratedTip == null ? null : _saveLastTip,
                        onCopy:
                        state.lastGeneratedTip == null ? null : _copyLastTip,
                      ),
                    ),
                    _GeneratorTabPage(
                      child: _AiPanel(
                        state: state,
                        onGenerate: _generateAnalysis,
                        onApplyBest: state.bestAnalyzedTip.length == 6
                            ? _applyBestTip
                            : null,
                      ),
                      currentTip: _CurrentTipPanel(
                        state: state,
                        onSave:
                        state.lastGeneratedTip == null ? null : _saveLastTip,
                        onCopy:
                        state.lastGeneratedTip == null ? null : _copyLastTip,
                      ),
                    ),
                    _GeneratorTabPage(
                      child: _JackpotPanel(
                        state: state,
                        onGenerate: _generateAnalysis,
                        onApplyBest: state.bestAnalyzedTip.length == 6
                            ? _applyBestTip
                            : null,
                      ),
                      currentTip: _CurrentTipPanel(
                        state: state,
                        onSave:
                        state.lastGeneratedTip == null ? null : _saveLastTip,
                        onCopy:
                        state.lastGeneratedTip == null ? null : _copyLastTip,
                      ),
                    ),
                    _GeneratorTabPage(
                      child: _SystemEntryPanel(
                        state: state,
                      ),
                      currentTip: _CurrentTipPanel(
                        state: state,
                        onSave:
                        state.lastGeneratedTip == null ? null : _saveLastTip,
                        onCopy:
                        state.lastGeneratedTip == null ? null : _copyLastTip,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _GeneratorTabPage extends StatelessWidget {
  final Widget child;
  final Widget currentTip;

  const _GeneratorTabPage({
    required this.child,
    required this.currentTip,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        child,
        const SizedBox(height: 14),
        currentTip,
        const SizedBox(height: 8),
      ],
    );
  }
}

class _GlassHeader extends StatelessWidget {
  const _GlassHeader();

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.white.withOpacity(0.90),
                Colors.white.withOpacity(0.72),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Colors.white.withOpacity(0.65)),
            boxShadow: const [
              BoxShadow(
                color: AppColors.shadowLight,
                blurRadius: 18,
                offset: Offset(0, 10),
              ),
            ],
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'LottoMind AI',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  color: AppColors.textPrimary,
                ),
              ),
              SizedBox(height: 6),
              Text(
                'Generator für Zufall, AI-Analyse, Jackpot-Flow und Systemspiele.',
                style: TextStyle(
                  fontSize: 13,
                  height: 1.4,
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _GeneratorModeTabs extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;

  const _GeneratorModeTabs({
    required this.index,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    const labels = ['Normal', 'AI', 'Jackpot', 'System'];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: List.generate(labels.length, (i) {
          final selected = i == index;
          return Padding(
            padding: EdgeInsets.only(right: i == labels.length - 1 ? 0 : 8),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => onChanged(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding:
                const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                decoration: BoxDecoration(
                  gradient: selected
                      ? const LinearGradient(
                    colors: [AppColors.primary, AppColors.primaryDark],
                  )
                      : null,
                  color: selected ? null : AppColors.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.border),
                ),
                child: Text(
                  labels[i],
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: selected ? Colors.white : AppColors.textSecondary,
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _TopMetricCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _TopMetricCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 108,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: AppColors.border),
          boxShadow: const [
            BoxShadow(
              color: AppColors.shadowLight,
              blurRadius: 14,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          children: [
            Icon(icon, color: AppColors.primary, size: 20),
            const SizedBox(height: 10),
            Text(
              value,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PanelCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;

  const _PanelCard({
    required this.title,
    required this.subtitle,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowLight,
            blurRadius: 16,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            style: const TextStyle(
              fontSize: 12,
              height: 1.4,
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class _SubCard extends StatelessWidget {
  final String title;
  final Widget child;

  const _SubCard({
    required this.title,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surfaceSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }
}

class _NormalPanel extends StatelessWidget {
  final LottoAppState state;
  final Future<void> Function() onGenerate;
  final Future<void> Function()? onSave;
  final Future<void> Function()? onCopy;

  const _NormalPanel({
    required this.state,
    required this.onGenerate,
    required this.onSave,
    required this.onCopy,
  });

  @override
  Widget build(BuildContext context) {
    return _PanelCard(
      title: 'Normal',
      subtitle: 'Schneller Zufallstipp ohne Analyse-Filter.',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Ideal für schnelles Generieren und direktes Speichern.',
            style: TextStyle(
              fontSize: 12,
              height: 1.4,
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 14),
          PrimaryButton(
            label: 'Zufallstipp generieren',
            icon: Icons.casino_rounded,
            onPressed: onGenerate,
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              SizedBox(
                width: 180,
                child: PrimaryButton(
                  label: 'Speichern',
                  icon: Icons.bookmark_add_rounded,
                  onPressed: onSave,
                ),
              ),
              SizedBox(
                width: 180,
                child: OutlinedButton.icon(
                  onPressed: onCopy,
                  icon: const Icon(Icons.copy_rounded),
                  label: const Text('Kopieren'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _AiPanel extends StatelessWidget {
  final LottoAppState state;
  final Future<void> Function() onGenerate;
  final Future<void> Function()? onApplyBest;

  const _AiPanel({
    required this.state,
    required this.onGenerate,
    required this.onApplyBest,
  });

  @override
  Widget build(BuildContext context) {
    final ai = state.analysisAiSummary;
    final bestTip = state.bestAnalyzedTip;
    final lastSimulation = state.bestCurrentTipWindow?.summary;
    final bestSimulation = state.bestAiTipWindow?.summary;

    return _PanelCard(
      title: 'AI',
      subtitle: 'Analysezeitraum, Profil, AI Bewertung und AI Pro.',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SubCard(
            title: 'Analyse-Steuerung',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const _ControlLabel('Ziehungstag'),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _ChoiceButton(
                      label: 'Beide',
                      selected:
                      state.analysisDrawFilter == AnalysisDrawFilter.all,
                      onTap: () =>
                          context.read<LottoAppState>().setAnalysisDrawFilter(
                            AnalysisDrawFilter.all,
                          ),
                    ),
                    _ChoiceButton(
                      label: 'Mittwoch',
                      selected: state.analysisDrawFilter ==
                          AnalysisDrawFilter.wednesday,
                      onTap: () =>
                          context.read<LottoAppState>().setAnalysisDrawFilter(
                            AnalysisDrawFilter.wednesday,
                          ),
                    ),
                    _ChoiceButton(
                      label: 'Samstag',
                      selected: state.analysisDrawFilter ==
                          AnalysisDrawFilter.saturday,
                      onTap: () =>
                          context.read<LottoAppState>().setAnalysisDrawFilter(
                            AnalysisDrawFilter.saturday,
                          ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                const _ControlLabel('Analyse-Ziehungen'),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    _StepButton(
                      label: '-10',
                      onTap: () {
                        final s = context.read<LottoAppState>();
                        final next = s.analysisDrawCount - 10 < 1
                            ? 1
                            : s.analysisDrawCount - 10;
                        s.setAnalysisDrawCount(next);
                      },
                    ),
                    _StepButton(
                      label: '-1',
                      onTap: () {
                        final s = context.read<LottoAppState>();
                        final next = s.analysisDrawCount - 1 < 1
                            ? 1
                            : s.analysisDrawCount - 1;
                        s.setAnalysisDrawCount(next);
                      },
                    ),
                    SizedBox(
                      width: 220,
                      child: Slider(
                        value: state.analysisDrawCount.toDouble(),
                        min: 1,
                        max: state.maxAnalysisDrawCount.toDouble(),
                        divisions: state.maxAnalysisDrawCount > 1
                            ? state.maxAnalysisDrawCount - 1
                            : 1,
                        label: '${state.analysisDrawCount}',
                        onChanged: (value) {
                          context.read<LottoAppState>().setAnalysisDrawCount(
                            value.round(),
                          );
                        },
                      ),
                    ),
                    _StepButton(
                      label: '+1',
                      onTap: () {
                        final s = context.read<LottoAppState>();
                        final next = s.analysisDrawCount + 1 >
                            s.maxAnalysisDrawCount
                            ? s.maxAnalysisDrawCount
                            : s.analysisDrawCount + 1;
                        s.setAnalysisDrawCount(next);
                      },
                    ),
                    _StepButton(
                      label: '+10',
                      onTap: () {
                        final s = context.read<LottoAppState>();
                        final next = s.analysisDrawCount + 10 >
                            s.maxAnalysisDrawCount
                            ? s.maxAnalysisDrawCount
                            : s.analysisDrawCount + 10;
                        s.setAnalysisDrawCount(next);
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    SizedBox(
                      width: 180,
                      child: OutlinedButton.icon(
                        onPressed: () {
                          context.read<LottoAppState>().setAnalysisToRecent52();
                        },
                        icon: const Icon(Icons.history_rounded),
                        label: const Text('Letzte 52'),
                      ),
                    ),
                    SizedBox(
                      width: 180,
                      child: OutlinedButton.icon(
                        onPressed: () {
                          context.read<LottoAppState>().setAnalysisToAllHistory();
                        },
                        icon: const Icon(Icons.all_inclusive_rounded),
                        label: const Text('Komplett'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                const _ControlLabel('Profil'),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _ChoiceButton(
                      label: 'Defensiv',
                      selected:
                      state.analysisProfile == AnalysisProfile.defensive,
                      onTap: () =>
                          context.read<LottoAppState>().setAnalysisProfile(
                            AnalysisProfile.defensive,
                          ),
                    ),
                    _ChoiceButton(
                      label: 'Mittel',
                      selected:
                      state.analysisProfile == AnalysisProfile.balanced,
                      onTap: () =>
                          context.read<LottoAppState>().setAnalysisProfile(
                            AnalysisProfile.balanced,
                          ),
                    ),
                    _ChoiceButton(
                      label: 'Aggressiv',
                      selected:
                      state.analysisProfile == AnalysisProfile.aggressive,
                      onTap: () =>
                          context.read<LottoAppState>().setAnalysisProfile(
                            AnalysisProfile.aggressive,
                          ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                _InlineInfo(label: 'Fenster', value: state.analysisWindowLabel),
                const SizedBox(height: 6),
                _InlineInfo(
                  label: 'Ziehungen',
                  value: '${state.analysisDrawCount}',
                ),
                const SizedBox(height: 6),
                _InlineInfo(
                  label: 'Qualität',
                  value: state.analysisStrengthLabel,
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          PrimaryButton(
            label: 'Analyse-Tipp berechnen',
            icon: Icons.auto_awesome_rounded,
            onPressed: onGenerate,
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              SizedBox(
                width: 180,
                child: PrimaryButton(
                  label: 'AI Max Mode',
                  icon: Icons.psychology_alt_rounded,
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const AiMaxModeScreen(),
                      ),
                    );
                  },
                ),
              ),
              SizedBox(
                width: 180,
                child: PrimaryButton(
                  label: 'Gewinnsimulation',
                  icon: Icons.query_stats_rounded,
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const WinSimulationScreen(),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _SubCard(
            title: 'AI Bewertung',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _InlineInfo(label: 'Titel', value: ai.title),
                const SizedBox(height: 6),
                _InlineInfo(label: 'Confidence', value: ai.confidence),
                const SizedBox(height: 12),
                _ConfidenceBar(confidenceText: ai.confidence),
                const SizedBox(height: 12),
                _BallRow(title: 'Empfohlen', numbers: ai.recommendedNumbers),
                const SizedBox(height: 12),
                _BallRow(title: 'Eher meiden', numbers: ai.avoidNumbers),
                const SizedBox(height: 12),
                Text(
                  ai.reasoning,
                  style: const TextStyle(
                    fontSize: 12,
                    height: 1.4,
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _SubCard(
            title: 'AI Pro Bewertung',
            child: bestTip.length != 6
                ? const Text(
              'Noch kein AI Pro Tipp verfügbar.',
              style: TextStyle(
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w600,
              ),
            )
                : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _BallRow(title: 'Bester Tipp', numbers: bestTip),
                if (bestSimulation != null) ...[
                  const SizedBox(height: 12),
                  _SimulationSummaryCard(
                    title: 'Rücktest AI Pro',
                    simulation: bestSimulation,
                  ),
                ],
                const SizedBox(height: 12),
                PrimaryButton(
                  label: 'AI Pro Tipp übernehmen',
                  icon: Icons.download_done_rounded,
                  onPressed: onApplyBest,
                ),
                if (lastSimulation != null) ...[
                  const SizedBox(height: 12),
                  _SimulationSummaryCard(
                    title: 'Rücktest aktueller Tipp',
                    simulation: lastSimulation,
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _JackpotPanel extends StatelessWidget {
  final LottoAppState state;
  final Future<void> Function() onGenerate;
  final Future<void> Function()? onApplyBest;

  const _JackpotPanel({
    required this.state,
    required this.onGenerate,
    required this.onApplyBest,
  });

  @override
  Widget build(BuildContext context) {
    return _PanelCard(
      title: 'Jackpot',
      subtitle:
      'Aggressiverer Flow für seltenere Chancen und AI-gestützte Auswahl.',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _JackpotModeInfo(),
          const SizedBox(height: 14),
          _SubCard(
            title: 'Jackpot Fokus',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Diese Ansicht betont einen aggressiveren, jackpot-orientierten Flow. Sie nutzt deinen vorhandenen AI- und Analysekern, ohne zusätzlichen instabilen Sonder-State.',
                  style: TextStyle(
                    fontSize: 12,
                    height: 1.45,
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 12),
                _InlineInfo(
                  label: 'Strategie',
                  value: 'AI Analyse + AI Pro + Gewinnsimulation',
                ),
                const SizedBox(height: 6),
                _InlineInfo(
                  label: 'Ziel',
                  value: 'aggressiver, chancenorientierter Spielstil',
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          PrimaryButton(
            label: 'Jackpot Tipp berechnen',
            icon: Icons.local_fire_department_rounded,
            onPressed: onGenerate,
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              SizedBox(
                width: 180,
                child: PrimaryButton(
                  label: 'AI Max Mode öffnen',
                  icon: Icons.bolt_rounded,
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const AiMaxModeScreen(),
                      ),
                    );
                  },
                ),
              ),
              SizedBox(
                width: 180,
                child: PrimaryButton(
                  label: 'Gewinnsimulation',
                  icon: Icons.query_stats_rounded,
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const WinSimulationScreen(),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
          if (state.bestAnalyzedTip.length == 6) ...[
            const SizedBox(height: 14),
            _SubCard(
              title: 'Jackpot Kandidat',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _BallRow(
                    title: 'AI Pro Kandidat',
                    numbers: state.bestAnalyzedTip,
                  ),
                  const SizedBox(height: 12),
                  PrimaryButton(
                    label: 'Kandidaten übernehmen',
                    icon: Icons.download_done_rounded,
                    onPressed: onApplyBest,
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _SystemEntryPanel extends StatelessWidget {
  final LottoAppState state;

  const _SystemEntryPanel({
    required this.state,
  });

  @override
  Widget build(BuildContext context) {
    return _PanelCard(
      title: 'System',
      subtitle: 'VEW und Vollsystem als eigener strukturierter Bereich.',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SubCard(
            title: 'Warum eigener Bereich?',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _InlineInfo(label: 'Systemart', value: state.systemPlayTypeLabel),
                const SizedBox(height: 6),
                _InlineInfo(
                  label: 'Systemgröße',
                  value: '${state.selectedSystemSize}',
                ),
                const SizedBox(height: 6),
                _InlineInfo(
                  label: 'Manuell',
                  value: state.manualSystemNumbers.isEmpty
                      ? '-'
                      : state.manualSystemNumbers.join(' • '),
                ),
                const SizedBox(height: 6),
                _InlineInfo(label: 'Reihen', value: '${state.systemRows.length}'),
              ],
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            'Systeme haben jetzt einen eigenen sauberen Flow: wählen → Zahlen setzen → erzeugen → Abgabe → PDF.',
            style: TextStyle(
              fontSize: 12,
              height: 1.45,
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 14),
          PrimaryButton(
            label: 'Zum Systembereich',
            icon: Icons.grid_view_rounded,
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const SystemGeneratorScreen(),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _CurrentTipPanel extends StatelessWidget {
  final LottoAppState state;
  final Future<void> Function()? onSave;
  final Future<void> Function()? onCopy;

  const _CurrentTipPanel({
    required this.state,
    required this.onSave,
    required this.onCopy,
  });

  @override
  Widget build(BuildContext context) {
    final tip = state.lastGeneratedTip;
    final superNumber = state.lastGeneratedSuperNumber;
    final lastSimulation = state.bestCurrentTipWindow?.summary;

    return _PanelCard(
      title: 'Aktueller Tipp',
      subtitle: 'Der zuletzt erzeugte Tipp mit direkter Bewertung.',
      child: tip == null || tip.isEmpty
          ? const Text(
        'Noch kein Tipp generiert.',
        style: TextStyle(
          color: AppColors.textSecondary,
          fontWeight: FontWeight.w600,
        ),
      )
          : Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _BallRow(title: 'Zahlen', numbers: tip),
          const SizedBox(height: 10),
          _InlineInfo(
            label: 'Superzahl',
            value: superNumber?.toString() ?? '-',
          ),
          if (lastSimulation != null) ...[
            const SizedBox(height: 12),
            _SimulationSummaryCard(
              title: 'Gewinn-Anzeige',
              simulation: lastSimulation,
            ),
          ],
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              SizedBox(
                width: 180,
                child: PrimaryButton(
                  label: 'Speichern',
                  icon: Icons.bookmark_add_rounded,
                  onPressed: onSave,
                ),
              ),
              SizedBox(
                width: 180,
                child: OutlinedButton.icon(
                  onPressed: onCopy,
                  icon: const Icon(Icons.copy_rounded),
                  label: const Text('Kopieren'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SimulationSummaryCard extends StatelessWidget {
  final String title;
  final dynamic simulation;

  const _SimulationSummaryCard({
    required this.title,
    required this.simulation,
  });

  num _numValue(String field, [num fallback = 0]) {
    try {
      final dynamic value;
      switch (field) {
        case 'weightedScore':
          value = simulation.weightedScore;
          break;
        case 'estimatedEuroTotalValue':
          value = simulation.estimatedEuroTotalValue;
          break;
        case 'totalDraws':
          value = simulation.totalDraws;
          break;
        case 'hit3':
          value = simulation.hit3;
          break;
        case 'hit4':
          value = simulation.hit4;
          break;
        case 'hit5':
          value = simulation.hit5;
          break;
        case 'hit6':
          value = simulation.hit6;
          break;
        default:
          value = fallback;
      }
      return value is num ? value : fallback;
    } catch (_) {
      return fallback;
    }
  }

  int _hitFromDistribution(int hit) {
    try {
      final map = simulation.hitDistribution;
      if (map is Map<int, int>) return map[hit] ?? 0;
      if (map is Map) {
        final value = map[hit];
        return value is int ? value : 0;
      }
      return 0;
    } catch (_) {
      return 0;
    }
  }

  String _riskLabel(num score) {
    if (score >= 12) return 'Niedriger';
    if (score >= 6) return 'Mittel';
    return 'Höher';
  }

  @override
  Widget build(BuildContext context) {
    final euro = _numValue('estimatedEuroTotalValue', 0).toDouble();
    final draws = _numValue('totalDraws', 0).toInt();
    final weighted = _numValue('weightedScore', 0).toDouble();

    final hit3 = _numValue('hit3', _hitFromDistribution(3)).toInt();
    final hit4 = _numValue('hit4', _hitFromDistribution(4)).toInt();
    final hit5 = _numValue('hit5', _hitFromDistribution(5)).toInt();
    final hit6 = _numValue('hit6', _hitFromDistribution(6)).toInt();

    final avg = draws > 0 ? euro / draws : 0.0;

    return _SubCard(
      title: title,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _InlineInfo(
            label: 'Modellwert',
            value: '${euro.toStringAsFixed(2).replaceAll('.', ',')} €',
          ),
          const SizedBox(height: 6),
          _InlineInfo(
            label: 'Ø pro Ziehung',
            value: '${avg.toStringAsFixed(2).replaceAll('.', ',')} €',
          ),
          const SizedBox(height: 6),
          _InlineInfo(label: 'Risiko', value: _riskLabel(weighted)),
          const SizedBox(height: 6),
          _InlineInfo(
            label: 'Treffer-Score',
            value: weighted.toStringAsFixed(1),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _HitPill(label: '3er', value: '$hit3'),
              _HitPill(label: '4er', value: '$hit4'),
              _HitPill(label: '5er', value: '$hit5'),
              _HitPill(label: '6er', value: '$hit6'),
            ],
          ),
        ],
      ),
    );
  }
}

class _HitPill extends StatelessWidget {
  final String label;
  final String value;

  const _HitPill({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColors.border),
      ),
      child: Text(
        '$label: $value',
        style: const TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w800,
          color: AppColors.textPrimary,
        ),
      ),
    );
  }
}

class _ControlLabel extends StatelessWidget {
  final String text;

  const _ControlLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w800,
        color: AppColors.textSecondary,
      ),
    );
  }
}

class _ChoiceButton extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _ChoiceButton({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          gradient: selected
              ? const LinearGradient(
            colors: [AppColors.primary, AppColors.primaryDark],
          )
              : null,
          color: selected ? null : AppColors.surfaceSoft,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? Colors.transparent : AppColors.border,
          ),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w800,
            color: selected ? Colors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }
}

class _StepButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _StepButton({
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 36,
      child: OutlinedButton(
        onPressed: onTap,
        child: Text(label),
      ),
    );
  }
}

class _InlineInfo extends StatelessWidget {
  final String label;
  final String value;

  const _InlineInfo({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 260) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  fontSize: 12,
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 12,
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          );
        }

        return Row(
          children: [
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  fontSize: 12,
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Flexible(
              child: Text(
                value,
                textAlign: TextAlign.right,
                style: const TextStyle(
                  fontSize: 12,
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _BallRow extends StatelessWidget {
  final String title;
  final List<int> numbers;

  const _BallRow({
    required this.title,
    required this.numbers,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 12,
            color: AppColors.textSecondary,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: numbers.map((n) => NumberBall(number: n)).toList(),
        ),
      ],
    );
  }
}

class _ConfidenceBar extends StatelessWidget {
  final String confidenceText;

  const _ConfidenceBar({
    required this.confidenceText,
  });

  @override
  Widget build(BuildContext context) {
    double value;
    if (confidenceText.toLowerCase().contains('sehr')) {
      value = 1.0;
    } else if (confidenceText.toLowerCase().contains('stark')) {
      value = 0.8;
    } else if (confidenceText.toLowerCase().contains('mittel')) {
      value = 0.6;
    } else if (confidenceText.toLowerCase().contains('begrenzt')) {
      value = 0.35;
    } else {
      value = 0.18;
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(999),
      child: LinearProgressIndicator(
        value: value,
        minHeight: 10,
        backgroundColor: AppColors.surfaceSoft,
      ),
    );
  }
}

class _JackpotModeInfo extends StatelessWidget {
  const _JackpotModeInfo();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.deepOrange.withOpacity(0.08),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Colors.deepOrange.withOpacity(0.25),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          Icon(
            Icons.local_fire_department_rounded,
            color: Colors.deepOrange,
            size: 22,
          ),
          SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Jackpot Fokus',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    color: Colors.deepOrange,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Diese Ansicht betont einen aggressiveren, jackpot-orientierten Flow. Sie nutzt deinen vorhandenen AI- und Analysekern, ohne zusätzlichen instabilen Sonder-State.',
                  style: TextStyle(
                    fontSize: 12,
                    height: 1.4,
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}