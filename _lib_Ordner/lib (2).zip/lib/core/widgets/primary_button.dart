import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class PrimaryButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;

  const PrimaryButton({
    super.key,
    required this.label,
    this.icon,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    final isDisabled = onPressed == null;

    final child = icon == null
        ? Text(label)
        : Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, size: 18),
        const SizedBox(width: 8),
        Text(label),
      ],
    );

    return GestureDetector(
      onTap: onPressed,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        height: 54,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: isDisabled
              ? null
              : const LinearGradient(
            colors: [
              AppColors.primary,
              AppColors.primaryDark,
            ],
          ),
          color: isDisabled ? AppColors.border : null,
          boxShadow: isDisabled
              ? []
              : const [
            BoxShadow(
              color: Color(0x1A2563EB),
              blurRadius: 14,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: DefaultTextStyle(
          style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w800,
            color: isDisabled ? AppColors.textMuted : Colors.white,
          ),
          child: child,
        ),
      ),
    );
  }
}