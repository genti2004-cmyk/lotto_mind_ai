import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/number_ball.dart';
import '../../../core/widgets/primary_button.dart';
import '../provider/lotto_app_state.dart';
import '../../analysis/presentation/ai_max_mode_screen.dart';

class GeneratorScreen extends StatefulWidget {
  const GeneratorScreen({super.key});

  @override
  State<GeneratorScreen> createState() => _GeneratorScreenState();
}

class _GeneratorScreenState extends State<GeneratorScreen> {
  int _tabIndex = 0;
  int _systemStep = 0;

  Future<void> _showMessage(String message) async {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _generateRandom() async {
    await context.read<LottoAppState>().generateRandomTip();
    await _showMessage('Zufallstipp wurde erstellt.');
  }

  Future<void> _saveLastTip() async {
    await context.read<LottoAppState>().saveLastTip(source: 'manual');
    await _showMessage('Tipp wurde gespeichert.');
  }

  Future<void> _generateAnalysis() async {
    try {
      await context.read<LottoAppState>().generateAnalysisTip();
      await _showMessage('Analyse-Tipp wurde erstellt.');
    } catch (e) {
      await _showMessage(e.toString());
    }
  }

  Future<void> _applyBestTip() async {
    await context.read<LottoAppState>().applyBestAnalyzedTip();
    await _showMessage('AI Pro Tipp wurde übernommen.');
  }

  Future<void> _generateSystem() async {
    try {
      await context.read<LottoAppState>().generateSystemTip();
      if (!mounted) return;
      final rows = context.read<LottoAppState>().systemRows.length;
      await _showMessage('$rows Systemreihen wurden erzeugt.');
    } catch (e) {
      await _showMessage(e.toString());
    }
  }

  Future<void> _saveSystemRows() async {
    final added = await context.read<LottoAppState>().saveSystemRowsAsTips();
    await _showMessage('$added Systemreihen wurden gespeichert.');
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();
    final summary = state.analysisSummary;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
              sliver: SliverList(
                delegate: SliverChildListDelegate(
                  [
                    const _GlassHeader(),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(
                          child: _TopMetricCard(
                            title: 'Ziehungen',
                            value: '${summary.drawCount}',
                            icon: Icons.dataset_rounded,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _TopMetricCard(
                            title: 'Profil',
                            value: state.analysisProfileLabel,
                            icon: Icons.psychology_alt_rounded,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _TopMetricCard(
                            title: 'Qualität',
                            value: state.analysisStrengthLabel,
                            icon: Icons.insights_rounded,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    _SegmentTabs(
                      index: _tabIndex,
                      onChanged: (value) {
                        setState(() {
                          _tabIndex = value;
                        });
                      },
                    ),
                    const SizedBox(height: 14),
                    if (_tabIndex == 0)
                      _RandomPanel(
                        lastTip: state.lastGeneratedTip,
                        onGenerate: _generateRandom,
                        onSave: state.lastGeneratedTip == null ? null : _saveLastTip,
                      ),
                    if (_tabIndex == 1)
                      _AnalysisPanel(
                        state: state,
                        onGenerate: _generateAnalysis,
                        onApplyBest: state.bestAnalyzedTip.length == 6
                            ? _applyBestTip
                            : null,
                      ),
                    if (_tabIndex == 2)
                      _SystemPanel(
                        state: state,
                        step: _systemStep,
                        onStepChanged: (value) {
                          setState(() {
                            _systemStep = value;
                          });
                        },
                        onGenerate: _generateSystem,
                        onSaveRows: state.hasSystemRows ? _saveSystemRows : null,
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GlassHeader extends StatelessWidget {
  const _GlassHeader();

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.white.withOpacity(0.92),
                Colors.white.withOpacity(0.68),
              ],
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Colors.white.withOpacity(0.75)),
            boxShadow: const [
              BoxShadow(
                color: AppColors.shadowLight,
                blurRadius: 20,
                offset: Offset(0, 10),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  gradient: const LinearGradient(
                    colors: [AppColors.primary, AppColors.primaryDark],
                  ),
                ),
                child: const Icon(
                  Icons.auto_graph_rounded,
                  color: Colors.white,
                  size: 26,
                ),
              ),
              const SizedBox(width: 14),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Smart Generator',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'AI Bewertung, AI Pro Tipp und Simulation in einer klaren Premium-Oberfläche.',
                      style: TextStyle(
                        fontSize: 13,
                        height: 1.35,
                        color: AppColors.textSecondary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TopMetricCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _TopMetricCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowLight,
            blurRadius: 14,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: AppColors.primary),
          const SizedBox(height: 14),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            title,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

class _SegmentTabs extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;

  const _SegmentTabs({
    required this.index,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          _SegmentButton(
            label: 'Zufall',
            icon: Icons.casino_rounded,
            selected: index == 0,
            onTap: () => onChanged(0),
          ),
          _SegmentButton(
            label: 'Analyse',
            icon: Icons.auto_awesome_rounded,
            selected: index == 1,
            onTap: () => onChanged(1),
          ),
          _SegmentButton(
            label: 'System',
            icon: Icons.grid_view_rounded,
            selected: index == 2,
            onTap: () => onChanged(2),
          ),
        ],
      ),
    );
  }
}

class _SegmentButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _SegmentButton({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOut,
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          decoration: BoxDecoration(
            gradient: selected
                ? const LinearGradient(
              colors: [AppColors.primary, AppColors.primaryDark],
            )
                : null,
            color: selected ? null : Colors.transparent,
            borderRadius: BorderRadius.circular(16),
            boxShadow: selected
                ? const [
              BoxShadow(
                color: AppColors.shadowMedium,
                blurRadius: 10,
                offset: Offset(0, 4),
              ),
            ]
                : null,
          ),
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  icon,
                  size: 15,
                  color: selected ? Colors.white : AppColors.textSecondary,
                ),
                const SizedBox(width: 6),
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: selected ? Colors.white : AppColors.textSecondary,
                  ),
                ),
                if (selected) ...[
                  const SizedBox(width: 4),
                  const Icon(
                    Icons.check_rounded,
                    size: 14,
                    color: Colors.white,
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _PanelCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;

  const _PanelCard({
    required this.title,
    required this.subtitle,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowLight,
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            style: const TextStyle(
              fontSize: 13,
              height: 1.35,
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 18),
          child,
        ],
      ),
    );
  }
}

class _RandomPanel extends StatelessWidget {
  final List<int>? lastTip;
  final Future<void> Function() onGenerate;
  final Future<void> Function()? onSave;

  const _RandomPanel({
    required this.lastTip,
    required this.onGenerate,
    required this.onSave,
  });

  @override
  Widget build(BuildContext context) {
    return _PanelCard(
      title: 'Zufallsmodus',
      subtitle: 'Schnelle Reihen ohne Regel- und Analysefilter.',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          PrimaryButton(
            label: 'Zufallstipp erzeugen',
            icon: Icons.casino_rounded,
            onPressed: onGenerate,
          ),
          const SizedBox(height: 10),
          PrimaryButton(
            label: 'Aktuelle Reihe speichern',
            icon: Icons.bookmark_add_rounded,
            onPressed: onSave,
          ),
          const SizedBox(height: 18),
          _SubCard(
            title: 'Letzte Reihe',
            child: lastTip == null
                ? const Text(
              'Noch keine Reihe erzeugt.',
              style: TextStyle(
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w600,
              ),
            )
                : Wrap(
              spacing: 8,
              runSpacing: 8,
              children: lastTip!
                  .map((n) => NumberBall(number: n))
                  .toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class _AnalysisPanel extends StatelessWidget {
  final LottoAppState state;
  final Future<void> Function() onGenerate;
  final Future<void> Function()? onApplyBest;

  const _AnalysisPanel({
    required this.state,
    required this.onGenerate,
    required this.onApplyBest,
  });

  @override
  Widget build(BuildContext context) {
    final ai = state.analysisAiSummary;
    final bestTip = state.bestAnalyzedTip;
    final lastSimulation = state.lastTipSimulation;
    final bestSimulation = state.bestTipSimulation;

    return _PanelCard(
      title: 'Analysemodus',
      subtitle: 'Slider, Letzte 52, AI Bewertung und AI Pro UI.',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SubCard(
            title: 'Analyse-Steuerung',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const _ControlLabel('Ziehungstag'),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: _ChoiceButton(
                        label: 'Beide',
                        selected: state.analysisDrawFilter == AnalysisDrawFilter.all,
                        onTap: () => context.read<LottoAppState>().setAnalysisDrawFilter(
                          AnalysisDrawFilter.all,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _ChoiceButton(
                        label: 'Mittwoch',
                        selected:
                        state.analysisDrawFilter == AnalysisDrawFilter.wednesday,
                        onTap: () => context.read<LottoAppState>().setAnalysisDrawFilter(
                          AnalysisDrawFilter.wednesday,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _ChoiceButton(
                        label: 'Samstag',
                        selected:
                        state.analysisDrawFilter == AnalysisDrawFilter.saturday,
                        onTap: () => context.read<LottoAppState>().setAnalysisDrawFilter(
                          AnalysisDrawFilter.saturday,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                const _ControlLabel('Analyse-Ziehungen'),
                const SizedBox(height: 8),
                Row(
                  children: [
                    _StepButton(
                      label: '-10',
                      onTap: () {
                        final s = context.read<LottoAppState>();
                        final next =
                        s.analysisDrawCount - 10 < 1 ? 1 : s.analysisDrawCount - 10;
                        s.setAnalysisDrawCount(next);
                      },
                    ),
                    const SizedBox(width: 6),
                    _StepButton(
                      label: '-1',
                      onTap: () {
                        final s = context.read<LottoAppState>();
                        final next =
                        s.analysisDrawCount - 1 < 1 ? 1 : s.analysisDrawCount - 1;
                        s.setAnalysisDrawCount(next);
                      },
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Slider(
                        value: state.analysisDrawCount.toDouble(),
                        min: 1,
                        max: state.maxAnalysisDrawCount.toDouble(),
                        divisions: state.maxAnalysisDrawCount > 1
                            ? state.maxAnalysisDrawCount - 1
                            : 1,
                        label: '${state.analysisDrawCount}',
                        onChanged: (value) {
                          context.read<LottoAppState>().setAnalysisDrawCount(
                            value.round(),
                          );
                        },
                      ),
                    ),
                    const SizedBox(width: 8),
                    _StepButton(
                      label: '+1',
                      onTap: () {
                        final s = context.read<LottoAppState>();
                        final max = s.maxAnalysisDrawCount;
                        final next =
                        s.analysisDrawCount + 1 > max ? max : s.analysisDrawCount + 1;
                        s.setAnalysisDrawCount(next);
                      },
                    ),
                    const SizedBox(width: 6),
                    _StepButton(
                      label: '+10',
                      onTap: () {
                        final s = context.read<LottoAppState>();
                        final max = s.maxAnalysisDrawCount;
                        final next = s.analysisDrawCount + 10 > max
                            ? max
                            : s.analysisDrawCount + 10;
                        s.setAnalysisDrawCount(next);
                      },
                    ),
                  ],
                ),
                Row(
                  children: [
                    Text(
                      '1',
                      style: const TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const Spacer(),
                    const Text(
                      'Finger: 1er • Buttons: 1 / 10',
                      style: TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      '${state.maxAnalysisDrawCount}',
                      style: const TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          context.read<LottoAppState>().setAnalysisToRecent52();
                        },
                        icon: const Icon(Icons.history_rounded),
                        label: const Text('Letzte 52'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          context.read<LottoAppState>().setAnalysisToAllHistory();
                        },
                        icon: const Icon(Icons.all_inclusive_rounded),
                        label: const Text('Komplett'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                const _ControlLabel('Profil'),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: _ChoiceButton(
                        label: 'Defensiv',
                        selected:
                        state.analysisProfile == AnalysisProfile.defensive,
                        onTap: () => context.read<LottoAppState>().setAnalysisProfile(
                          AnalysisProfile.defensive,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _ChoiceButton(
                        label: 'Mittel',
                        selected:
                        state.analysisProfile == AnalysisProfile.balanced,
                        onTap: () => context.read<LottoAppState>().setAnalysisProfile(
                          AnalysisProfile.balanced,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _ChoiceButton(
                        label: 'Aggressiv',
                        selected:
                        state.analysisProfile == AnalysisProfile.aggressive,
                        onTap: () => context.read<LottoAppState>().setAnalysisProfile(
                          AnalysisProfile.aggressive,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                _InlineInfo(label: 'Fenster', value: state.analysisWindowLabel),
                const SizedBox(height: 6),
                _InlineInfo(label: 'Ziehungen', value: '${state.analysisDrawCount}'),
                const SizedBox(height: 6),
                _InlineInfo(label: 'Qualität', value: state.analysisStrengthLabel),
              ],
            ),
          ),
          const SizedBox(height: 14),
          PrimaryButton(
            label: 'Analyse-Tipp berechnen',
            icon: Icons.auto_awesome_rounded,
            onPressed: onGenerate,
          ),
          const SizedBox(height: 10),

          PrimaryButton(
            label: 'AI Max Mode',
            icon: Icons.psychology_alt_rounded,
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const AiMaxModeScreen(),
                ),
              );
            },
          ),
          _SubCard(
            title: 'AI Bewertung',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _InlineInfo(label: 'Titel', value: ai.title),
                const SizedBox(height: 6),
                _InlineInfo(label: 'Confidence', value: ai.confidence),
                const SizedBox(height: 12),
                _ConfidenceBar(confidenceText: ai.confidence),
                const SizedBox(height: 12),
                _BallRow(title: 'Empfohlen', numbers: ai.recommendedNumbers),
                const SizedBox(height: 12),
                _BallRow(title: 'Eher meiden', numbers: ai.avoidNumbers),
                const SizedBox(height: 12),
                Text(
                  ai.reasoning,
                  style: const TextStyle(
                    fontSize: 12,
                    height: 1.4,
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _SubCard(
            title: 'AI Pro Bewertung',
            child: bestTip.length != 6
                ? const Text(
              'Noch kein AI Pro Tipp verfügbar.',
              style: TextStyle(
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w600,
              ),
            )
                : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: bestTip
                      .map((n) => NumberBall(number: n))
                      .toList(),
                ),
                const SizedBox(height: 14),
                _AiProScoreCard(
                  title: 'AI Pro Score',
                  profile: state.analysisProfileLabel,
                  quality: state.analysisStrengthLabel,
                  drawCount: state.analysisDrawCount,
                ),
                if (bestSimulation != null) ...[
                  const SizedBox(height: 14),
                  _SimulationCard(
                    title: 'AI Pro Rücktest',
                    simulation: bestSimulation,
                  ),
                ],
                const SizedBox(height: 14),
                PrimaryButton(
                  label: 'AI Pro Tipp übernehmen',
                  icon: Icons.psychology_alt_rounded,
                  onPressed: onApplyBest,
                ),
              ],
            ),
          ),
          if (lastSimulation != null) ...[
            const SizedBox(height: 14),
            _SubCard(
              title: 'Letzter Tipp Rücktest',
              child: _SimulationCard(
                title: 'Trefferverteilung',
                simulation: lastSimulation,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _ConfidenceBar extends StatelessWidget {
  final String confidenceText;

  const _ConfidenceBar({
    required this.confidenceText,
  });

  double _extractValue() {
    final match = RegExp(r'(\d+)').firstMatch(confidenceText);
    final raw = int.tryParse(match?.group(1) ?? '') ?? 0;
    final clamped = raw.clamp(0, 100);
    return clamped / 100;
  }

  @override
  Widget build(BuildContext context) {
    final value = _extractValue();
    final color = value >= 0.75
        ? Colors.green
        : value >= 0.45
        ? Colors.orange
        : Colors.red;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Confidence Balken',
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: LinearProgressIndicator(
            value: value,
            minHeight: 12,
            backgroundColor: Colors.grey.shade200,
            valueColor: AlwaysStoppedAnimation<Color>(color),
          ),
        ),
      ],
    );
  }
}

class _AiProScoreCard extends StatelessWidget {
  final String title;
  final String profile;
  final String quality;
  final int drawCount;

  const _AiProScoreCard({
    required this.title,
    required this.profile,
    required this.quality,
    required this.drawCount,
  });

  int _score() {
    int base = 50;

    if (quality.toLowerCase().contains('hoch')) {
      base += 20;
    } else if (quality.toLowerCase().contains('mittel')) {
      base += 10;
    }

    if (profile.toLowerCase().contains('aggressiv')) {
      base += 8;
    } else if (profile.toLowerCase().contains('defensiv')) {
      base += 4;
    } else {
      base += 6;
    }

    if (drawCount >= 52) {
      base += 12;
    } else if (drawCount >= 20) {
      base += 8;
    } else {
      base += 4;
    }

    return base.clamp(0, 100);
  }

  @override
  Widget build(BuildContext context) {
    final score = _score();
    final color = score >= 80
        ? Colors.green
        : score >= 60
        ? Colors.orange
        : Colors.red;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surfaceSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Container(
                width: 64,
                height: 64,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.12),
                  border: Border.all(color: color.withOpacity(0.4)),
                ),
                child: Text(
                  '$score',
                  style: TextStyle(
                    color: color,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  children: [
                    _InlineInfo(label: 'Profil', value: profile),
                    const SizedBox(height: 6),
                    _InlineInfo(label: 'Qualität', value: quality),
                    const SizedBox(height: 6),
                    _InlineInfo(label: 'Basis', value: '$drawCount Ziehungen'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SimulationCard extends StatelessWidget {
  final String title;
  final dynamic simulation;

  const _SimulationCard({
    required this.title,
    required this.simulation,
  });

  @override
  Widget build(BuildContext context) {
    final totalDraws = simulation.totalDraws as int;

    Widget row(int hits) {
      final count = simulation.getHitCount(hits) as int;
      final ratio = totalDraws > 0 ? count / totalDraws : 0.0;

      return Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '$hits Richtige',
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ),
                Text(
                  '$count',
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: LinearProgressIndicator(
                value: ratio,
                minHeight: 10,
                backgroundColor: Colors.grey.shade200,
                valueColor: const AlwaysStoppedAnimation<Color>(AppColors.primary),
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surfaceSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 12),
          row(0),
          row(1),
          row(2),
          row(3),
          row(4),
          row(5),
          row(6),
        ],
      ),
    );
  }
}

class _StepButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _StepButton({
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Ink(
        width: 44,
        height: 38,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
          boxShadow: const [
            BoxShadow(
              color: AppColors.shadowLight,
              blurRadius: 8,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Center(
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
        ),
      ),
    );
  }
}

class _SystemPanel extends StatelessWidget {
  final LottoAppState state;
  final int step;
  final ValueChanged<int> onStepChanged;
  final Future<void> Function() onGenerate;
  final Future<void> Function()? onSaveRows;

  const _SystemPanel({
    required this.state,
    required this.step,
    required this.onStepChanged,
    required this.onGenerate,
    required this.onSaveRows,
  });

  @override
  Widget build(BuildContext context) {
    return _PanelCard(
      title: 'Systemgenerator',
      subtitle: 'Vollsystem und VEW sauber geführt in drei Schritten.',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _StepTabs(step: step, onChanged: onStepChanged),
          const SizedBox(height: 14),
          if (step == 0) _SystemStepType(state: state),
          if (step == 1) _SystemStepNumbers(state: state),
          if (step == 2)
            _SystemStepResult(
              state: state,
              onGenerate: onGenerate,
              onSaveRows: onSaveRows,
            ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: step == 0 ? null : () => onStepChanged(step - 1),
                  icon: const Icon(Icons.arrow_back_rounded),
                  label: const Text('Zurück'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.icon(
                  onPressed: step == 2 ? null : () => onStepChanged(step + 1),
                  icon: const Icon(Icons.arrow_forward_rounded),
                  label: const Text('Weiter'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _StepTabs extends StatelessWidget {
  final int step;
  final ValueChanged<int> onChanged;

  const _StepTabs({
    required this.step,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    const labels = ['1. Typ', '2. Zahlen', '3. Ergebnis'];
    return Row(
      children: List.generate(labels.length, (index) {
        final selected = step == index;
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: index == labels.length - 1 ? 0 : 8),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => onChanged(index),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  gradient: selected
                      ? const LinearGradient(
                    colors: [AppColors.primary, AppColors.primaryDark],
                  )
                      : null,
                  color: selected ? null : AppColors.surfaceSoft,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.border),
                ),
                child: Center(
                  child: Text(
                    labels[index],
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: selected ? Colors.white : AppColors.textSecondary,
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}

class _SystemStepType extends StatelessWidget {
  final LottoAppState state;

  const _SystemStepType({required this.state});

  @override
  Widget build(BuildContext context) {
    return _SubCard(
      title: 'Systemart und Größe',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: _ChoiceButton(
                  label: 'Vollsystem',
                  selected: state.systemPlayType == SystemPlayType.full,
                  onTap: () => context.read<LottoAppState>().setSystemPlayType(
                    SystemPlayType.full,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _ChoiceButton(
                  label: 'VEW',
                  selected: state.systemPlayType == SystemPlayType.vew,
                  onTap: () => context.read<LottoAppState>().setSystemPlayType(
                    SystemPlayType.vew,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _InlineInfo(label: 'Systemart', value: state.systemPlayTypeLabel),
          const SizedBox(height: 8),
          _InlineInfo(label: 'Systemgröße', value: '${state.selectedSystemSize} Zahlen'),
          const SizedBox(height: 8),
          Slider(
            value: state.selectedSystemSize.toDouble(),
            min: 7,
            max: 16,
            divisions: 9,
            label: '${state.selectedSystemSize}',
            onChanged: (value) {
              context.read<LottoAppState>().setSelectedSystemSize(value.round());
            },
          ),
        ],
      ),
    );
  }
}

class _SystemStepNumbers extends StatelessWidget {
  final LottoAppState state;

  const _SystemStepNumbers({required this.state});

  @override
  Widget build(BuildContext context) {
    return _SubCard(
      title: 'Manuelle Basiszahlen',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _InlineInfo(
            label: 'Gewählt',
            value: state.manualSystemNumbers.isEmpty
                ? 'Noch keine Zahlen'
                : state.manualSystemNumbers.join(' • '),
          ),
          const SizedBox(height: 8),
          _InlineInfo(
            label: 'Freie Plätze',
            value: '${state.remainingManualSystemSlots}',
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: List.generate(49, (index) {
              final number = index + 1;
              final selected = state.manualSystemNumbers.contains(number);
              final disabled = !selected &&
                  state.manualSystemNumbers.length >= state.selectedSystemSize;
              return _SelectableNumberChip(
                number: number,
                selected: selected,
                disabled: disabled,
                onTap: () async {
                  try {
                    await context.read<LottoAppState>().toggleManualSystemNumber(number);
                  } catch (_) {}
                },
              );
            }),
          ),
          const SizedBox(height: 14),
          OutlinedButton.icon(
            onPressed: state.manualSystemNumbers.isEmpty
                ? null
                : () {
              context.read<LottoAppState>().clearManualSystemNumbers();
            },
            icon: const Icon(Icons.backspace_outlined),
            label: const Text('Auswahl leeren'),
          ),
        ],
      ),
    );
  }
}

class _SystemStepResult extends StatelessWidget {
  final LottoAppState state;
  final Future<void> Function() onGenerate;
  final Future<void> Function()? onSaveRows;

  const _SystemStepResult({
    required this.state,
    required this.onGenerate,
    required this.onSaveRows,
  });

  @override
  Widget build(BuildContext context) {
    return _SubCard(
      title: 'Ergebnis',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          PrimaryButton(
            label: 'Systemreihen berechnen',
            icon: Icons.grid_view_rounded,
            onPressed: onGenerate,
          ),
          const SizedBox(height: 10),
          PrimaryButton(
            label: 'Systemreihen speichern',
            icon: Icons.save_alt_rounded,
            onPressed: onSaveRows,
          ),
          const SizedBox(height: 14),
          _InlineInfo(
            label: 'Basiszahlen',
            value: state.systemBaseNumbers.isEmpty
                ? '-'
                : state.systemBaseNumbers.join(' • '),
          ),
          const SizedBox(height: 8),
          _InlineInfo(
            label: 'Reihen',
            value: '${state.systemRows.length}',
          ),
          const SizedBox(height: 14),
          if (!state.hasSystemRows)
            const Text(
              'Noch keine Systemreihen erzeugt.',
              style: TextStyle(
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w600,
              ),
            )
          else
            ...state.systemRows.take(10).toList().asMap().entries.map((entry) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 28,
                      child: Text(
                        '${entry.key + 1}.',
                        style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: entry.value
                            .map((n) => NumberBall(number: n))
                            .toList(),
                      ),
                    ),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }
}

class _SubCard extends StatelessWidget {
  final String title;
  final Widget child;

  const _SubCard({
    required this.title,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surfaceSoft,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

class _ControlLabel extends StatelessWidget {
  final String label;

  const _ControlLabel(this.label);

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w800,
        color: AppColors.textPrimary,
      ),
    );
  }
}
class _ChoiceButton extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _ChoiceButton({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedScale(
      duration: const Duration(milliseconds: 140),
      scale: selected ? 1.01 : 1.0,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOut,
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
          decoration: BoxDecoration(
            gradient: selected
                ? const LinearGradient(
              colors: [AppColors.primary, AppColors.primaryDark],
            )
                : null,
            color: selected ? null : Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? AppColors.primaryDark : AppColors.border,
              width: selected ? 1.4 : 1.0,
            ),
            boxShadow: selected
                ? const [
              BoxShadow(
                color: AppColors.shadowMedium,
                blurRadius: 10,
                offset: Offset(0, 4),
              ),
            ]
                : null,
          ),
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (selected) ...[
                  const Icon(
                    Icons.check_circle_rounded,
                    size: 14,
                    color: Colors.white,
                  ),
                  const SizedBox(width: 4),
                ],
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: selected ? Colors.white : AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _InlineInfo extends StatelessWidget {
  final String label;
  final String value;

  const _InlineInfo({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 88,
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: AppColors.textSecondary,
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
              height: 1.35,
            ),
          ),
        ),
      ],
    );
  }
}

class _BallRow extends StatelessWidget {
  final String title;
  final List<int> numbers;

  const _BallRow({
    required this.title,
    required this.numbers,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 8),
        if (numbers.isEmpty)
          const Text(
            '-',
            style: TextStyle(
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w600,
            ),
          )
        else
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: numbers.map((n) => NumberBall(number: n)).toList(),
          ),
      ],
    );
  }
}

class _SelectableNumberChip extends StatelessWidget {
  final int number;
  final bool selected;
  final bool disabled;
  final VoidCallback onTap;

  const _SelectableNumberChip({
    required this.number,
    required this.selected,
    required this.disabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final background = selected
        ? AppColors.primary
        : disabled
        ? Colors.grey.shade200
        : Colors.white;
    final foreground = selected
        ? Colors.white
        : disabled
        ? Colors.grey.shade500
        : AppColors.textSecondary;

    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: disabled ? null : onTap,
      child: Container(
        width: 40,
        height: 40,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: background,
          border: Border.all(color: AppColors.border),
        ),
        child: Text(
          '$number',
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w800,
            color: foreground,
          ),
        ),
      ),
    );
  }
}