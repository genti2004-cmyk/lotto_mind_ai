import '../../draws/domain/draw_result.dart';

class NumberAnalysis {
  final int number;
  final int totalCount;
  final int lastSeenIndex;
  final int currentGap;
  final double trendScore;
  final double returnScore;
  final double pairScore;
  final double tripleScore;
  final double rangeScore;
  final double totalScore;

  const NumberAnalysis({
    required this.number,
    required this.totalCount,
    required this.lastSeenIndex,
    required this.currentGap,
    required this.trendScore,
    required this.returnScore,
    required this.pairScore,
    required this.tripleScore,
    required this.rangeScore,
    required this.totalScore,
  });
}

class PairPattern {
  final List<int> pair;
  final int count;
  final double score;

  const PairPattern({
    required this.pair,
    required this.count,
    required this.score,
  });
}

class TriplePattern {
  final List<int> triple;
  final int count;
  final double score;

  const TriplePattern({
    required this.triple,
    required this.count,
    required this.score,
  });
}

class RangeGroupAnalysis {
  final String label;
  final int min;
  final int max;
  final int hitCount;
  final double averagePerDraw;
  final double share;

  const RangeGroupAnalysis({
    required this.label,
    required this.min,
    required this.max,
    required this.hitCount,
    required this.averagePerDraw,
    required this.share,
  });
}

class SmartTipDetails {
  final List<int> numbers;
  final List<String> reasons;

  const SmartTipDetails({
    required this.numbers,
    required this.reasons,
  });
}

class AdvancedNumberAnalysisService {
  const AdvancedNumberAnalysisService();

  List<NumberAnalysis> buildAdvancedAnalysis(List<DrawResult> draws) {
    if (draws.isEmpty) return [];

    final sortedDraws = List<DrawResult>.from(draws)
      ..sort((a, b) => b.drawDate.compareTo(a.drawDate));

    final limitedDraws = sortedDraws.length > 120
        ? sortedDraws.take(120).toList()
        : sortedDraws;

    final pairPatterns = buildPairPatterns(limitedDraws, top: 40);
    final triplePatterns = buildTriplePatterns(limitedDraws, top: 24);
    final rangeGroups = buildRangeGroups(limitedDraws);

    final Map<int, int> totalCount = {};
    final Map<int, int> lastSeen = {};

    for (int i = 0; i < limitedDraws.length; i++) {
      final numbers = _normalizedNumbers(limitedDraws[i]);
      for (final n in numbers) {
        totalCount[n] = (totalCount[n] ?? 0) + 1;
        lastSeen.putIfAbsent(n, () => i);
      }
    }

    final Map<int, double> rangeContribution = {};
    for (final group in rangeGroups) {
      final weight = group.share * 8.0;
      for (int n = group.min; n <= group.max; n++) {
        rangeContribution[n] = (rangeContribution[n] ?? 0) + weight;
      }
    }

    final List<NumberAnalysis> result = [];

    for (int n = 1; n <= 49; n++) {
      final count = totalCount[n] ?? 0;
      final lastIndex = lastSeen[n] ?? -1;
      final gap = lastIndex == -1 ? limitedDraws.length : lastIndex;

      double trend = 0;
      for (int i = 0; i < limitedDraws.length; i++) {
        final numbers = _normalizedNumbers(limitedDraws[i]);
        if (!numbers.contains(n)) continue;

        if (i <= 9) {
          trend += 3.0;
        } else if (i <= 24) {
          trend += 2.0;
        } else if (i <= 49) {
          trend += 1.0;
        } else {
          trend += 0.35;
        }
      }

      double returnScore = 0;
      if (gap >= 20) {
        returnScore = 3.0;
      } else if (gap >= 12) {
        returnScore = 2.0;
      } else if (gap >= 6) {
        returnScore = 1.0;
      }

      double pairScore = 0;
      for (final pair in pairPatterns) {
        if (pair.pair.contains(n)) {
          pairScore += pair.count.toDouble();
        }
      }

      double tripleScore = 0;
      for (final triple in triplePatterns) {
        if (triple.triple.contains(n)) {
          tripleScore += triple.count.toDouble() * 1.5;
        }
      }

      final rangeScore = rangeContribution[n] ?? 0.0;

      final totalScore =
          (count * 0.55) +
              (trend * 1.25) +
              (returnScore * 2.10) +
              (pairScore * 0.18) +
              (tripleScore * 0.15) +
              (rangeScore * 0.22);

      result.add(
        NumberAnalysis(
          number: n,
          totalCount: count,
          lastSeenIndex: lastIndex,
          currentGap: gap,
          trendScore: trend,
          returnScore: returnScore,
          pairScore: pairScore,
          tripleScore: tripleScore,
          rangeScore: rangeScore,
          totalScore: totalScore,
        ),
      );
    }

    result.sort((a, b) => b.totalScore.compareTo(a.totalScore));
    return result;
  }

  List<int> getTopNumbers(List<DrawResult> draws, {int count = 10}) {
    final analysis = buildAdvancedAnalysis(draws);
    return analysis.take(count).map((e) => e.number).toList();
  }

  List<PairPattern> buildPairPatterns(List<DrawResult> draws, {int top = 12}) {
    if (draws.isEmpty) return [];

    final limitedDraws = draws.length > 100 ? draws.take(100).toList() : draws;
    final Map<String, int> pairMap = {};

    for (final draw in limitedDraws) {
      final numbers = _normalizedNumbers(draw);
      if (numbers.length < 2) continue;

      for (int i = 0; i < numbers.length; i++) {
        for (int j = i + 1; j < numbers.length; j++) {
          final key = '${numbers[i]}-${numbers[j]}';
          pairMap[key] = (pairMap[key] ?? 0) + 1;
        }
      }
    }

    final result = pairMap.entries.map((entry) {
      final parts = entry.key.split('-').map(int.parse).toList()..sort();
      return PairPattern(
        pair: parts,
        count: entry.value,
        score: entry.value.toDouble(),
      );
    }).where((e) => e.pair.length == 2).toList();

    result.sort((a, b) => b.score.compareTo(a.score));
    return result.take(top).toList();
  }

  List<TriplePattern> buildTriplePatterns(List<DrawResult> draws, {int top = 10}) {
    if (draws.isEmpty) return [];

    final limitedDraws = draws.length > 70 ? draws.take(70).toList() : draws;
    final Map<String, int> tripleMap = {};

    for (final draw in limitedDraws) {
      final numbers = _normalizedNumbers(draw);
      if (numbers.length < 3) continue;

      for (int i = 0; i < numbers.length; i++) {
        for (int j = i + 1; j < numbers.length; j++) {
          for (int k = j + 1; k < numbers.length; k++) {
            final key = '${numbers[i]}-${numbers[j]}-${numbers[k]}';
            tripleMap[key] = (tripleMap[key] ?? 0) + 1;
          }
        }
      }
    }

    final result = tripleMap.entries.map((entry) {
      final parts = entry.key.split('-').map(int.parse).toList()..sort();
      return TriplePattern(
        triple: parts,
        count: entry.value,
        score: entry.value.toDouble(),
      );
    }).where((e) => e.triple.length == 3).toList();

    result.sort((a, b) => b.score.compareTo(a.score));
    return result.take(top).toList();
  }

  List<RangeGroupAnalysis> buildRangeGroups(List<DrawResult> draws) {
    if (draws.isEmpty) return const [];

    final groups = <({String label, int min, int max})>[
      (label: '1-10', min: 1, max: 10),
      (label: '11-20', min: 11, max: 20),
      (label: '21-30', min: 21, max: 30),
      (label: '31-40', min: 31, max: 40),
      (label: '41-49', min: 41, max: 49),
    ];

    int totalNumbers = 0;
    for (final draw in draws) {
      totalNumbers += _normalizedNumbers(draw).length;
    }
    if (totalNumbers <= 0) return const [];

    final List<RangeGroupAnalysis> result = [];

    for (final group in groups) {
      int hitCount = 0;
      for (final draw in draws) {
        for (final n in _normalizedNumbers(draw)) {
          if (n >= group.min && n <= group.max) {
            hitCount++;
          }
        }
      }

      result.add(
        RangeGroupAnalysis(
          label: group.label,
          min: group.min,
          max: group.max,
          hitCount: hitCount,
          averagePerDraw: draws.isEmpty ? 0 : hitCount / draws.length,
          share: hitCount / totalNumbers,
        ),
      );
    }

    result.sort((a, b) => b.share.compareTo(a.share));
    return result;
  }

  List<int> generateSmartTip(List<DrawResult> draws) {
    return generateSmartTipDetails(draws).numbers;
  }

  SmartTipDetails generateSmartTipDetails(List<DrawResult> draws) {
    final analysis = buildAdvancedAnalysis(draws);
    if (analysis.isEmpty) {
      return const SmartTipDetails(numbers: [], reasons: []);
    }

    final topAnalysis = analysis.take(12).toList();
    final selected = topAnalysis.take(6).map((e) => e.number).toList()..sort();

    return SmartTipDetails(
      numbers: selected,
      reasons: const ['Leichte Smart-Tipp-Berechnung für stabile Analyse'],
    );
  }

  List<int> _normalizedNumbers(DrawResult draw) {
    final unique = draw.numbers.toSet().toList()..sort();
    return unique.where((n) => n >= 1 && n <= 49).toList();
  }
}
