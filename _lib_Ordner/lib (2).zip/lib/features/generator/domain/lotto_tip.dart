class LottoTip {
  final String id;
  final DateTime createdAt;
  final List<int> numbers;
  final String source;
  final bool isFavorite;

  const LottoTip({
    required this.id,
    required this.createdAt,
    required this.numbers,
    required this.source,
    this.isFavorite = false,
  });

  LottoTip copyWith({
    String? id,
    DateTime? createdAt,
    List<int>? numbers,
    String? source,
    bool? isFavorite,
  }) {
    return LottoTip(
      id: id ?? this.id,
      createdAt: createdAt ?? this.createdAt,
      numbers: numbers ?? this.numbers,
      source: source ?? this.source,
      isFavorite: isFavorite ?? this.isFavorite,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'createdAt': createdAt.toIso8601String(),
      'numbers': numbers,
      'source': source,
      'isFavorite': isFavorite,
    };
  }

  factory LottoTip.fromMap(Map<dynamic, dynamic> map) {
    return LottoTip(
      id: map['id']?.toString() ?? '',
      createdAt:
      DateTime.tryParse(map['createdAt']?.toString() ?? '') ?? DateTime.now(),
      numbers: (map['numbers'] as List? ?? const [])
          .map((e) => int.tryParse(e.toString()) ?? 0)
          .where((e) => e > 0)
          .toList(),
      source: map['source']?.toString() ?? 'smart_analysis',
      isFavorite: map['isFavorite'] == true,
    );
  }
}