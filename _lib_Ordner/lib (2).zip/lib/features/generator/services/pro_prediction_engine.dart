
import 'dart:math';

import '../../draws/domain/draw_result.dart';

class PredictionEngineResult {
  final List<int> primaryTip;
  final int? recommendedSuperNumber;
  final double overallScore;
  final double score3Plus;
  final List<PredictionCandidate> topCandidates;
  final List<String> reasons;

  const PredictionEngineResult({
    required this.primaryTip,
    required this.recommendedSuperNumber,
    required this.overallScore,
    required this.score3Plus,
    required this.topCandidates,
    required this.reasons,
  });

  factory PredictionEngineResult.empty() {
    return const PredictionEngineResult(
      primaryTip: [],
      recommendedSuperNumber: null,
      overallScore: 0,
      score3Plus: 0,
      topCandidates: [],
      reasons: ['Noch nicht genug Ziehungen für eine belastbare Prognose.'],
    );
  }
}

class PredictionCandidate {
  final List<int> tip;
  final double totalScore;
  final double score3Plus;
  final double pairScore;
  final double tripleScore;
  final double recencyScore;
  final double overdueScore;
  final double structureScore;
  final List<String> reasons;

  const PredictionCandidate({
    required this.tip,
    required this.totalScore,
    required this.score3Plus,
    required this.pairScore,
    required this.tripleScore,
    required this.recencyScore,
    required this.overdueScore,
    required this.structureScore,
    required this.reasons,
  });
}

class ProPredictionEngine {
  final Random _random;

  ProPredictionEngine({Random? random}) : _random = random ?? Random();

  PredictionEngineResult build({
    required List<DrawResult> draws,
    required String profileLabel,
    int candidateCount = 320,
  }) {
    final normalizedDraws = draws
        .map((d) => d.numbers.where((n) => n >= 1 && n <= 49).toSet().toList()..sort())
        .where((d) => d.length == 6)
        .toList();

    if (normalizedDraws.length < 12) {
      return PredictionEngineResult.empty();
    }

    final freq = _buildFrequency(normalizedDraws);
    final recency = _buildRecencyFrequency(normalizedDraws, recentWindow: min(26, normalizedDraws.length));
    final lastSeen = _buildLastSeenIndex(normalizedDraws);
    final pairCounts = _buildPairCounts(normalizedDraws);
    final tripleCounts = _buildTripleCounts(normalizedDraws);
    final repeatHistogram = _buildRepeatHistogram(normalizedDraws);
    final superNumber = _buildSuperNumberRecommendation(draws);

    final baseRanking = _buildBaseRanking(
      freq: freq,
      recency: recency,
      lastSeen: lastSeen,
      profileLabel: profileLabel,
    );

    final candidates = <PredictionCandidate>[];

    for (int i = 0; i < candidateCount; i++) {
      final tip = _buildCandidateTip(
        ranking: baseRanking,
        pairCounts: pairCounts,
        tripleCounts: tripleCounts,
        profileLabel: profileLabel,
      );

      candidates.add(_scoreTip(
        tip: tip,
        draws: normalizedDraws,
        pairCounts: pairCounts,
        tripleCounts: tripleCounts,
        freq: freq,
        recency: recency,
        lastSeen: lastSeen,
        repeatHistogram: repeatHistogram,
      ));
    }

    candidates.sort((a, b) => b.totalScore.compareTo(a.totalScore));
    final unique = <String, PredictionCandidate>{};
    for (final c in candidates) {
      unique.putIfAbsent(c.tip.join('-'), () => c);
      if (unique.length >= 20) break;
    }

    final topCandidates = unique.values.toList()
      ..sort((a, b) => b.totalScore.compareTo(a.totalScore));

    if (topCandidates.isEmpty) {
      return PredictionEngineResult.empty();
    }

    final best = topCandidates.first;
    return PredictionEngineResult(
      primaryTip: best.tip,
      recommendedSuperNumber: superNumber,
      overallScore: best.totalScore,
      score3Plus: best.score3Plus,
      topCandidates: topCandidates,
      reasons: best.reasons,
    );
  }

  Map<int, int> _buildFrequency(List<List<int>> draws) {
    final map = {for (int i = 1; i <= 49; i++) i: 0};
    for (final draw in draws) {
      for (final n in draw) {
        map[n] = (map[n] ?? 0) + 1;
      }
    }
    return map;
  }

  Map<int, int> _buildRecencyFrequency(List<List<int>> draws, {required int recentWindow}) {
    final map = {for (int i = 1; i <= 49; i++) i: 0};
    for (final draw in draws.take(recentWindow)) {
      for (final n in draw) {
        map[n] = (map[n] ?? 0) + 1;
      }
    }
    return map;
  }

  Map<int, int> _buildLastSeenIndex(List<List<int>> draws) {
    final map = <int, int>{};
    for (int number = 1; number <= 49; number++) {
      map[number] = draws.length + 99;
    }
    for (int i = 0; i < draws.length; i++) {
      for (final n in draws[i]) {
        map.putIfAbsent(n, () => i);
      }
    }
    return map;
  }

  Map<String, int> _buildPairCounts(List<List<int>> draws) {
    final map = <String, int>{};
    for (final draw in draws) {
      for (int i = 0; i < draw.length; i++) {
        for (int j = i + 1; j < draw.length; j++) {
          final key = '${draw[i]}-${draw[j]}';
          map[key] = (map[key] ?? 0) + 1;
        }
      }
    }
    return map;
  }

  Map<String, int> _buildTripleCounts(List<List<int>> draws) {
    final map = <String, int>{};
    for (final draw in draws) {
      for (int i = 0; i < draw.length; i++) {
        for (int j = i + 1; j < draw.length; j++) {
          for (int k = j + 1; k < draw.length; k++) {
            final key = '${draw[i]}-${draw[j]}-${draw[k]}';
            map[key] = (map[key] ?? 0) + 1;
          }
        }
      }
    }
    return map;
  }

  Map<int, int> _buildRepeatHistogram(List<List<int>> draws) {
    final hist = {for (int i = 0; i <= 6; i++) i: 0};
    for (int i = 1; i < draws.length; i++) {
      final prev = draws[i - 1].toSet();
      final curr = draws[i].toSet();
      final overlap = curr.where(prev.contains).length;
      hist[overlap] = (hist[overlap] ?? 0) + 1;
    }
    return hist;
  }

  int? _buildSuperNumberRecommendation(List<DrawResult> draws) {
    final counts = {for (int i = 0; i <= 9; i++) i: 0};
    for (final draw in draws) {
      final sn = draw.superNumber;
      if (sn != null && sn >= 0 && sn <= 9) {
        counts[sn] = (counts[sn] ?? 0) + 1;
      }
    }
    final sorted = counts.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return sorted.isEmpty ? null : sorted.first.key;
  }

  List<_RankedNumber> _buildBaseRanking({
    required Map<int, int> freq,
    required Map<int, int> recency,
    required Map<int, int> lastSeen,
    required String profileLabel,
  }) {
    final aggressive = profileLabel.toLowerCase().contains('aggressiv');
    final defensive = profileLabel.toLowerCase().contains('defensiv');
    final ranked = <_RankedNumber>[];

    for (int number = 1; number <= 49; number++) {
      final total = (freq[number] ?? 0).toDouble();
      final recent = (recency[number] ?? 0).toDouble();
      final overdueIndex = (lastSeen[number] ?? 0).toDouble();
      double score = (total * 1.0) + (recent * 1.8) + (overdueIndex * 0.12);

      if (aggressive) {
        score += overdueIndex * 0.25;
      } else if (defensive) {
        score += total * 0.8;
      } else {
        score += recent * 0.6;
      }

      ranked.add(_RankedNumber(number: number, score: score));
    }

    ranked.sort((a, b) => b.score.compareTo(a.score));
    return ranked;
  }

  List<int> _buildCandidateTip({
    required List<_RankedNumber> ranking,
    required Map<String, int> pairCounts,
    required Map<String, int> tripleCounts,
    required String profileLabel,
  }) {
    final selected = <int>{};
    final pool = ranking.take(22).map((e) => e.number).toList();

    while (selected.length < 2 && pool.isNotEmpty) {
      selected.add(pool[_random.nextInt(min(pool.length, 10))]);
    }

    final sortedNumbers = selected.toList()..sort();
    for (final candidate in pool) {
      if (selected.contains(candidate)) continue;
      final probe = [...sortedNumbers, candidate]..sort();

      bool goodPair = false;
      for (int i = 0; i < probe.length; i++) {
        for (int j = i + 1; j < probe.length; j++) {
          final key = '${probe[i]}-${probe[j]}';
          if ((pairCounts[key] ?? 0) >= 2) goodPair = true;
        }
      }

      bool goodTriple = false;
      if (probe.length >= 3) {
        for (int i = 0; i < probe.length; i++) {
          for (int j = i + 1; j < probe.length; j++) {
            for (int k = j + 1; k < probe.length; k++) {
              final key = '${probe[i]}-${probe[j]}-${probe[k]}';
              if ((tripleCounts[key] ?? 0) >= 2) goodTriple = true;
            }
          }
        }
      }

      if (goodPair || goodTriple || _random.nextDouble() < 0.30) {
        selected.add(candidate);
      }
      if (selected.length >= 6) break;
    }

    for (final item in ranking) {
      if (selected.length >= 6) break;
      selected.add(item.number);
    }

    final tip = selected.toList()..sort();
    return _normalizeStructure(tip.take(6).toList());
  }

  List<int> _normalizeStructure(List<int> rawTip) {
    final tip = rawTip.toSet().where((n) => n >= 1 && n <= 49).toList()..sort();
    if (tip.length != 6) {
      final fallback = <int>{...tip};
      while (fallback.length < 6) {
        fallback.add(_random.nextInt(49) + 1);
      }
      return fallback.toList()..sort();
    }

    final even = tip.where((n) => n.isEven).length;
    final low = tip.where((n) => n <= 24).length;
    final sum = tip.fold<int>(0, (a, b) => a + b);
    final spread = tip.last - tip.first;

    if (even >= 2 && even <= 4 && low >= 2 && low <= 4 && sum >= 95 && sum <= 190 && spread >= 18) {
      return tip;
    }

    final result = List<int>.from(tip);
    while (true) {
      final evenNow = result.where((n) => n.isEven).length;
      final lowNow = result.where((n) => n <= 24).length;
      final sumNow = result.fold<int>(0, (a, b) => a + b);
      final spreadNow = result.last - result.first;

      if (evenNow >= 2 && evenNow <= 4 && lowNow >= 2 && lowNow <= 4 && sumNow >= 95 && sumNow <= 190 && spreadNow >= 18) {
        break;
      }

      result.removeAt(_random.nextInt(result.length));
      result.add(_random.nextInt(49) + 1);
      final unique = result.toSet().toList()..sort();
      result..clear()..addAll(unique);
      while (result.length < 6) {
        result.add(_random.nextInt(49) + 1);
        final unique2 = result.toSet().toList()..sort();
        result..clear()..addAll(unique2);
      }
      result.sort();
    }

    return result.take(6).toList()..sort();
  }

  PredictionCandidate _scoreTip({
    required List<int> tip,
    required List<List<int>> draws,
    required Map<String, int> pairCounts,
    required Map<String, int> tripleCounts,
    required Map<int, int> freq,
    required Map<int, int> recency,
    required Map<int, int> lastSeen,
    required Map<int, int> repeatHistogram,
  }) {
    final backtest = _backtestTip(tip, draws);
    final score3Plus = _score3Plus(backtest, draws.length);
    final pairScore = _pairScore(tip, pairCounts);
    final tripleScore = _tripleScore(tip, tripleCounts);
    final recencyScore = _recencyScore(tip, freq, recency);
    final overdueScore = _overdueScore(tip, lastSeen);
    final structureScore = _structureScore(tip, repeatHistogram);

    final totalScore = (score3Plus * 0.35) +
        (pairScore * 0.20) +
        (tripleScore * 0.10) +
        (recencyScore * 0.15) +
        (overdueScore * 0.10) +
        (structureScore * 0.10);

    return PredictionCandidate(
      tip: tip,
      totalScore: totalScore,
      score3Plus: score3Plus,
      pairScore: pairScore,
      tripleScore: tripleScore,
      recencyScore: recencyScore,
      overdueScore: overdueScore,
      structureScore: structureScore,
      reasons: [
        '3+ Treffer Rücktest: ${score3Plus.toStringAsFixed(1)}',
        'Paarmuster: ${pairScore.toStringAsFixed(1)}',
        'Dreiermuster: ${tripleScore.toStringAsFixed(1)}',
        'Aktuelle Dynamik: ${recencyScore.toStringAsFixed(1)}',
        'Überfälligkeit: ${overdueScore.toStringAsFixed(1)}',
        'Strukturfit: ${structureScore.toStringAsFixed(1)}',
      ],
    );
  }

  Map<int, int> _backtestTip(List<int> tip, List<List<int>> draws) {
    final hist = {for (int i = 0; i <= 6; i++) i: 0};
    final set = tip.toSet();
    for (final draw in draws) {
      final hits = draw.where(set.contains).length;
      hist[hits] = (hist[hits] ?? 0) + 1;
    }
    return hist;
  }

  double _score3Plus(Map<int, int> backtest, int totalDraws) {
    if (totalDraws == 0) return 0;
    final two = backtest[2] ?? 0;
    final three = backtest[3] ?? 0;
    final four = backtest[4] ?? 0;
    final five = backtest[5] ?? 0;
    final six = backtest[6] ?? 0;
    final weighted = (two * 0.8) + (three * 2.5) + (four * 5.0) + (five * 8.0) + (six * 12.0);
    return (weighted / totalDraws) * 10.0;
  }

  double _pairScore(List<int> tip, Map<String, int> pairCounts) {
    double score = 0;
    int pairCounter = 0;
    for (int i = 0; i < tip.length; i++) {
      for (int j = i + 1; j < tip.length; j++) {
        final key = '${tip[i]}-${tip[j]}';
        score += (pairCounts[key] ?? 0).toDouble();
        pairCounter++;
      }
    }
    return pairCounter == 0 ? 0 : score / pairCounter;
  }

  double _tripleScore(List<int> tip, Map<String, int> tripleCounts) {
    double score = 0;
    int tripleCounter = 0;
    for (int i = 0; i < tip.length; i++) {
      for (int j = i + 1; j < tip.length; j++) {
        for (int k = j + 1; k < tip.length; k++) {
          final key = '${tip[i]}-${tip[j]}-${tip[k]}';
          score += (tripleCounts[key] ?? 0).toDouble();
          tripleCounter++;
        }
      }
    }
    return tripleCounter == 0 ? 0 : score / tripleCounter;
  }

  double _recencyScore(List<int> tip, Map<int, int> freq, Map<int, int> recency) {
    double sum = 0;
    for (final n in tip) {
      sum += ((recency[n] ?? 0) * 2.0) + ((freq[n] ?? 0) * 0.6);
    }
    return sum / tip.length;
  }

  double _overdueScore(List<int> tip, Map<int, int> lastSeen) {
    double sum = 0;
    for (final n in tip) {
      sum += (lastSeen[n] ?? 0).toDouble();
    }
    return sum / tip.length;
  }

  double _structureScore(List<int> tip, Map<int, int> repeatHistogram) {
    final even = tip.where((n) => n.isEven).length;
    final low = tip.where((n) => n <= 24).length;
    final sum = tip.fold<int>(0, (a, b) => a + b);
    final spread = tip.last - tip.first;
    final endDigits = tip.map((e) => e % 10).toSet().length;

    double score = 0;
    if (even >= 2 && even <= 4) score += 8;
    if (low >= 2 && low <= 4) score += 8;
    if (sum >= 95 && sum <= 190) score += 10;
    if (spread >= 18 && spread <= 42) score += 8;
    if (endDigits >= 4) score += 4;
    if ((repeatHistogram[1] ?? 0) >= (repeatHistogram[2] ?? 0)) score += 2;
    return score;
  }
}

class _RankedNumber {
  final int number;
  final double score;

  const _RankedNumber({
    required this.number,
    required this.score,
  });
}
