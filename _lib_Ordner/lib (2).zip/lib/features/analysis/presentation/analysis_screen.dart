import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/app_card.dart';
import '../../../core/widgets/section_title.dart';
import '../../draws/domain/draw_result.dart';
import '../../generator/provider/lotto_app_state.dart';

class AnalysisScreen extends StatefulWidget {
  const AnalysisScreen({super.key});

  @override
  State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> {
  double _visibleCount = 8;

  int get visibleCount => _visibleCount.round().clamp(4, 16);

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SectionTitle(
            title: 'Analyse',
            subtitle:
            'Trendzahlen und weniger aktive Zahlen getrennt nach Mittwoch und Samstag',
          ),
          const SizedBox(height: 20),
          _OverviewCard(state: state),
          const SizedBox(height: 16),
          _DisplayControlCard(
            value: _visibleCount,
            visibleCount: visibleCount,
            onChanged: (value) {
              setState(() {
                _visibleCount = value;
              });
            },
          ),
          const SizedBox(height: 16),
          _DayAnalysisCard(
            title: 'Mittwoch',
            subtitle: 'Auswertung der Mittwoch-Ziehungen',
            draws: state.wednesdayDrawResults,
            visibleCount: visibleCount,
          ),
          const SizedBox(height: 16),
          _DayAnalysisCard(
            title: 'Samstag',
            subtitle: 'Auswertung der Samstag-Ziehungen',
            draws: state.saturdayDrawResults,
            visibleCount: visibleCount,
          ),
        ],
      ),
    );
  }
}

class _OverviewCard extends StatelessWidget {
  final LottoAppState state;

  const _OverviewCard({required this.state});

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Übersicht',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 12),
          _row('Gesamt Ziehungen', state.drawResults.length.toString()),
          _row('Mittwoch', state.wednesdayDrawResults.length.toString()),
          _row('Samstag', state.saturdayDrawResults.length.toString()),
          _row('Analyse-Ziehungen', state.analysisDrawResults.length.toString()),
          _row('Gespeicherte Tipps', state.savedTips.length.toString()),
        ],
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}

class _DisplayControlCard extends StatelessWidget {
  final double value;
  final int visibleCount;
  final ValueChanged<double> onChanged;

  const _DisplayControlCard({
    required this.value,
    required this.visibleCount,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Anzahl angezeigter Zahlen',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Mit dem Slider legst du fest, wie viele Zahlen pro Bereich angezeigt werden.',
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w600,
              height: 1.35,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text(
                '4',
                style: TextStyle(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Expanded(
                child: Slider(
                  value: value,
                  min: 4,
                  max: 16,
                  divisions: 12,
                  label: '$visibleCount',
                  onChanged: onChanged,
                ),
              ),
              const Text(
                '16',
                style: TextStyle(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: AppColors.surfaceSoft,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Text(
                '$visibleCount Zahlen sichtbar',
                style: const TextStyle(
                  fontWeight: FontWeight.w800,
                  color: AppColors.textPrimary,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _DayAnalysisCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final List<DrawResult> draws;
  final int visibleCount;

  const _DayAnalysisCard({
    required this.title,
    required this.subtitle,
    required this.draws,
    required this.visibleCount,
  });

  @override
  Widget build(BuildContext context) {
    final stats = _buildStats(draws, visibleCount);

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w600,
              height: 1.35,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _MiniInfoCard(
                  label: 'Ziehungen',
                  value: '${draws.length}',
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _MiniInfoCard(
                  label: 'Top-Paar',
                  value: stats.topPairLabel,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _NumberGroupSection(
            title: 'Trendzahlen',
            subtitle: 'Zahlen mit stärkerer Präsenz im gewählten Ziehungsblock',
            numbers: stats.trendingNumbers,
          ),
          const SizedBox(height: 16),
          _NumberGroupSection(
            title: 'Weniger aktive Zahlen',
            subtitle: 'Zahlen mit geringerer Präsenz im selben Ziehungsblock',
            numbers: stats.lessActiveNumbers,
          ),
          const SizedBox(height: 16),
          _SimpleMetricRow(
            label: 'Durchschnittliche Summe',
            value: stats.averageSum,
          ),
          const SizedBox(height: 8),
          _SimpleMetricRow(
            label: 'Durchschnittlich gerade Zahlen',
            value: stats.averageEven,
          ),
          const SizedBox(height: 8),
          _SimpleMetricRow(
            label: 'Durchschnittlich niedrige Zahlen (1–24)',
            value: stats.averageLow,
          ),
        ],
      ),
    );
  }

  _DayStats _buildStats(List<DrawResult> draws, int visibleCount) {
    if (draws.isEmpty) {
      return const _DayStats(
        trendingNumbers: [],
        lessActiveNumbers: [],
        topPairLabel: '-',
        averageSum: '-',
        averageEven: '-',
        averageLow: '-',
      );
    }

    final numberCounts = <int, int>{for (int i = 1; i <= 49; i++) i: 0};
    final pairCounts = <String, int>{};

    int totalSum = 0;
    int totalEven = 0;
    int totalLow = 0;

    for (final draw in draws) {
      final numbers = List<int>.from(draw.numbers)..sort();

      totalSum += numbers.fold<int>(0, (a, b) => a + b);
      totalEven += numbers.where((n) => n.isEven).length;
      totalLow += numbers.where((n) => n <= 24).length;

      for (final n in numbers) {
        numberCounts[n] = (numberCounts[n] ?? 0) + 1;
      }

      for (int i = 0; i < numbers.length; i++) {
        for (int j = i + 1; j < numbers.length; j++) {
          final key = '${numbers[i]}-${numbers[j]}';
          pairCounts[key] = (pairCounts[key] ?? 0) + 1;
        }
      }
    }

    final sortedHigh = numberCounts.entries.toList()
      ..sort((a, b) {
        final byCount = b.value.compareTo(a.value);
        if (byCount != 0) return byCount;
        return a.key.compareTo(b.key);
      });

    final sortedLow = numberCounts.entries.toList()
      ..sort((a, b) {
        final byCount = a.value.compareTo(b.value);
        if (byCount != 0) return byCount;
        return a.key.compareTo(b.key);
      });

    final topPair = pairCounts.entries.isEmpty
        ? null
        : (pairCounts.entries.toList()
      ..sort((a, b) {
        final byCount = b.value.compareTo(a.value);
        if (byCount != 0) return byCount;
        return a.key.compareTo(b.key);
      }))
        .first;

    return _DayStats(
      trendingNumbers:
      sortedHigh.take(visibleCount).map((e) => e.key).toList(),
      lessActiveNumbers:
      sortedLow.take(visibleCount).map((e) => e.key).toList(),
      topPairLabel: topPair == null ? '-' : '${topPair.key} (${topPair.value})',
      averageSum: (totalSum / draws.length).toStringAsFixed(1),
      averageEven: (totalEven / draws.length).toStringAsFixed(1),
      averageLow: (totalLow / draws.length).toStringAsFixed(1),
    );
  }
}

class _DayStats {
  final List<int> trendingNumbers;
  final List<int> lessActiveNumbers;
  final String topPairLabel;
  final String averageSum;
  final String averageEven;
  final String averageLow;

  const _DayStats({
    required this.trendingNumbers,
    required this.lessActiveNumbers,
    required this.topPairLabel,
    required this.averageSum,
    required this.averageEven,
    required this.averageLow,
  });
}

class _MiniInfoCard extends StatelessWidget {
  final String label;
  final String value;

  const _MiniInfoCard({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
      decoration: BoxDecoration(
        color: AppColors.surfaceSoft,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

class _NumberGroupSection extends StatelessWidget {
  final String title;
  final String subtitle;
  final List<int> numbers;

  const _NumberGroupSection({
    required this.title,
    required this.subtitle,
    required this.numbers,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surfaceSoft,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w600,
              fontSize: 12,
              height: 1.35,
            ),
          ),
          const SizedBox(height: 12),
          if (numbers.isEmpty)
            const Text(
              'Keine Daten vorhanden.',
              style: TextStyle(
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w600,
              ),
            )
          else
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: numbers.map((n) {
                return Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Text(
                    '$n',
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimary,
                    ),
                  ),
                );
              }).toList(),
            ),
        ],
      ),
    );
  }
}

class _SimpleMetricRow extends StatelessWidget {
  final String label;
  final String value;

  const _SimpleMetricRow({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
      ],
    );
  }
}