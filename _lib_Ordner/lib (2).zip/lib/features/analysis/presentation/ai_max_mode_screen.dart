// lib/features/analysis/presentation/ai_max_mode_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/number_ball.dart';
import '../../../core/widgets/primary_button.dart';
import '../../../core/widgets/section_title.dart';
import '../../generator/provider/lotto_app_state.dart';

class AiMaxModeScreen extends StatelessWidget {
  const AiMaxModeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();
    final result = state.predictionEngineResult;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('AI Max Mode')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SectionTitle(
            title: 'AI Max Mode',
            subtitle: 'Beste Tipps basierend auf Analyse + Score',
          ),

          const SizedBox(height: 20),

          Wrap(
            spacing: 8,
            children: result.primaryTip
                .map((n) => NumberBall(number: n))
                .toList(),
          ),

          const SizedBox(height: 10),

          Text(
            'Superzahl: ${result.recommendedSuperNumber ?? '-'}',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),

          const SizedBox(height: 20),

          PrimaryButton(
            label: 'Neu berechnen',
            icon: Icons.refresh,
            onPressed: () {
              context.read<LottoAppState>().notifyListeners();
            },
          ),

          const SizedBox(height: 20),

          ...result.topCandidates.take(5).map((c) {
            return ListTile(
              title: Text(c.tip.join(' - ')),
              subtitle: Text('Score: ${c.totalScore.toStringAsFixed(2)}'),
              trailing: IconButton(
                icon: const Icon(Icons.check),
                onPressed: () {
                  context.read<LottoAppState>().setGeneratedNumbers(c.tip);
                },
              ),
            );
          }),
        ],
      ),
    );
  }
}