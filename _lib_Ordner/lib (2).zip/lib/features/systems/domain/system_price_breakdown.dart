class SystemPriceBreakdown {
  final double lotto;
  final double spiel77;
  final double super6;
  final double processingFee;
  final double total;

  const SystemPriceBreakdown({
    required this.lotto,
    required this.spiel77,
    required this.super6,
    required this.processingFee,
    required this.total,
  });

  factory SystemPriceBreakdown.empty() {
    return const SystemPriceBreakdown(
      lotto: 0.0,
      spiel77: 0.0,
      super6: 0.0,
      processingFee: 0.0,
      total: 0.0,
    );
  }

  SystemPriceBreakdown copyWith({
    double? lotto,
    double? spiel77,
    double? super6,
    double? processingFee,
    double? total,
  }) {
    return SystemPriceBreakdown(
      lotto: lotto ?? this.lotto,
      spiel77: spiel77 ?? this.spiel77,
      super6: super6 ?? this.super6,
      processingFee: processingFee ?? this.processingFee,
      total: total ?? this.total,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'lotto': lotto,
      'spiel77': spiel77,
      'super6': super6,
      'processingFee': processingFee,
      'total': total,
    };
  }

  factory SystemPriceBreakdown.fromJson(Map<String, dynamic> json) {
    return SystemPriceBreakdown(
      lotto: (json['lotto'] as num?)?.toDouble() ?? 0.0,
      spiel77: (json['spiel77'] as num?)?.toDouble() ?? 0.0,
      super6: (json['super6'] as num?)?.toDouble() ?? 0.0,
      processingFee: (json['processingFee'] as num?)?.toDouble() ?? 0.0,
      total: (json['total'] as num?)?.toDouble() ?? 0.0,
    );
  }

  @override
  String toString() {
    return 'SystemPriceBreakdown('
        'lotto: $lotto, '
        'spiel77: $spiel77, '
        'super6: $super6, '
        'processingFee: $processingFee, '
        'total: $total'
        ')';
  }
}