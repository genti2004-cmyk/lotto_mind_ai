import 'system_mode.dart';
import 'vew_system_type.dart';

class SystemTicket {
  final SystemMode mode;
  final VewSystemType? vewType;
  final List<int> baseNumbers;
  final List<List<int>> rows;

  const SystemTicket({
    required this.mode,
    this.vewType,
    required this.baseNumbers,
    required this.rows,
  });

  int get rowCount => rows.length;

  Map<String, dynamic> toMap() {
    return {
      'mode': mode.name,
      'vewType': vewType?.name,
      'baseNumbers': baseNumbers,
      'rows': rows,
    };
  }

  factory SystemTicket.fromMap(Map<String, dynamic> map) {
    return SystemTicket(
      mode: SystemMode.values.firstWhere(
            (e) => e.name == map['mode'],
        orElse: () => SystemMode.full,
      ),
      vewType: map['vewType'] == null
          ? null
          : VewSystemType.values.firstWhere(
            (e) => e.name == map['vewType'],
        orElse: () => VewSystemType.vew7_3,
      ),
      baseNumbers: List<int>.from(map['baseNumbers'] as List? ?? const []),
      rows: (map['rows'] as List? ?? const [])
          .map((e) => List<int>.from(e as List))
          .toList(),
    );
  }
}