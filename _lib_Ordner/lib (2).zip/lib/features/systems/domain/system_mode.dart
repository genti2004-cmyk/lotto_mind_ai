enum SystemMode {
  full,
  vew,
}

extension SystemModeX on SystemMode {
  String get label {
    switch (this) {
      case SystemMode.full:
        return 'Vollsystem';
      case SystemMode.vew:
        return 'VEW';
    }
  }
}