import 'dart:io';

import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:share_plus/share_plus.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/section_title.dart';
import '../domain/system_price_breakdown.dart';
import '../domain/system_ticket.dart';
import '../services/system_pdf_service.dart';

class SystemPdfPreviewScreen extends StatefulWidget {
  final SystemTicket ticket;
  final SystemPriceBreakdown price;

  final bool withSpiel77;
  final bool withSuper6;
  final bool playWednesday;
  final bool playSaturday;
  final int weeks;

  const SystemPdfPreviewScreen({
    super.key,
    required this.ticket,
    required this.price,
    required this.withSpiel77,
    required this.withSuper6,
    required this.playWednesday,
    required this.playSaturday,
    required this.weeks,
  });

  @override
  State<SystemPdfPreviewScreen> createState() =>
      _SystemPdfPreviewScreenState();
}

class _SystemPdfPreviewScreenState extends State<SystemPdfPreviewScreen> {
  final _pdfService = SystemPdfService();

  File? _file;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _generate();
  }

  Future<void> _generate() async {
    final file = await _pdfService.generateTicketPdf(
      ticket: widget.ticket,
      price: widget.price,
      withSpiel77: widget.withSpiel77,
      withSuper6: widget.withSuper6,
      playWednesday: widget.playWednesday,
      playSaturday: widget.playSaturday,
      weeks: widget.weeks,
    );

    if (!mounted) return;

    setState(() {
      _file = file;
      _loading = false;
    });
  }

  Future<void> _open() async {
    if (_file == null) return;
    await OpenFilex.open(_file!.path);
  }

  Future<void> _share() async {
    if (_file == null) return;
    await Share.shareXFiles([XFile(_file!.path)]);
  }

  String _dayLabel() {
    if (widget.playWednesday && widget.playSaturday) return 'Mittwoch + Samstag';
    if (widget.playWednesday) return 'Mittwoch';
    if (widget.playSaturday) return 'Samstag';
    return '-';
  }

  @override
  Widget build(BuildContext context) {
    final rowCount = widget.ticket.rowCount;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('PDF Vorschau'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SectionTitle(
              title: 'WestLotto Abgabe-PDF',
              subtitle:
              'Spielauftrag prüfen, PDF öffnen oder direkt teilen',
            ),
            const SizedBox(height: 20),
            _PreviewCard(
              rowCount: rowCount,
              dayLabel: _dayLabel(),
              weeks: widget.weeks,
              withSpiel77: widget.withSpiel77,
              withSuper6: widget.withSuper6,
              totalPrice:
              '${widget.price.total.toStringAsFixed(2).replaceAll('.', ',')} €',
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: AppColors.border),
                boxShadow: const [
                  BoxShadow(
                    color: AppColors.shadowLight,
                    blurRadius: 18,
                    offset: Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Icon(
                    Icons.picture_as_pdf_rounded,
                    size: 110,
                    color: Colors.red.shade400,
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'Das PDF wurde erfolgreich erstellt.',
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w900,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Du kannst es jetzt öffnen oder direkt teilen.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: AppColors.textSecondary,
                      fontWeight: FontWeight.w600,
                      height: 1.35,
                    ),
                  ),
                  const SizedBox(height: 18),
                  ElevatedButton.icon(
                    onPressed: _open,
                    icon: const Icon(Icons.open_in_new),
                    label: const Text('PDF öffnen'),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(52),
                    ),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton.icon(
                    onPressed: _share,
                    icon: const Icon(Icons.share),
                    label: const Text('PDF teilen'),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(52),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PreviewCard extends StatelessWidget {
  final int rowCount;
  final String dayLabel;
  final int weeks;
  final bool withSpiel77;
  final bool withSuper6;
  final String totalPrice;

  const _PreviewCard({
    required this.rowCount,
    required this.dayLabel,
    required this.weeks,
    required this.withSpiel77,
    required this.withSuper6,
    required this.totalPrice,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.primary, AppColors.primaryDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(28),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowMedium,
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Spielauftrag Übersicht',
            style: TextStyle(
              color: Colors.white,
              fontSize: 21,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 14),
          _HeroRow(label: 'Reihen', value: '$rowCount'),
          _HeroRow(label: 'Ziehungstage', value: dayLabel),
          _HeroRow(label: 'Wochen', value: '$weeks'),
          _HeroRow(label: 'Spiel 77', value: withSpiel77 ? 'Ja' : 'Nein'),
          _HeroRow(label: 'SUPER 6', value: withSuper6 ? 'Ja' : 'Nein'),
          _HeroRow(label: 'Gesamt', value: totalPrice),
        ],
      ),
    );
  }
}

class _HeroRow extends StatelessWidget {
  final String label;
  final String value;

  const _HeroRow({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: Colors.white70,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}