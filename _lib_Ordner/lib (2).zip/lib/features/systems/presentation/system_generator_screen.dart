import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/number_ball.dart';
import '../../../core/widgets/primary_button.dart';
import '../../../core/widgets/section_title.dart';
import '../../generator/provider/lotto_app_state.dart';
import 'system_submission_screen.dart';

class SystemGeneratorScreen extends StatefulWidget {
  const SystemGeneratorScreen({super.key});

  @override
  State<SystemGeneratorScreen> createState() => _SystemGeneratorScreenState();
}

class _SystemGeneratorScreenState extends State<SystemGeneratorScreen> {
  Future<void> _generate() async {
    try {
      await context.read<LottoAppState>().generateSystemTip();
      if (!mounted) return;
      final rows = context.read<LottoAppState>().systemRows.length;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$rows Systemreihen wurden erzeugt.')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    }
  }

  Future<void> _saveRows() async {
    final added = await context.read<LottoAppState>().saveSystemRowsAsTips();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$added Systemreihen wurden gespeichert.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Systemgenerator'),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SectionTitle(
              title: 'Systemgenerator',
              subtitle:
              'Vollsystem und VEW in einer hochwertigen, klaren Oberfläche',
            ),
            const SizedBox(height: 20),
            const _HintCard(
              title: 'WestLotto Abgabe',
              text:
              'Für die spätere PDF-Abgabe werden die Systemreihen im Abgabeformat vorbereitet. Pro PDF-Seite werden maximal 12 Reihen dargestellt.',
            ),
            const SizedBox(height: 16),
            _Panel(
              title: 'Systemart',
              subtitle: 'Wähle die gewünschte Generator-Logik',
              child: Row(
                children: [
                  Expanded(
                    child: _ChoiceButton(
                      label: 'Vollsystem',
                      selected: state.systemPlayType == SystemPlayType.full,
                      onTap: () => context
                          .read<LottoAppState>()
                          .setSystemPlayType(SystemPlayType.full),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _ChoiceButton(
                      label: 'VEW',
                      selected: state.systemPlayType == SystemPlayType.vew,
                      onTap: () => context
                          .read<LottoAppState>()
                          .setSystemPlayType(SystemPlayType.vew),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _Panel(
              title: 'Systemgröße',
              subtitle: 'Definiert die Basiszahlengröße für das System',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${state.selectedSystemSize} Zahlen',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  Slider(
                    value: state.selectedSystemSize.toDouble(),
                    min: 7,
                    max: 16,
                    divisions: 9,
                    label: '${state.selectedSystemSize}',
                    onChanged: (value) {
                      context
                          .read<LottoAppState>()
                          .setSelectedSystemSize(value.round());
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _Panel(
              title: 'Manuelle Zahlen',
              subtitle: 'Optional kannst du Basiszahlen vorgeben',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _InfoLine(
                    label: 'Gewählt',
                    value: state.manualSystemNumbers.isEmpty
                        ? '-'
                        : state.manualSystemNumbers.join(' • '),
                  ),
                  const SizedBox(height: 8),
                  _InfoLine(
                    label: 'Freie Plätze',
                    value: '${state.remainingManualSystemSlots}',
                  ),
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: List.generate(49, (index) {
                      final number = index + 1;
                      final selected =
                      state.manualSystemNumbers.contains(number);
                      final disabled = !selected &&
                          state.manualSystemNumbers.length >=
                              state.selectedSystemSize;
                      return _NumberChip(
                        number: number,
                        selected: selected,
                        disabled: disabled,
                        onTap: () async {
                          try {
                            await context
                                .read<LottoAppState>()
                                .toggleManualSystemNumber(number);
                          } catch (_) {}
                        },
                      );
                    }),
                  ),
                  const SizedBox(height: 14),
                  OutlinedButton.icon(
                    onPressed: state.manualSystemNumbers.isEmpty
                        ? null
                        : () => context
                        .read<LottoAppState>()
                        .clearManualSystemNumbers(),
                    icon: const Icon(Icons.backspace_outlined),
                    label: const Text('Auswahl leeren'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _Panel(
              title: 'Aktionen',
              subtitle: 'Erzeugen, speichern und zur Abgabe wechseln',
              child: Column(
                children: [
                  PrimaryButton(
                    label: 'Systemreihen erzeugen',
                    icon: Icons.grid_view_rounded,
                    onPressed: _generate,
                  ),
                  const SizedBox(height: 10),
                  PrimaryButton(
                    label: 'Systemreihen speichern',
                    icon: Icons.save_alt_rounded,
                    onPressed: state.hasSystemRows ? _saveRows : null,
                  ),
                  const SizedBox(height: 10),
                  PrimaryButton(
                    label: 'Zur Abgabe (WestLotto)',
                    icon: Icons.arrow_forward_rounded,
                    onPressed: state.hasSystemRows
                        ? () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => const SystemSubmissionScreen(),
                        ),
                      );
                    }
                        : null,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _Panel(
              title: 'Ergebnis',
              subtitle: 'Vorschau der erzeugten Systemreihen',
              child: !state.hasSystemRows
                  ? const Text(
                'Noch keine Systemreihen vorhanden.',
                style: TextStyle(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w600,
                ),
              )
                  : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _InfoLine(
                    label: 'Basiszahlen',
                    value: state.systemBaseNumbers.join(' • '),
                  ),
                  const SizedBox(height: 8),
                  _InfoLine(
                    label: 'Reihen',
                    value: '${state.systemRows.length}',
                  ),
                  const SizedBox(height: 14),
                  ...state.systemRows
                      .take(12)
                      .toList()
                      .asMap()
                      .entries
                      .map((entry) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: 26,
                            child: Text(
                              '${entry.key + 1}.',
                              style: const TextStyle(
                                color: AppColors.textSecondary,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          Expanded(
                            child: Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: entry.value
                                  .map((n) => NumberBall(number: n))
                                  .toList(),
                            ),
                          ),
                        ],
                      ),
                    );
                  }),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HintCard extends StatelessWidget {
  final String title;
  final String text;

  const _HintCard({
    required this.title,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surfaceSoft,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(
            Icons.info_outline_rounded,
            color: AppColors.primary,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  text,
                  style: const TextStyle(
                    color: AppColors.textSecondary,
                    height: 1.35,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Panel extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;

  const _Panel({
    required this.title,
    required this.subtitle,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowLight,
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            style: const TextStyle(
              color: AppColors.textSecondary,
              height: 1.35,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 16),
          child,
        ],
      ),
    );
  }
}

class _ChoiceButton extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _ChoiceButton({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          gradient: selected
              ? const LinearGradient(
            colors: [AppColors.primary, AppColors.primaryDark],
          )
              : null,
          color: selected ? null : AppColors.surfaceSoft,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: selected ? Colors.white : AppColors.textSecondary,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ),
    );
  }
}

class _InfoLine extends StatelessWidget {
  final String label;
  final String value;

  const _InfoLine({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.right,
            style: const TextStyle(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      ],
    );
  }
}

class _NumberChip extends StatelessWidget {
  final int number;
  final bool selected;
  final bool disabled;
  final VoidCallback onTap;

  const _NumberChip({
    required this.number,
    required this.selected,
    required this.disabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final background = selected
        ? AppColors.primary
        : disabled
        ? Colors.grey.shade200
        : Colors.white;
    final foreground = selected
        ? Colors.white
        : disabled
        ? Colors.grey.shade500
        : AppColors.textSecondary;

    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: disabled ? null : onTap,
      child: Container(
        width: 40,
        height: 40,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: background,
          border: Border.all(color: AppColors.border),
        ),
        child: Text(
          '$number',
          style: TextStyle(
            color: foreground,
            fontWeight: FontWeight.w800,
            fontSize: 11,
          ),
        ),
      ),
    );
  }
}