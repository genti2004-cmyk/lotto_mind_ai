import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/primary_button.dart';
import '../../../core/widgets/section_title.dart';
import '../../generator/provider/lotto_app_state.dart';
import '../domain/system_mode.dart';
import '../domain/system_price_breakdown.dart';
import '../domain/system_ticket.dart';
import 'system_pdf_preview_screen.dart';

class SystemSubmissionScreen extends StatefulWidget {
  const SystemSubmissionScreen({super.key});

  @override
  State<SystemSubmissionScreen> createState() => _SystemSubmissionScreenState();
}

class _SystemSubmissionScreenState extends State<SystemSubmissionScreen> {
  bool _withSpiel77 = false;
  bool _withSuper6 = false;
  bool _playWednesday = true;
  bool _playSaturday = true;
  double _weeks = 1;

  int get weeks => _weeks.round().clamp(1, 12);

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();

    final hasRows = state.systemRows.isNotEmpty;
    final rowCount = state.systemRows.length;

    final drawFactor =
        (_playWednesday ? 1 : 0) + (_playSaturday ? 1 : 0);
    final safeDrawFactor = drawFactor == 0 ? 1 : drawFactor;

    final price = _buildPrice(
      rowCount,
      weeks,
      safeDrawFactor,
    );

    final ticket = SystemTicket(
      mode: state.systemPlayType == SystemPlayType.full
          ? SystemMode.full
          : SystemMode.vew,
      baseNumbers: List<int>.from(state.systemBaseNumbers),
      rows: List<List<int>>.from(
        state.systemRows.map((e) => List<int>.from(e)),
      ),
      vewType: null,
    );

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('WestLotto Abgabe')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SectionTitle(
              title: 'Spielschein Abgabe',
              subtitle:
              'Konfiguriere deinen Spielauftrag und erstelle ein PDF',
            ),
            const SizedBox(height: 20),

            _HeroCard(
              rowCount: rowCount,
              weeks: weeks,
              drawLabel: _drawLabel(),
              total: _euro(price.total),
            ),

            const SizedBox(height: 16),

            _Panel(
              title: 'Ziehungstage',
              child: Row(
                children: [
                  Expanded(
                    child: _ToggleButton(
                      label: 'Mittwoch',
                      selected: _playWednesday,
                      onTap: () {
                        setState(() {
                          _playWednesday = !_playWednesday;
                          if (!_playWednesday && !_playSaturday) {
                            _playSaturday = true;
                          }
                        });
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _ToggleButton(
                      label: 'Samstag',
                      selected: _playSaturday,
                      onTap: () {
                        setState(() {
                          _playSaturday = !_playSaturday;
                          if (!_playWednesday && !_playSaturday) {
                            _playWednesday = true;
                          }
                        });
                      },
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            _Panel(
              title: 'Zusatzlotterien',
              child: Column(
                children: [
                  SwitchListTile(
                    title: const Text('Spiel 77'),
                    value: _withSpiel77,
                    onChanged: (v) => setState(() => _withSpiel77 = v),
                  ),
                  SwitchListTile(
                    title: const Text('SUPER 6'),
                    value: _withSuper6,
                    onChanged: (v) => setState(() => _withSuper6 = v),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            _Panel(
              title: 'Wochen',
              child: Column(
                children: [
                  Text('$weeks Woche(n)'),
                  Slider(
                    value: _weeks,
                    min: 1,
                    max: 12,
                    divisions: 11,
                    label: '$weeks',
                    onChanged: (v) => setState(() => _weeks = v),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            _Panel(
              title: 'Preis',
              child: Column(
                children: [
                  _row('Reihen', '$rowCount'),
                  _row('Ziehungen', _drawLabel()),
                  _row('Wochen', '$weeks'),
                  const Divider(),
                  _row('Gesamt', _euro(price.total), bold: true),
                ],
              ),
            ),

            const SizedBox(height: 16),

            PrimaryButton(
              label: 'PDF Spielschein erstellen',
              icon: Icons.picture_as_pdf,
              onPressed: !hasRows
                  ? null
                  : () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => SystemPdfPreviewScreen(
                      ticket: ticket,
                      price: price,
                      withSpiel77: _withSpiel77,
                      withSuper6: _withSuper6,
                      playWednesday: _playWednesday,
                      playSaturday: _playSaturday,
                      weeks: weeks,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  SystemPriceBreakdown _buildPrice(
      int rows, int weeks, int draws) {
    final lotto = rows * 1.20 * weeks * draws;
    final fee = rows > 0 ? 0.35 : 0.0;

    return SystemPriceBreakdown(
      lotto: lotto,
      spiel77: _withSpiel77 ? 2.50 * weeks * draws : 0,
      super6: _withSuper6 ? 1.25 * weeks * draws : 0,
      processingFee: fee,
      total: lotto +
          fee +
          (_withSpiel77 ? 2.50 * weeks * draws : 0) +
          (_withSuper6 ? 1.25 * weeks * draws : 0),
    );
  }

  String _drawLabel() {
    if (_playWednesday && _playSaturday) return 'Mi + Sa';
    if (_playWednesday) return 'Mittwoch';
    if (_playSaturday) return 'Samstag';
    return '-';
  }

  String _euro(double v) =>
      '${v.toStringAsFixed(2).replaceAll('.', ',')} €';

  Widget _row(String l, String v, {bool bold = false}) {
    return Row(
      children: [
        Expanded(child: Text(l)),
        Text(
          v,
          style: TextStyle(
            fontWeight: bold ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ],
    );
  }
}

class _HeroCard extends StatelessWidget {
  final int rowCount;
  final int weeks;
  final String drawLabel;
  final String total;

  const _HeroCard({
    required this.rowCount,
    required this.weeks,
    required this.drawLabel,
    required this.total,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.primary, AppColors.primaryDark],
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Abgabe Übersicht',
              style: TextStyle(color: Colors.white)),
          Text('Reihen: $rowCount',
              style: const TextStyle(color: Colors.white)),
          Text('Ziehung: $drawLabel',
              style: const TextStyle(color: Colors.white)),
          Text('Wochen: $weeks',
              style: const TextStyle(color: Colors.white)),
          Text('Gesamt: $total',
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

class _Panel extends StatelessWidget {
  final String title;
  final Widget child;

  const _Panel({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style:
              const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }
}

class _ToggleButton extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _ToggleButton({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: selected
              ? AppColors.primary
              : AppColors.surfaceSoft,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: selected ? Colors.white : Colors.black,
            ),
          ),
        ),
      ),
    );
  }
}