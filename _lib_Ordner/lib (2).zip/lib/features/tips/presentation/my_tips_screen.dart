import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/app_card.dart';
import '../../../core/widgets/number_ball.dart';
import '../../../core/widgets/section_title.dart';
import '../../generator/domain/lotto_tip.dart';
import '../../generator/provider/lotto_app_state.dart';

class MyTipsScreen extends StatelessWidget {
  const MyTipsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();
    final favoriteTips = state.favoriteTips;
    final regularTips = state.regularTips;
    final hasSelectedDraw = state.selectedDrawForCheck != null;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Meine Tipps'),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
          children: [
            SectionTitle(
              title: 'Meine Tipps',
              subtitle: hasSelectedDraw
                  ? 'Favoriten, Trefferstatus und gespeicherte Reihen'
                  : 'Favoriten und gespeicherte Reihen',
              trailing: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: AppColors.infoSoft,
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: AppColors.border),
                ),
                child: Text(
                  '${state.savedTips.length} gespeichert',
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: AppColors.primary,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),

            if (favoriteTips.isNotEmpty) ...[
              const _BlockHeader(
                title: 'Favoriten',
                subtitle: 'Deine markierten Haupttipps mit Trefferstatus und Kennzahlen.',
              ),
              const SizedBox(height: 12),
              ...favoriteTips.map(
                    (tip) => Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: _TipCard(tip: tip),
                ),
              ),
              const SizedBox(height: 10),
            ],

            const _BlockHeader(
              title: 'Alle Tipps',
              subtitle: 'Alle gespeicherten Reihen sauber und ruhig aufgelistet.',
            ),
            const SizedBox(height: 12),

            if (regularTips.isEmpty && favoriteTips.isEmpty)
              const AppCard(
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 6),
                  child: Text(
                    'Noch keine Tipps gespeichert.',
                    style: TextStyle(fontSize: 15),
                  ),
                ),
              )
            else if (regularTips.isEmpty)
              const AppCard(
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 6),
                  child: Text(
                    'Alle gespeicherten Tipps sind aktuell als Favorit markiert.',
                    style: TextStyle(fontSize: 15),
                  ),
                ),
              )
            else
              ...regularTips.map(
                    (tip) => Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: _TipCard(tip: tip),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _BlockHeader extends StatelessWidget {
  final String title;
  final String subtitle;

  const _BlockHeader({
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          subtitle,
          style: const TextStyle(
            fontSize: 14,
            height: 1.45,
            color: AppColors.textSecondary,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

class _TipCard extends StatelessWidget {
  final LottoTip tip;

  const _TipCard({
    required this.tip,
  });

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();
    final hitCount = state.hitCountForTip(tip.id);
    final matchedNumbers = state.matchedNumbersForTip(tip.id);
    final sum = tip.numbers.fold<int>(0, (a, b) => a + b);
    final evenCount = tip.numbers.where((n) => n.isEven).length;
    final lowCount = tip.numbers.where((n) => n <= 24).length;

    final createdAt =
        '${tip.createdAt.day.toString().padLeft(2, '0')}.'
        '${tip.createdAt.month.toString().padLeft(2, '0')}.'
        '${tip.createdAt.year}  '
        '${tip.createdAt.hour.toString().padLeft(2, '0')}:'
        '${tip.createdAt.minute.toString().padLeft(2, '0')}';

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _TagPill(
                label: tip.source.toUpperCase(),
                color: AppColors.infoSoft,
                textColor: AppColors.primary,
              ),
              if (tip.isFavorite)
                const _TagPill(
                  label: 'FAVORIT',
                  color: AppColors.warningSoft,
                  textColor: AppColors.warning,
                ),
              if (state.selectedDrawForCheck != null)
                _TagPill(
                  label: '$hitCount Treffer',
                  color: _hitSoftColor(hitCount),
                  textColor: _hitColor(hitCount),
                ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Text(
                  createdAt,
                  style: const TextStyle(
                    fontSize: 13,
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              IconButton(
                tooltip: tip.isFavorite
                    ? 'Favorit entfernen'
                    : 'Als Favorit markieren',
                onPressed: () async {
                  await context.read<LottoAppState>().toggleTipFavorite(tip.id);
                },
                icon: Icon(
                  tip.isFavorite
                      ? Icons.star_rounded
                      : Icons.star_border_rounded,
                  color: tip.isFavorite
                      ? AppColors.warning
                      : AppColors.textMuted,
                ),
              ),
              IconButton(
                tooltip: 'Tipp loeschen',
                onPressed: () async {
                  await context.read<LottoAppState>().removeTip(tip.id);
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Tipp wurde geloescht.')),
                  );
                },
                icon: const Icon(Icons.delete_outline_rounded),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: tip.numbers
                .map(
                  (number) => NumberBall(
                number: number,
                highlighted: matchedNumbers.contains(number),
              ),
            )
                .toList(),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _StatChip(label: 'Summe', value: '$sum'),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatChip(label: 'Gerade', value: '$evenCount'),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatChip(label: 'Niedrig', value: '$lowCount'),
              ),
            ],
          ),
          if (matchedNumbers.isNotEmpty) ...[
            const SizedBox(height: 14),
            Text(
              'Trefferzahlen: ${matchedNumbers.join(', ')}',
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ],
      ),
    );
  }

  static Color _hitColor(int hits) {
    if (hits >= 4) return AppColors.success;
    if (hits == 3) return AppColors.warning;
    if (hits >= 1) return AppColors.primary;
    return AppColors.textMuted;
  }

  static Color _hitSoftColor(int hits) {
    if (hits >= 4) return AppColors.successSoft;
    if (hits == 3) return AppColors.warningSoft;
    if (hits >= 1) return AppColors.infoSoft;
    return const Color(0xFFF1F4F8);
  }
}

class _TagPill extends StatelessWidget {
  final String label;
  final Color color;
  final Color textColor;

  const _TagPill({
    required this.label,
    required this.color,
    required this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColors.border),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w800,
          color: textColor,
        ),
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;

  const _StatChip({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
      decoration: BoxDecoration(
        color: AppColors.surfaceSoft,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}