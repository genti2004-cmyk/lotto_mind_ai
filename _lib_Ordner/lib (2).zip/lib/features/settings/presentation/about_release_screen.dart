import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../domain/app_edition.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/app_card.dart';
import '../../../core/widgets/section_title.dart';
import '../../generator/provider/lotto_app_state.dart';

class AboutReleaseScreen extends StatelessWidget {
  const AboutReleaseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Release-Info'),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
          children: [
            const SectionTitle(
              title: 'Release-Info',
              subtitle: 'Produktstatus, Version und Release-Bereitschaft',
            ),
            const SizedBox(height: 20),
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const _BlockHeader(
                    title: 'App-Status',
                    subtitle:
                    'Wichtige Projektdaten und aktueller Entwicklungsstand auf einen Blick.',
                  ),
                  const SizedBox(height: 14),
                  _InfoRow(label: 'App-Name', value: 'Lotto Pro Analyzer'),
                  const SizedBox(height: 10),
                  _InfoRow(label: 'Edition', value: state.edition.label),
                  const SizedBox(height: 10),
                  _InfoRow(
                    label: 'Gespeicherte Tipps',
                    value: '${state.savedTips.length}',
                  ),
                  const SizedBox(height: 10),
                  _InfoRow(
                    label: 'Gespeicherte Ziehungen',
                    value: '${state.drawResults.length}',
                  ),
                  const SizedBox(height: 10),
                  _InfoRow(
                    label: 'Regelprofile',
                    value: '${state.ruleProfiles.length}',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _BlockHeader(
                    title: 'Release-Checkliste',
                    subtitle:
                    'Die wichtigsten technischen und strukturellen Punkte für den aktuellen Release-Status.',
                  ),
                  SizedBox(height: 14),
                  _ReleaseLine('App startet stabil'),
                  _ReleaseLine('Navigation und Generator funktionieren'),
                  _ReleaseLine('Hive-Persistenz ist aktiv'),
                  _ReleaseLine('Backup und Import sind vorbereitet'),
                  _ReleaseLine('Pro- und Future-Architektur ist vorbereitet'),
                  _ReleaseLine('UI wurde auf ein einheitliches Theme umgestellt'),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _BlockHeader(
                    title: 'Empfohlene letzte Schritte vor dem Release',
                    subtitle:
                    'Diese letzten Prüfungen solltest du vor dem finalen Build noch durchgehen.',
                  ),
                  SizedBox(height: 14),
                  Text(
                    '1. App-Icon finalisieren\n'
                        '2. Splash-Screen prüfen\n'
                        '3. Versionsnummer in der pubspec erhöhen\n'
                        '4. Android Manifest und iOS Display Name prüfen\n'
                        '5. Release-Build auf echtem Gerät testen\n'
                        '6. Backup-Import und Export real testen',
                    style: TextStyle(
                      height: 1.5,
                      color: AppColors.textSecondary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BlockHeader extends StatelessWidget {
  final String title;
  final String subtitle;

  const _BlockHeader({
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          subtitle,
          style: const TextStyle(
            color: AppColors.textSecondary,
            fontWeight: FontWeight.w500,
            height: 1.45,
          ),
        ),
      ],
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;

  const _InfoRow({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.end,
            style: const TextStyle(
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
        ),
      ],
    );
  }
}

class _ReleaseLine extends StatelessWidget {
  final String text;

  const _ReleaseLine(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          const Icon(
            Icons.check_circle_rounded,
            size: 18,
            color: AppColors.success,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}