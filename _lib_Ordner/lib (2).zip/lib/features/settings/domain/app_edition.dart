enum AppEdition {
  free,
  pro,
  future,
}

extension AppEditionX on AppEdition {
  String get key {
    switch (this) {
      case AppEdition.free:
        return 'free';
      case AppEdition.pro:
        return 'pro';
      case AppEdition.future:
        return 'future';
    }
  }

  String get label {
    switch (this) {
      case AppEdition.free:
        return 'Free Version';
      case AppEdition.pro:
        return 'Pro Version';
      case AppEdition.future:
        return 'Future Version';
    }
  }

  String get subtitle {
    switch (this) {
      case AppEdition.free:
        return 'Basis Funktionen fuer Einstieg';
      case AppEdition.pro:
        return 'Erweiterte Analyse und Systeme';
      case AppEdition.future:
        return 'KI Analyse, Trends und Prognosen';
    }
  }

  static AppEdition fromKey(String? value) {
    switch (value) {
      case 'pro':
        return AppEdition.pro;
      case 'future':
        return AppEdition.future;
      case 'free':
      default:
        return AppEdition.free;
    }
  }
}