enum SystemGameTab {
  normal,
  full,
  vew,
}

enum FullSystemType {
  fs007,
  fs008,
  fs009,
  fs010,
}

extension FullSystemTypeX on FullSystemType {
  String get code {
    switch (this) {
      case FullSystemType.fs007:
        return '007';
      case FullSystemType.fs008:
        return '008';
      case FullSystemType.fs009:
        return '009';
      case FullSystemType.fs010:
        return '010';
    }
  }

  int get selectedNumbers {
    switch (this) {
      case FullSystemType.fs007:
        return 7;
      case FullSystemType.fs008:
        return 8;
      case FullSystemType.fs009:
        return 9;
      case FullSystemType.fs010:
        return 10;
    }
  }

  int get rowCount {
    switch (this) {
      case FullSystemType.fs007:
        return 7;
      case FullSystemType.fs008:
        return 28;
      case FullSystemType.fs009:
        return 84;
      case FullSystemType.fs010:
        return 210;
    }
  }

  String get title => 'Vollsystem $code';

  String get subtitle => '$selectedNumbers Zahlen · $rowCount Reihen';
}

class VewPreset {
  const VewPreset({
    required this.code,
    required this.name,
    required this.stammzahlen,
    required this.reihen,
    required this.hinweis,
  });

  final String code;
  final String name;
  final int stammzahlen;
  final int reihen;
  final String hinweis;
}

class PriceBreakdown {
  const PriceBreakdown({
    required this.baseAmount,
    required this.spiel77Amount,
    required this.super6Amount,
    required this.drawCount,
    required this.processingFee,
  });

  final double baseAmount;
  final double spiel77Amount;
  final double super6Amount;
  final int drawCount;
  final double processingFee;

  double get subtotalPerDraw => baseAmount + spiel77Amount + super6Amount;
  double get totalWithoutProcessing => subtotalPerDraw * drawCount;
  double get total => totalWithoutProcessing + processingFee;
}
