// FINAL UI PRO DASHBOARD (komplett ersetzt)

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/number_ball.dart';
import '../../../core/widgets/primary_button.dart';
import '../../../core/widgets/section_title.dart';
import '../../generator/provider/lotto_app_state.dart';
import '../../statistics/presentation/statistics_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();
    final lastTip = state.lastGeneratedTip;
    final bestTip = state.bestAnalyzedTip;
    final simulation = state.lastTipSimulation;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
          children: [
            const SectionTitle(
              title: 'Übersicht',
              subtitle: 'Dein Arbeitsbereich für Tipps, Analyse und Ergebnisse',
            ),

            const SizedBox(height: 20),

            /// HERO
            _HeroCard(
              hasTip: lastTip != null,
              onRandomTap: () async {
                await context.read<LottoAppState>().generateRandomTip();
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Zufallstipp erstellt')),
                );
              },
              onAnalysisTap: () async {
                await context.read<LottoAppState>().generateAnalysisTip();
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('AI Tipp erstellt')),
                );
              },
              onSaveTap: lastTip == null
                  ? null
                  : () async {
                await context.read<LottoAppState>().saveLastTip();
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Tipp gespeichert')),
                );
              },
              onStatisticsTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => const StatisticsScreen(),
                  ),
                );
              },
            ),

            const SizedBox(height: 18),

            /// METRICS
            Row(
              children: [
                Expanded(
                  child: _MetricCard(
                    title: 'Tipps',
                    value: '${state.savedTips.length}',
                    icon: Icons.confirmation_number,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _MetricCard(
                    title: 'Favoriten',
                    value: '${state.favoriteTips.length}',
                    icon: Icons.star,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _MetricCard(
                    title: 'Ziehungen',
                    value: '${state.drawResults.length}',
                    icon: Icons.bar_chart,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 18),

            /// LETZTER TIPP
            _PremiumCard(
              title: 'Letzter Tipp',
              subtitle: 'Zuletzt erzeugte Zahlen',
              child: lastTip == null
                  ? const _EmptyText('Noch kein Tipp vorhanden')
                  : Column(
                children: [
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children:
                    lastTip.map((n) => NumberBall(number: n)).toList(),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: _MiniStat(
                          label: 'Summe',
                          value:
                          '${lastTip.fold<int>(0, (a, b) => a + b)}',
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _MiniStat(
                          label: 'Gerade',
                          value:
                          '${lastTip.where((n) => n.isEven).length}',
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _MiniStat(
                          label: '≤ 24',
                          value:
                          '${lastTip.where((n) => n <= 24).length}',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 18),

            /// AI PRO
            _PremiumCard(
              title: 'AI Pro Empfehlung',
              subtitle: 'Optimierter Tipp basierend auf Analyse',
              child: bestTip.length != 6
                  ? const _EmptyText('Noch keine Empfehlung vorhanden')
                  : Wrap(
                spacing: 8,
                runSpacing: 8,
                children:
                bestTip.map((n) => NumberBall(number: n)).toList(),
              ),
            ),

            const SizedBox(height: 18),

            /// SIMULATION
            _PremiumCard(
              title: 'Rücktest',
              subtitle: 'Trefferverteilung deines letzten Tipps',
              child: simulation == null
                  ? const _EmptyText('Noch kein Rücktest verfügbar')
                  : Column(
                children: List.generate(7, (hits) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: _InfoLine(
                      label: '$hits Richtige',
                      value: '${simulation.getHitCount(hits)}',
                    ),
                  );
                }),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  final bool hasTip;
  final Future<void> Function() onRandomTap;
  final Future<void> Function() onAnalysisTap;
  final Future<void> Function()? onSaveTap;
  final VoidCallback onStatisticsTap;

  const _HeroCard({
    required this.hasTip,
    required this.onRandomTap,
    required this.onAnalysisTap,
    required this.onSaveTap,
    required this.onStatisticsTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(
          colors: [AppColors.primary, AppColors.primaryDark],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Smart Generator',
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Schnell Tipps generieren und analysieren',
            style: TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 18),
          PrimaryButton(label: 'Zufall', onPressed: onRandomTap),
          const SizedBox(height: 10),
          PrimaryButton(label: 'Analyse', onPressed: onAnalysisTap),
          const SizedBox(height: 10),
          PrimaryButton(
            label: hasTip ? 'Speichern' : 'Kein Tipp',
            onPressed: onSaveTap,
          ),
        ],
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _MetricCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: AppColors.primary),
          const SizedBox(height: 10),
          Text(value,
              style:
              const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text(title),
        ],
      ),
    );
  }
}

class _PremiumCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;

  const _PremiumCard({
    required this.title,
    required this.subtitle,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(28),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style:
              const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: Colors.grey)),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String label;
  final String value;

  const _MiniStat({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(label),
      ],
    );
  }
}

class _InfoLine extends StatelessWidget {
  final String label;
  final String value;

  const _InfoLine({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(label)),
        Text(value),
      ],
    );
  }
}

class _EmptyText extends StatelessWidget {
  final String text;

  const _EmptyText(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(text, style: const TextStyle(color: Colors.grey));
  }
}