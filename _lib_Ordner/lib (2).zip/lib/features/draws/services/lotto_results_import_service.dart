import 'dart:convert';
import 'dart:io';

import '../domain/draw_result.dart';

class LottoResultsImportService {
  static const String _latestUrl = 'https://www.lotto.net/german-lotto/results';

  Future<List<DrawResult>> fetchLatestResults() async {
    final body = await _download(_latestUrl);
    return _parseResultsFromHtml(body);
  }

  Future<List<DrawResult>> fetchYearResults(int year) async {
    final body = await _download('https://www.lotto.net/german-lotto/results/$year');
    return _parseResultsFromHtml(body);
  }

  Future<String> _download(String url) async {
    final client = HttpClient();
    client.userAgent = 'Mozilla/5.0 (Flutter Lotto Pro Analyzer)';
    try {
      final request = await client.getUrl(Uri.parse(url));
      final response = await request.close();

      if (response.statusCode != 200) {
        throw Exception('Import fehlgeschlagen (HTTP ${response.statusCode}).');
      }

      return await response.transform(utf8.decoder).join();
    } finally {
      client.close(force: true);
    }
  }

  List<DrawResult> _parseResultsFromHtml(String html) {
    final text = _htmlToPlainText(html);

    final headingRegex = RegExp(
      r'(Wednesday|Saturday)\s+([A-Za-z]+)\s+(\d{1,2})(?:st|nd|rd|th)?\s+(\d{4})',
      multiLine: true,
    );

    final matches = headingRegex.allMatches(text).toList();
    final results = <DrawResult>[];

    for (int i = 0; i < matches.length; i++) {
      final match = matches[i];

      final monthName = match.group(2)!;
      final day = int.tryParse(match.group(3)!);
      final year = int.tryParse(match.group(4)!);
      final month = _monthFromEnglish(monthName);

      if (day == null || year == null || month == null) continue;

      final start = match.end;
      final end = i + 1 < matches.length ? matches[i + 1].start : text.length;
      final block = text.substring(start, end);

      final mainNumbers = _extractMainNumbers(block);
      if (mainNumbers.length < 6) continue;

      final drawDate = DateTime(year, month, day);

      results.add(
        DrawResult(
          id: '${drawDate.toIso8601String()}-${mainNumbers.join('-')}',
          drawDate: drawDate,
          numbers: mainNumbers,
          superNumber: _extractSuperNumber(block),
          spiel77: _extractSpiel77(block),
          super6: _extractSuper6(block),
        ),
      );
    }

    final deduped = <String, DrawResult>{};
    for (final result in results) {
      deduped['${result.drawDate.toIso8601String()}-${result.numbers.join('-')}'] =
          result;
    }

    return deduped.values.toList()
      ..sort((a, b) => b.drawDate.compareTo(a.drawDate));
  }

  List<int> _extractMainNumbers(String block) {
    final rawNumbers = RegExp(r'\b([0-9]{1,2})\b')
        .allMatches(block)
        .map((m) => int.tryParse(m.group(1) ?? ''))
        .whereType<int>()
        .where((n) => n >= 0 && n <= 49)
        .toList();

    if (rawNumbers.length < 6) return const [];
    return rawNumbers.take(6).toList()..sort();
  }

  int? _extractSuperNumber(String block) {
    final superMatch = RegExp(
      r'(?:Superzahl|Super)\s*[:\-]?\s*(\d)\b',
      caseSensitive: false,
    ).firstMatch(block);

    if (superMatch != null) {
      return int.tryParse(superMatch.group(1) ?? '');
    }

    final rawNumbers = RegExp(r'\b([0-9]{1,2})\b')
        .allMatches(block)
        .map((m) => int.tryParse(m.group(1) ?? ''))
        .whereType<int>()
        .where((n) => n >= 0 && n <= 49)
        .toList();

    return rawNumbers.length >= 7 ? rawNumbers[6] : null;
  }

  String? _extractSpiel77(String block) {
    return _extractDigitGame(
      block,
      patterns: const [
        'Spiel 77',
        'Spiel77',
      ],
      length: 7,
    );
  }

  String? _extractSuper6(String block) {
    return _extractDigitGame(
      block,
      patterns: const [
        'SUPER 6',
        'SUPER6',
      ],
      length: 6,
    );
  }

  String? _extractDigitGame(
      String block, {
        required List<String> patterns,
        required int length,
      }) {
    for (final patternText in patterns) {
      final labelPattern = patternText.replaceAll(' ', r'\s*');

      final spaced = RegExp(
        '$labelPattern[^0-9]{0,60}((?:[0-9]\\s*){$length})',
        caseSensitive: false,
      ).firstMatch(block);

      if (spaced != null) {
        final digits = spaced.group(1)?.replaceAll(RegExp(r'\D'), '') ?? '';
        if (digits.length == length) return digits;
      }

      final compact = RegExp(
        '$labelPattern[^0-9]{0,60}([0-9]{$length})',
        caseSensitive: false,
      ).firstMatch(block);

      if (compact != null) {
        final digits = compact.group(1)?.replaceAll(RegExp(r'\D'), '') ?? '';
        if (digits.length == length) return digits;
      }
    }

    return null;
  }

  String _htmlToPlainText(String html) {
    var text = html;

    text = text.replaceAll(
      RegExp(r'<script[\s\S]*?</script>', caseSensitive: false),
      ' ',
    );
    text = text.replaceAll(
      RegExp(r'<style[\s\S]*?</style>', caseSensitive: false),
      ' ',
    );
    text = text.replaceAll(RegExp(r'<!--[\s\S]*?-->'), ' ');
    text = text.replaceAll(RegExp(r'<[^>]+>'), '\n');

    return text
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&amp;', '&')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&uuml;', 'ü')
        .replaceAll('&ouml;', 'ö')
        .replaceAll('&auml;', 'ä')
        .replaceAll('&Uuml;', 'Ü')
        .replaceAll('&Ouml;', 'Ö')
        .replaceAll('&Auml;', 'Ä')
        .replaceAll('&szlig;', 'ß');
  }

  int? _monthFromEnglish(String name) {
    switch (name.toLowerCase()) {
      case 'january':
        return 1;
      case 'february':
        return 2;
      case 'march':
        return 3;
      case 'april':
        return 4;
      case 'may':
        return 5;
      case 'june':
        return 6;
      case 'july':
        return 7;
      case 'august':
        return 8;
      case 'september':
        return 9;
      case 'october':
        return 10;
      case 'november':
        return 11;
      case 'december':
        return 12;
      default:
        return null;
    }
  }
}