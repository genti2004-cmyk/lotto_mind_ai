import 'dart:convert';
import 'dart:io';

import '../domain/draw_result.dart';

class LottoResultsImportService {
  static const String _latestUrl = 'https://www.lotto.net/german-lotto/results';

  Future<List<DrawResult>> fetchLatestResults() async {
    final body = await _download(_latestUrl);
    return _parseResultsFromHtml(body);
  }

  Future<List<DrawResult>> fetchYearResults(int year) async {
    final body = await _download(
      'https://www.lotto.net/german-lotto/results/$year',
    );
    return _parseResultsFromHtml(body);
  }

  Future<String> _download(String url) async {
    final client = HttpClient();
    client.userAgent = 'Mozilla/5.0 (Flutter Lotto Mind AI)';

    try {
      final request = await client.getUrl(Uri.parse(url));
      final response = await request.close();

      if (response.statusCode != 200) {
        throw Exception('Import fehlgeschlagen (HTTP ${response.statusCode}).');
      }

      return response.transform(utf8.decoder).join();
    } finally {
      client.close(force: true);
    }
  }

  List<DrawResult> _parseResultsFromHtml(String html) {
    final text = _htmlToPlainText(html);

    final headingRegex = RegExp(
      r'(Wednesday|Saturday)\s+([A-Za-z]+)\s+(\d{1,2})(?:st|nd|rd|th)?\s+(\d{4})',
      multiLine: true,
    );

    final matches = headingRegex.allMatches(text).toList();
    final results = <DrawResult>[];

    for (var i = 0; i < matches.length; i++) {
      final match = matches[i];
      final monthName = match.group(2)!;
      final day = int.tryParse(match.group(3)!);
      final year = int.tryParse(match.group(4)!);
      final month = _monthFromEnglish(monthName);

      if (day == null || year == null || month == null) continue;

      final start = match.end;
      final end = i + 1 < matches.length ? matches[i + 1].start : text.length;
      final block = text.substring(start, end);

      final mainNumbers = _extractMainNumbers(block);
      if (mainNumbers.length != 6) continue;

      final drawDate = DateTime(year, month, day);
      final id = '${drawDate.toIso8601String()}-${mainNumbers.join('-')}';

final parsedSuperNumber = _extractSuperNumber(block);
final parsedSpiel77 = _extractSpiel77(block);
final parsedSuper6 = _extractSuper6(block);

results.add(
DrawResult(
id: '${drawDate.toIso8601String()}-${mainNumbers.join('-')}',
drawDate: drawDate,
numbers: mainNumbers,
superNumber: parsedSuperNumber,
spiel77: parsedSpiel77,
super6: parsedSuper6,
),
);

    }

    final deduped = <String, DrawResult>{};
    for (final result in results) {
      deduped[result.id] = result;
    }

    return deduped.values.toList()
      ..sort((a, b) => b.drawDate.compareTo(a.drawDate));
  }

  List<int> _extractMainNumbers(String block) {
    final rawNumbers = RegExp(r'\b([0-9]{1,2})\b')
        .allMatches(block)
        .map((m) => int.tryParse(m.group(1) ?? ''))
        .whereType<int>()
        .where((n) => n >= 1 && n <= 49)
        .toList();

    if (rawNumbers.length < 6) return const [];

    final numbers = rawNumbers.take(6).toList()..sort();
    return numbers;
  }

  int? _extractSuperNumber(String block) {
    final labelMatch = RegExp(
      r'(?:Superzahl|Super\s*number|Super)\s*[:\-]?\s*(\d)\b',
      caseSensitive: false,
    ).firstMatch(block);

    if (labelMatch != null) {
      return int.tryParse(labelMatch.group(1) ?? '');
    }

    final rawNumbers = RegExp(r'\b([0-9]{1,2})\b')
        .allMatches(block)
        .map((m) => int.tryParse(m.group(1) ?? ''))
        .whereType<int>()
        .toList();

    if (rawNumbers.length >= 7) {
      final candidate = rawNumbers[6];
      if (candidate >= 0 && candidate <= 9) return candidate;
    }

    return null;
  }

  String? _extractSpiel77(String block) {
    return _extractDigitGame(
      block,
      labels: const ['Spiel 77', 'Spiel77'],
      length: 7,
    );
  }

  String? _extractSuper6(String block) {
    return _extractDigitGame(
      block,
      labels: const ['SUPER 6', 'SUPER6', 'Super 6', 'Super6'],
      length: 6,
    );
  }

  String? _extractDigitGame(
      String block, {
        required List<String> labels,
        required int length,
      }) {
    for (final label in labels) {
      final labelPattern = RegExp.escape(label).replaceAll(r'\ ', r'\s*');
      final compact = RegExp(
        '$labelPattern[^0-9]{0,80}([0-9]{$length})',
        caseSensitive: false,
      ).firstMatch(block);

      if (compact != null) {
        final digits = _onlyDigits(compact.group(1) ?? '');
        if (digits.length == length) return digits;
      }

      final spaced = RegExp(
        '$labelPattern[^0-9]{0,80}((?:[0-9][^0-9]*){$length})',
        caseSensitive: false,
      ).firstMatch(block);

      if (spaced != null) {
        final digits = _onlyDigits(spaced.group(1) ?? '');
        if (digits.length == length) return digits;
      }
    }

    return null;
  }

  String _onlyDigits(String input) {
    return input.replaceAll(RegExp(r'[^0-9]'), '');
  }

  String _htmlToPlainText(String html) {
    var text = html;

    text = text.replaceAll(
      RegExp(r'<script[\s\S]*?</script>', caseSensitive: false),
      ' ',
    );
    text = text.replaceAll(
      RegExp(r'<style[\s\S]*?</style>', caseSensitive: false),
      ' ',
    );
    text = text.replaceAll(RegExp(r'<!--[\s\S]*?-->'), ' ');
    text = text.replaceAll(RegExp(r'<[^>]+>'), '\n');

    return text
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&amp;', '&')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&uuml;', 'ü')
        .replaceAll('&ouml;', 'ö')
        .replaceAll('&auml;', 'ä')
        .replaceAll('&Uuml;', 'Ü')
        .replaceAll('&Ouml;', 'Ö')
        .replaceAll('&Auml;', 'Ä')
        .replaceAll('&szlig;', 'ß')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  int? _monthFromEnglish(String name) {
    switch (name.toLowerCase()) {
      case 'january':
        return 1;
      case 'february':
        return 2;
      case 'march':
        return 3;
      case 'april':
        return 4;
      case 'may':
        return 5;
      case 'june':
        return 6;
      case 'july':
        return 7;
      case 'august':
        return 8;
      case 'september':
        return 9;
      case 'october':
        return 10;
      case 'november':
        return 11;
      case 'december':
        return 12;
      default:
        return null;
    }
  }
}
