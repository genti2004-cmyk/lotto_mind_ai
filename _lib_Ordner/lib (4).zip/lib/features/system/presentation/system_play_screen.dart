import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'package:lotto_mind_ai/features/generator/provider/lotto_app_state.dart';

/// Final PRO Systemspiel screen for Lotto Mind AI.
///
/// Enthält:
/// - Normalschein
/// - Vollsystem mit 7–12 Zahlen
/// - VEW-Vorschau
/// - Top-10 Analyseübernahme
/// - Superzahl, Zusatzzahl, Spiel 77, Super 6 Anzeige
class SystemPlayScreen extends StatefulWidget {
  const SystemPlayScreen({super.key});

  @override
  State<SystemPlayScreen> createState() => _SystemPlayScreenState();
}

/// Kompatibilitätsname, falls deine Navigation noch diesen Screen nutzt.
class SystemGeneratorScreen extends StatelessWidget {
  const SystemGeneratorScreen({super.key});

  @override
  Widget build(BuildContext context) => const SystemPlayScreen();
}

class _SystemPlayScreenState extends State<SystemPlayScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  final Set<int> _selectedNumbers = <int>{};
  static const double _pricePerRow = 1.20;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _refreshOptionalGames() {
    // Spiel 77 und Super 6 kommen direkt aus LottoAppState.
    // setState triggert nur eine neue Anzeige/Neuberechnung der Getter.
    setState(() {});
  }

  void _toggleNumber(int number, {required int max}) {
    HapticFeedback.selectionClick();
    setState(() {
      if (_selectedNumbers.contains(number)) {
        _selectedNumbers.remove(number);
        return;
      }
      if (_selectedNumbers.length < max) {
        _selectedNumbers.add(number);
      } else {
        _showSnack('Maximal $max Zahlen möglich.');
      }
    });
  }

  void _clearNumbers() {
    setState(_selectedNumbers.clear);
  }

  void _useTop10(LottoAppState state) {
    final top = state.top10Numbers.take(10).toList()..sort();
    if (top.isEmpty) {
      _showSnack('Noch keine Analysezahlen vorhanden. Bitte Ziehungen importieren.');
      return;
    }
    HapticFeedback.mediumImpact();
    setState(() {
      _selectedNumbers
        ..clear()
        ..addAll(top);
    });
    _showSnack('Top 10 Analysezahlen übernommen.');
  }

  int _rowsForFullSystem(int count) {
    if (count < 6) return 0;
    return _nCr(count, 6);
  }

  int _rowsForVew(int count) {
    if (count < 7) return 0;
    // Vereinfachte VEW-Vorschau: 2 Reihen pro gewählter Zahl.
    // Später kann hier eine echte VEW-Matrix hinterlegt werden.
    return count * 2;
  }

  int _nCr(int n, int r) {
    if (r > n) return 0;
    if (r == 0 || r == n) return 1;
    var result = 1;
    for (var i = 0; i < r; i++) {
      result = result * (n - i) ~/ (i + 1);
    }
    return result;
  }

  List<int> get _sortedNumbers => _selectedNumbers.toList()..sort();

  String _euro(double value) => '${value.toStringAsFixed(2).replaceAll('.', ',')} €';

  void _copySystemText({required String label, required int rows}) {
    final state = context.read<LottoAppState>();
    final numbers = _sortedNumbers.join(', ');
    final text = '''Lotto Mind AI - $label
Zahlen: $numbers
Reihen: $rows
Preis: ${_euro(rows * _pricePerRow)}
Superzahl: ${state.superZahl}
Zusatzzahl: ${state.zusatzZahl ?? '-'}
Spiel 77: ${state.spiel77}
Super 6: ${state.super6}''';

    Clipboard.setData(ClipboardData(text: text));
    _showSnack('Systemschein kopiert.');
  }

  void _showSnack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        content: Text(message),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();

    return Scaffold(
      backgroundColor: const Color(0xFFF3F6FB),
      appBar: AppBar(
        title: const Text('Systemspiel'),
        centerTitle: false,
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Normalschein'),
            Tab(text: 'Vollsystem'),
            Tab(text: 'VEW'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildNormalTab(state),
          _buildFullTab(state),
          _buildVewTab(state),
        ],
      ),
    );
  }

  Widget _buildNormalTab(LottoAppState state) {
    final rows = _selectedNumbers.length >= 6 ? 1 : 0;
    return _SystemTabShell(
      children: [
        _InfoHero(
          title: 'Normalschein',
          subtitle: 'Wähle exakt 6 Zahlen oder übernimm die Analyse-Auswahl.',
          icon: Icons.confirmation_number_rounded,
        ),
        _ActionRow(
          onTop10: () => _useTop10(state),
          onClear: _clearNumbers,
          onRefresh: _refreshOptionalGames,
        ),
        _NumberGrid(
          selectedNumbers: _selectedNumbers,
          maxNumbers: 10,
          onToggle: (n) => _toggleNumber(n, max: 10),
        ),
        _PreviewCard(
          title: 'Normalschein Vorschau',
          selectedNumbers: _sortedNumbers,
          rows: rows,
          price: rows * _pricePerRow,
          minHint: 'Mindestens 6 Zahlen auswählen.',
          isReady: _selectedNumbers.length >= 6,
        ),
        _OptionalGamesCard(
          superzahl: state.superZahl,
          zusatzzahl: state.zusatzZahl,
          spiel77: state.spiel77.trim().isNotEmpty ? state.spiel77 : '7702026',
          super6: state.super6.trim().isNotEmpty ? state.super6 : '620026',
          onRefresh: _refreshOptionalGames,
        ),
        _PrimaryActionButton(
          label: 'Normalschein kopieren',
          enabled: rows > 0,
          onPressed: () => _copySystemText(label: 'Normalschein', rows: rows),
        ),
      ],
    );
  }

  Widget _buildFullTab(LottoAppState state) {
    final count = _selectedNumbers.length;
    final rows = _rowsForFullSystem(count);
    return _SystemTabShell(
      children: [
        _InfoHero(
          title: 'Vollsystem',
          subtitle: 'Wähle 7 bis 12 Zahlen. Alle 6er-Kombinationen werden berechnet.',
          icon: Icons.grid_view_rounded,
        ),
        _ActionRow(
          onTop10: () => _useTop10(state),
          onClear: _clearNumbers,
          onRefresh: _refreshOptionalGames,
        ),
        _NumberGrid(
          selectedNumbers: _selectedNumbers,
          maxNumbers: 12,
          onToggle: (n) => _toggleNumber(n, max: 12),
        ),
        _PreviewCard(
          title: 'Vollsystem Vorschau',
          selectedNumbers: _sortedNumbers,
          rows: rows,
          price: rows * _pricePerRow,
          minHint: 'Ab 7 Zahlen wird das Vollsystem interessant.',
          isReady: count >= 7,
        ),
        _OptionalGamesCard(
          superzahl: state.superZahl,
          zusatzzahl: state.zusatzZahl,
          spiel77: state.spiel77,
          super6: state.super6,
          onRefresh: _refreshOptionalGames,
        ),
        _PrimaryActionButton(
          label: 'Vollsystem kopieren',
          enabled: rows > 0,
          onPressed: () => _copySystemText(label: 'Vollsystem', rows: rows),
        ),
      ],
    );
  }

  Widget _buildVewTab(LottoAppState state) {
    final count = _selectedNumbers.length;
    final rows = _rowsForVew(count);
    return _SystemTabShell(
      children: [
        _InfoHero(
          title: 'VEW-System',
          subtitle: 'Verdichtete Systemvorschau mit analysebasierter Zahlenbasis.',
          icon: Icons.auto_graph_rounded,
        ),
        _ActionRow(
          onTop10: () => _useTop10(state),
          onClear: _clearNumbers,
          onRefresh: _refreshOptionalGames,
        ),
        _NumberGrid(
          selectedNumbers: _selectedNumbers,
          maxNumbers: 12,
          onToggle: (n) => _toggleNumber(n, max: 12),
        ),
        _PreviewCard(
          title: 'VEW Vorschau',
          selectedNumbers: _sortedNumbers,
          rows: rows,
          price: rows * _pricePerRow,
          minHint: 'Für VEW mindestens 7 Zahlen wählen.',
          isReady: count >= 7,
        ),
        _OptionalGamesCard(
          superzahl: state.superZahl,
          zusatzzahl: state.zusatzZahl,
          spiel77: state.spiel77,
          super6: state.super6,
          onRefresh: _refreshOptionalGames,
        ),
        _PrimaryActionButton(
          label: 'VEW-System kopieren',
          enabled: rows > 0,
          onPressed: () => _copySystemText(label: 'VEW-System', rows: rows),
        ),
      ],
    );
  }
}

class _SystemTabShell extends StatelessWidget {
  const _SystemTabShell({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
      itemBuilder: (context, index) => children[index],
      separatorBuilder: (_, __) => const SizedBox(height: 14),
      itemCount: children.length,
    );
  }
}

class _InfoHero extends StatelessWidget {
  const _InfoHero({
    required this.title,
    required this.subtitle,
    required this.icon,
  });

  final String title;
  final String subtitle;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF123B8A), Color(0xFF1E63E9)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
        boxShadow: const [
          BoxShadow(
            color: Color(0x22123B8A),
            blurRadius: 18,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(icon, color: Colors.white),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: Color(0xFFE8EEFF),
                    fontSize: 13,
                    height: 1.3,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ActionRow extends StatelessWidget {
  const _ActionRow({
    required this.onTop10,
    required this.onClear,
    required this.onRefresh,
  });

  final VoidCallback onTop10;
  final VoidCallback onClear;
  final VoidCallback onRefresh;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        _SmallActionButton(
          icon: Icons.auto_awesome_rounded,
          label: 'Top 10 Analyse',
          onTap: onTop10,
        ),
        _SmallActionButton(
          icon: Icons.refresh_rounded,
          label: 'Spiel 77 / Super 6 neu',
          onTap: onRefresh,
        ),
        _SmallActionButton(
          icon: Icons.backspace_outlined,
          label: 'Leeren',
          onTap: onClear,
        ),
      ],
    );
  }
}

class _SmallActionButton extends StatelessWidget {
  const _SmallActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 18),
      label: Text(label),
      style: OutlinedButton.styleFrom(
        foregroundColor: const Color(0xFF123B8A),
        side: const BorderSide(color: Color(0xFFD5DEEF)),
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      ),
    );
  }
}

class _NumberGrid extends StatelessWidget {
  const _NumberGrid({
    required this.selectedNumbers,
    required this.maxNumbers,
    required this.onToggle,
  });

  final Set<int> selectedNumbers;
  final int maxNumbers;
  final ValueChanged<int> onToggle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFE1E7F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Zahlen wählen',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                ),
              ),
              Text(
                '${selectedNumbers.length}/$maxNumbers',
                style: const TextStyle(
                  color: Color(0xFF47627A),
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          GridView.builder(
            itemCount: 49,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 7,
              mainAxisSpacing: 7,
              crossAxisSpacing: 7,
              childAspectRatio: 1,
            ),
            itemBuilder: (context, index) {
              final number = index + 1;
              final selected = selectedNumbers.contains(number);
              return InkWell(
                borderRadius: BorderRadius.circular(999),
                onTap: () => onToggle(number),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 130),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: selected ? const Color(0xFF1B4FD6) : const Color(0xFFF7F9FD),
                    border: Border.all(
                      color: selected ? const Color(0xFF1B4FD6) : const Color(0xFFD9E1EC),
                    ),
                    boxShadow: selected
                        ? const [
                      BoxShadow(
                        color: Color(0x221B4FD6),
                        blurRadius: 8,
                        offset: Offset(0, 4),
                      ),
                    ]
                        : const [],
                  ),
                  child: Center(
                    child: Text(
                      '$number',
                      style: TextStyle(
                        color: selected ? Colors.white : const Color(0xFF1D2A39),
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _PreviewCard extends StatelessWidget {
  const _PreviewCard({
    required this.title,
    required this.selectedNumbers,
    required this.rows,
    required this.price,
    required this.minHint,
    required this.isReady,
  });

  final String title;
  final List<int> selectedNumbers;
  final int rows;
  final double price;
  final String minHint;
  final bool isReady;

  String _euro(double value) => '${value.toStringAsFixed(2).replaceAll('.', ',')} €';

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFE1E7F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: selectedNumbers.isEmpty
                ? [
              const Text(
                'Noch keine Zahlen gewählt.',
                style: TextStyle(color: Color(0xFF6D7D90)),
              ),
            ]
                : selectedNumbers
                .map((n) => Chip(
              label: Text('$n'),
              backgroundColor: const Color(0xFFEAF0FF),
              labelStyle: const TextStyle(fontWeight: FontWeight.w800),
            ))
                .toList(),
          ),
          const SizedBox(height: 12),
          _InfoLine(label: 'Reihen', value: '$rows'),
          _InfoLine(label: 'Preis', value: _euro(price)),
          if (!isReady) ...[
            const SizedBox(height: 8),
            Text(
              minHint,
              style: const TextStyle(
                color: Color(0xFF8A5A00),
                fontSize: 13,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _OptionalGamesCard extends StatelessWidget {
  const _OptionalGamesCard({
    required this.superzahl,
    required this.zusatzzahl,
    required this.spiel77,
    required this.super6,
    required this.onRefresh,
  });

  final int superzahl;
  final int? zusatzzahl;
  final String spiel77;
  final String super6;
  final VoidCallback onRefresh;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFE1E7F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Zusatzspiele',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                ),
              ),
              IconButton(
                tooltip: 'Neu berechnen',
                onPressed: onRefresh,
                icon: const Icon(Icons.refresh_rounded),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _InfoLine(label: 'Superzahl', value: '$superzahl'),
          _InfoLine(label: 'Zusatzzahl', value: '${zusatzzahl ?? '-'}'),
          _InfoLine(label: 'Spiel 77', value: spiel77),
          _InfoLine(label: 'Super 6', value: super6),
        ],
      ),
    );
  }
}

class _InfoLine extends StatelessWidget {
  const _InfoLine({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(color: Color(0xFF607086), fontWeight: FontWeight.w600),
            ),
          ),
          Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF172033)),
          ),
        ],
      ),
    );
  }
}

class _PrimaryActionButton extends StatelessWidget {
  const _PrimaryActionButton({
    required this.label,
    required this.enabled,
    required this.onPressed,
  });

  final String label;
  final bool enabled;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: enabled ? onPressed : null,
        icon: const Icon(Icons.content_copy_rounded),
        label: Text(label),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF1B4FD6),
          foregroundColor: Colors.white,
          disabledBackgroundColor: const Color(0xFFD9E1EC),
          disabledForegroundColor: const Color(0xFF77879A),
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
      ),
    );
  }
}
