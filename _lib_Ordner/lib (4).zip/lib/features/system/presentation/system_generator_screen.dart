import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../generator/provider/lotto_app_state.dart';

class SystemGeneratorScreen extends StatefulWidget {
  const SystemGeneratorScreen({super.key});

  @override
  State<SystemGeneratorScreen> createState() =>
      _SystemGeneratorScreenState();
}

class _SystemGeneratorScreenState
    extends State<SystemGeneratorScreen> {

  final List<int> selectedNumbers = [];

  void toggleNumber(int n) {
    setState(() {
      if (selectedNumbers.contains(n)) {
        selectedNumbers.remove(n);
      } else {
        if (selectedNumbers.length < 12) {
          selectedNumbers.add(n);
        }
      }
    });
  }

  int _nCr(int n, int r) {
    int res = 1;
    for (int i = 0; i < r; i++) {
      res = res * (n - i) ~/ (i + 1);
    }
    return res;
  }

  int calculateRows() {
    if (selectedNumbers.length < 6) return 0;
    return _nCr(selectedNumbers.length, 6);
  }

  double calculatePrice() {
    return calculateRows() * 1.20;
  }

  void useTop10(LottoAppState state) {
    setState(() {
      selectedNumbers.clear();
      selectedNumbers.addAll(state.top10Numbers);
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();

    final rows = calculateRows();
    final price = calculatePrice();

    return Scaffold(
      appBar: AppBar(title: const Text('Systemspiele')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [

            // Top10 Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => useTop10(state),
                icon: const Icon(Icons.auto_awesome),
                label: const Text('Top 10 Analyse verwenden'),
              ),
            ),

            const SizedBox(height: 16),

            // Zahlen
            Expanded(
              child: GridView.builder(
                itemCount: 49,
                gridDelegate:
                const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 7,
                ),
                itemBuilder: (_, i) {
                  final n = i + 1;
                  final selected = selectedNumbers.contains(n);

                  return GestureDetector(
                    onTap: () => toggleNumber(n),
                    child: Container(
                      margin: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: selected
                            ? Colors.blue
                            : Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.grey),
                      ),
                      child: Center(
                        child: Text(
                          '$n',
                          style: TextStyle(
                            color: selected
                                ? Colors.white
                                : Colors.black,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

            const SizedBox(height: 10),

            // Vorschau
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFE1E7F0)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Zahlen: ${selectedNumbers.length}'),
                  Text('Reihen: $rows'),
                  Text('Preis: ${price.toStringAsFixed(2)} €'),

                  const SizedBox(height: 8),

                  Text('Zusatzzahl: ${state.zusatzZahl ?? '-'}'),
                  Text('Superzahl: ${state.superZahl}'),
                  Text('Spiel 77: ${state.generateSpiel77()}'),
                  Text('Super 6: ${state.generateSuper6()}'),
                ],
              ),
            ),

            const SizedBox(height: 10),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: selectedNumbers.length < 6
                    ? null
                    : () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('System vorbereitet'),
                    ),
                  );
                },
                child: const Text('System spielen'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}