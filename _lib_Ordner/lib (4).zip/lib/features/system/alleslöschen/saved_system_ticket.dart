import '../domain/system_mode.dart';
import '../domain/vew_system_type.dart';

class SavedSystemTicket {
  final String id;
  final DateTime createdAt;
  final String drawModeLabel;
  final SystemMode mode;
  final VewSystemType? vewType;
  final List<int> baseNumbers;
  final List<List<int>> rows;

  const SavedSystemTicket({
    required this.id,
    required this.createdAt,
    required this.drawModeLabel,
    required this.mode,
    required this.baseNumbers,
    required this.rows,
    this.vewType,
  });

  int get rowCount => rows.length;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'createdAt': createdAt.toIso8601String(),
      'drawModeLabel': drawModeLabel,
      'mode': mode.name,
      'vewType': vewType?.name,
      'baseNumbers': baseNumbers,
      'rows': rows,
    };
  }

  factory SavedSystemTicket.fromMap(Map<String, dynamic> map) {
    final rawRows = (map['rows'] as List? ?? const [])
        .map((row) => (row as List)
        .map((e) => int.tryParse(e.toString()) ?? 0)
        .where((e) => e > 0)
        .toList())
        .where((row) => row.isNotEmpty)
        .toList();

    final rawBaseNumbers = (map['baseNumbers'] as List? ?? const [])
        .map((e) => int.tryParse(e.toString()) ?? 0)
        .where((e) => e > 0)
        .toList();

    final modeName = map['mode']?.toString();
    final vewTypeName = map['vewType']?.toString();

    return SavedSystemTicket(
      id: map['id']?.toString() ?? '',
      createdAt: DateTime.tryParse(map['createdAt']?.toString() ?? '') ?? DateTime.now(),
      drawModeLabel: map['drawModeLabel']?.toString() ?? 'Alle',
      mode: SystemMode.values.firstWhere(
            (e) => e.name == modeName,
        orElse: () => SystemMode.full,
      ),
      vewType: vewTypeName == null
          ? null
          : VewSystemType.values.firstWhere(
            (e) => e.name == vewTypeName,
        orElse: () => VewSystemType.vew7_3,
      ),
      baseNumbers: rawBaseNumbers,
      rows: rawRows,
    );
  }
}
