import 'dart:io';

import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:lotto_davenport/features/systems/domain/vew_system_type.dart';
import '../domain/system_ticket.dart';

class SystemExportService {
  static Future<File> exportToTxt(
      SystemTicket ticket, {
        int weeks = 1,
      }) async {
    final directory = await getApplicationDocumentsDirectory();
    final timestamp = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
    final file = File('${directory.path}/system_ticket_$timestamp.txt');

    final buffer = StringBuffer()
      ..writeln('=== LOTTO SYSTEMSCHEIN ===')
      ..writeln('Erstellt: ${DateFormat('dd.MM.yyyy HH:mm').format(DateTime.now())}')
      ..writeln('Modus: ${ticket.mode.name}')
      ..writeln('VEW: ${ticket.vewType?.label ?? '-'}')
      ..writeln('Basiszahlen: ${ticket.baseNumbers.join(', ')}')
      ..writeln('Wochen: $weeks')
      ..writeln('Reihen: ${ticket.rowCount}')
      ..writeln('');

    for (int i = 0; i < ticket.rows.length; i++) {
      final row = [...ticket.rows[i]]..sort();
      buffer.writeln('Reihe ${i + 1}: ${row.join(', ')}');
    }

    await file.writeAsString(buffer.toString(), flush: true);
    return file;
  }
}