class SystemPriceBreakdown {
  final double lotto;
  final double spiel77;
  final double super6;
  final double processingFee;
  final int draws;
  final int weeks;

  const SystemPriceBreakdown({
    required this.lotto,
    required this.spiel77,
    required this.super6,
    required this.processingFee,
    required this.draws,
    required this.weeks,
  });

  double get total => lotto + spiel77 + super6 + processingFee;
}

class SystemPricingService {
  static const double spiel77Price = 2.50;
  static const double super6Price = 1.25;
  static const double processingFee = 0.50;

  double basePriceForSystem(int systemSize) {
    switch (systemSize) {
      case 7:
        return 8.40;
      case 8:
        return 33.60;
      case 9:
        return 100.80;
      case 10:
        return 252.00;
      default:
        return 0.0;
    }
  }

  double calculatePrice({
    required int systemSize,
    required bool withSpiel77,
    required bool withSuper6,
    required int drawsCount,
    bool includeProcessingFee = true,
  }) {
    final base = basePriceForSystem(systemSize);
    final extrasPerDraw =
        (withSpiel77 ? spiel77Price : 0.0) +
            (withSuper6 ? super6Price : 0.0);

    final total = (base + extrasPerDraw) * drawsCount;
    return total + (includeProcessingFee && drawsCount > 0 ? processingFee : 0.0);
  }

  /// Kompatibel zu system_generator_screen.dart
  double calculateStake(dynamic ticket) {
    final int systemSize = _readInt(ticket, ['systemSize', 'fullSystem', 'selectedFullSystem'], fallback: 7);
    final bool withSpiel77 = _readBool(ticket, ['withSpiel77', 'spiel77']);
    final bool withSuper6 = _readBool(ticket, ['withSuper6', 'super6']);
    final bool playWednesday = _readBool(ticket, ['playWednesday', 'wednesday'], fallback: true);
    final bool playSaturday = _readBool(ticket, ['playSaturday', 'saturday'], fallback: true);
    final int durationWeeks = _readInt(ticket, ['durationWeeks', 'weeks'], fallback: 1);

    int drawsPerWeek = 0;
    if (playWednesday) drawsPerWeek++;
    if (playSaturday) drawsPerWeek++;

    final drawsCount = drawsPerWeek * durationWeeks;

    return calculatePrice(
      systemSize: systemSize,
      withSpiel77: withSpiel77,
      withSuper6: withSuper6,
      drawsCount: drawsCount,
    );
  }

  /// Kompatibel zu system_generator_screen.dart
  String formatEuro(double value) {
    return '${value.toStringAsFixed(2).replaceAll('.', ',')} €';
  }

  int _readInt(dynamic source, List<String> keys, {required int fallback}) {
    if (source == null) return fallback;

    for (final key in keys) {
      try {
        final value = source.toJson()[key];
        if (value is int) return value;
        if (value is num) return value.toInt();
      } catch (_) {}

      try {
        final value = source[key];
        if (value is int) return value;
        if (value is num) return value.toInt();
      } catch (_) {}
    }

    return fallback;
  }

  bool _readBool(dynamic source, List<String> keys, {bool fallback = false}) {
    if (source == null) return fallback;

    for (final key in keys) {
      try {
        final value = source.toJson()[key];
        if (value is bool) return value;
      } catch (_) {}

      try {
        final value = source[key];
        if (value is bool) return value;
      } catch (_) {}
    }

    return fallback;
  }
}