import '../../draws/domain/draw_result.dart';
import '../domain/system_ticket.dart';

class SystemSimulationService {
  static const double _stakePerRow = 1.20;

  static const Map<int, double> _defaultPayoutByHits = {
    6: 100000.0,
    5: 1000.0,
    4: 100.0,
    3: 10.0,
    2: 0.0,
    1: 0.0,
    0: 0.0,
  };

  SystemSimulationResult simulate(SystemTicket ticket, DrawResult draw) {
    final drawNumbers = List<int>.from(draw.numbers)..sort();

    final hitDistribution = <int, int>{};
    var bestHitCount = 0;

    for (final row in ticket.rows) {
      final hits = row.where(drawNumbers.contains).length;
      hitDistribution[hits] = (hitDistribution[hits] ?? 0) + 1;
      if (hits > bestHitCount) {
        bestHitCount = hits;
      }
    }

    return SystemSimulationResult(
      drawNumbers: drawNumbers,
      payoutByHits: _defaultPayoutByHits,
      rows: ticket.rowCount,
      stakePerRow: _stakePerRow,
      hitDistribution: hitDistribution,
      bestHitCount: bestHitCount,
    );
  }
}

class SystemSimulationResult {
  final List<int> drawNumbers;
  final Map<int, double> payoutByHits;
  final int rows;
  final double stakePerRow;
  final Map<int, int> hitDistribution;
  final int bestHitCount;

  const SystemSimulationResult({
    required this.drawNumbers,
    required this.payoutByHits,
    required this.rows,
    required this.stakePerRow,
    required this.hitDistribution,
    required this.bestHitCount,
  });

  int get winningRows {
    var total = 0;
    for (final entry in hitDistribution.entries) {
      if (entry.key >= 3) {
        total += entry.value;
      }
    }
    return total;
  }

  double get totalStake => rows * stakePerRow;

  double get totalPayout {
    double sum = 0;
    for (final entry in hitDistribution.entries) {
      final payout = payoutByHits[entry.key] ?? 0;
      sum += payout * entry.value;
    }
    return sum;
  }

  double get profit => totalPayout - totalStake;
}