import 'dart:ui';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/number_ball.dart';
import '../../../core/widgets/primary_button.dart';
import '../../analysis/presentation/ai_max_mode_screen.dart';
import '../../analysis/presentation/win_simulation_screen.dart';
import '../../generator/provider/lotto_app_state.dart';
import '../../system/presentation/system_generator_screen.dart';

class GeneratorScreen extends StatefulWidget {
  const GeneratorScreen({super.key});

  @override
  State<GeneratorScreen> createState() => _GeneratorScreenState();
}

class _GeneratorScreenState extends State<GeneratorScreen> {
  int _tabIndex = 0;
  late final PageController _pageController;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: _tabIndex);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _goToTab(int index) {
    if (_tabIndex == index) return;
    setState(() => _tabIndex = index);
    _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOutCubic,
    );
  }

  Future<void> _showMessage(String message) async {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _generateRandom() async {
    await context.read<LottoAppState>().generateRandomTip();
    await _showMessage('Zufallstipp wurde erstellt.');
  }

  Future<void> _saveLastTip() async {
    await context.read<LottoAppState>().saveLastTip(source: 'manual');
    await _showMessage('Tipp wurde gespeichert.');
  }

  Future<void> _generateAnalysis() async {
    try {
      await context.read<LottoAppState>().generateAnalysisTip();
      await _showMessage('Analyse-Tipp wurde erstellt.');
    } catch (e) {
      await _showMessage(e.toString());
    }
  }

  Future<void> _applyBestTip() async {
    await context.read<LottoAppState>().applyBestAnalyzedTip();
    await _showMessage('AI Pro Tipp wurde übernommen.');
  }

  Future<void> _copyLastTip() async {
    final state = context.read<LottoAppState>();
    final tip = state.lastGeneratedTip;
    final superNumber = state.lastGeneratedSuperNumber;

    if (tip == null || tip.isEmpty) {
      await _showMessage('Noch kein Tipp vorhanden.');
      return;
    }

    final text = superNumber == null
        ? tip.join(', ')
        : '${tip.join(', ')} | SZ: $superNumber';

    await Clipboard.setData(ClipboardData(text: text));
    await _showMessage('Tipp wurde kopiert.');
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();
    final summary = state.analysisSummary;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFF7FAFF), AppColors.background],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: ListView(
                  primary: true,
                  physics: const ClampingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
                  children: [
                    _HeroHeader(
                      state: state,
                      summary: summary,
                    ),
                    const SizedBox(height: 16),
                    _MetricsGrid(
                      cards: [
                        _MetricData(
                          title: 'Ziehungen',
                          value: '${summary.drawCount}',
                          icon: Icons.dataset_rounded,
                        ),
                        _MetricData(
                          title: 'Profil',
                          value: state.analysisProfileLabel,
                          icon: Icons.tune_rounded,
                        ),
                        _MetricData(
                          title: 'Qualität',
                          value: state.analysisStrengthLabel,
                          icon: Icons.insights_rounded,
                        ),
                        _MetricData(
                          title: 'Fenster',
                          value: state.analysisDrawFilterLabel,
                          icon: Icons.calendar_view_week_rounded,
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    _ModeTabs(
                      index: _tabIndex,
                      onChanged: _goToTab,
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      height: 980,
                      child: PageView(
                        controller: _pageController,
                        dragStartBehavior: DragStartBehavior.down,
                        onPageChanged: (value) {
                          if (mounted) {
                            setState(() => _tabIndex = value);
                          }
                        },
                        children: [
                          _TabScrollView(
                            child: _NormalPanel(
                              state: state,
                              onGenerate: _generateRandom,
                              onSave: state.lastGeneratedTip == null
                                  ? null
                                  : _saveLastTip,
                              onCopy: state.lastGeneratedTip == null
                                  ? null
                                  : _copyLastTip,
                            ),
                            currentTip: _CurrentTipPanel(
                              state: state,
                              onSave: state.lastGeneratedTip == null
                                  ? null
                                  : _saveLastTip,
                              onCopy: state.lastGeneratedTip == null
                                  ? null
                                  : _copyLastTip,
                            ),
                          ),
                          _TabScrollView(
                            child: _AiPanel(
                              state: state,
                              onGenerate: _generateAnalysis,
                              onApplyBest: state.bestAnalyzedTip.length == 6
                                  ? _applyBestTip
                                  : null,
                            ),
                            currentTip: _CurrentTipPanel(
                              state: state,
                              onSave: state.lastGeneratedTip == null
                                  ? null
                                  : _saveLastTip,
                              onCopy: state.lastGeneratedTip == null
                                  ? null
                                  : _copyLastTip,
                            ),
                          ),
                          _TabScrollView(
                            child: _JackpotPanel(
                              state: state,
                              onGenerate: _generateAnalysis,
                              onApplyBest: state.bestAnalyzedTip.length == 6
                                  ? _applyBestTip
                                  : null,
                            ),
                            currentTip: _CurrentTipPanel(
                              state: state,
                              onSave: state.lastGeneratedTip == null
                                  ? null
                                  : _saveLastTip,
                              onCopy: state.lastGeneratedTip == null
                                  ? null
                                  : _copyLastTip,
                            ),
                          ),
                          _TabScrollView(
                            child: _SystemEntryPanel(state: state),
                            currentTip: _CurrentTipPanel(
                              state: state,
                              onSave: state.lastGeneratedTip == null
                                  ? null
                                  : _saveLastTip,
                              onCopy: state.lastGeneratedTip == null
                                  ? null
                                  : _copyLastTip,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class _CompactGeneratorHeader extends StatelessWidget {
  const _CompactGeneratorHeader();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowLight,
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: const [
          Icon(
            Icons.auto_awesome_rounded,
            color: AppColors.primary,
            size: 22,
          ),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'Lotto Mind AI',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: AppColors.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MetricData {
  final String title;
  final String value;
  final IconData icon;

  const _MetricData({
    required this.title,
    required this.value,
    required this.icon,
  });
}

class _HeroHeader extends StatelessWidget {
  final LottoAppState state;
  final AnalysisSummary summary;

  const _HeroHeader({
    required this.state,
    required this.summary,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(30),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.white.withOpacity(0.95),
                const Color(0xFFF2F7FF).withOpacity(0.86),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: Colors.white.withOpacity(0.72)),
            boxShadow: const [
              BoxShadow(
                color: AppColors.shadowMedium,
                blurRadius: 26,
                offset: Offset(0, 14),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      gradient: const LinearGradient(
                        colors: [AppColors.primary, AppColors.primaryDark],
                      ),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x262563EB),
                          blurRadius: 14,
                          offset: Offset(0, 7),
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.auto_awesome_rounded,
                      color: Colors.white,
                      size: 28,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Lotto Mind AI',
                          style: TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.w900,
                            color: AppColors.textPrimary,
                            height: 1,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Smart Generator für Zufall, KI-Analyse, Jackpot-Strategie und Systemspiele.',
                          style: TextStyle(
                            fontSize: 13,
                            height: 1.45,
                            color: AppColors.textSecondary.withOpacity(0.95),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              _HighlightStrip(
                items: [
                  _HighlightItem(
                    icon: Icons.timeline_rounded,
                    title: 'Zeitraum',
                    value: state.analysisWindowLabel,
                  ),
                  _HighlightItem(
                    icon: Icons.bolt_rounded,
                    title: 'Heißeste Zahlen',
                    value: summary.hotNumbers.isEmpty
                        ? '-'
                        : summary.hotNumbers
                        .take(3)
                        .map((e) => e.number.toString().padLeft(2, '0'))
                        .join(' • '),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HighlightItem {
  final IconData icon;
  final String title;
  final String value;

  const _HighlightItem({
    required this.icon,
    required this.title,
    required this.value,
  });
}

class _HighlightStrip extends StatelessWidget {
  final List<_HighlightItem> items;

  const _HighlightStrip({required this.items});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: items
          .map(
            (item) => Padding(
          padding: EdgeInsets.only(bottom: item == items.last ? 0 : 10),
          child: Container(
            width: double.infinity,
            padding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.surfaceSoft,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                Icon(item.icon, color: AppColors.primary, size: 18),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    item.title,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Flexible(
                  child: Text(
                    item.value,
                    textAlign: TextAlign.right,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      )
          .toList(),
    );
  }
}

class _MetricsGrid extends StatelessWidget {
  final List<_MetricData> cards;

  const _MetricsGrid({required this.cards});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final crossAxisCount = width >= 900
            ? 4
            : width >= 620
            ? 2
            : 2;
        final itemWidth = (width - ((crossAxisCount - 1) * 12)) / crossAxisCount;

        return Wrap(
          spacing: 12,
          runSpacing: 12,
          children: cards
              .map(
                (card) => SizedBox(
              width: itemWidth,
              child: _MetricCard(data: card),
            ),
          )
              .toList(),
        );
      },
    );
  }
}

class _MetricCard extends StatelessWidget {
  final _MetricData data;

  const _MetricCard({required this.data});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowLight,
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: AppColors.infoSoft,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(data.icon, color: AppColors.primary, size: 20),
          ),
          const SizedBox(height: 12),
          Text(
            data.value,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            data.title,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

class _ModeTabItem {
  final String label;
  final IconData icon;

  const _ModeTabItem({
    required this.label,
    required this.icon,
  });
}

class _ModeTabs extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;

  const _ModeTabs({
    required this.index,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    const items = [
      _ModeTabItem(label: 'Normal', icon: Icons.casino_rounded),
      _ModeTabItem(label: 'AI', icon: Icons.psychology_alt_rounded),
      _ModeTabItem(label: 'Jackpot', icon: Icons.local_fire_department_rounded),
      _ModeTabItem(label: 'System', icon: Icons.grid_view_rounded),
    ];

    return Row(
      children: List.generate(items.length, (i) {
        final selected = i == index;
        final item = items[i];
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: i == items.length - 1 ? 0 : 8),
            child: InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () => onChanged(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 140),
                curve: Curves.easeOut,
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
                decoration: BoxDecoration(
                  gradient: selected
                      ? const LinearGradient(
                    colors: [AppColors.primary, AppColors.primaryDark],
                  )
                      : null,
                  color: selected ? null : AppColors.surface,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: selected ? Colors.transparent : AppColors.border,
                  ),
                  boxShadow: selected
                      ? const [
                    BoxShadow(
                      color: Color(0x1F2563EB),
                      blurRadius: 12,
                      offset: Offset(0, 6),
                    ),
                  ]
                      : const [],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      item.icon,
                      size: 17,
                      color: selected ? Colors.white : AppColors.textSecondary,
                    ),
                    const SizedBox(height: 6),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        item.label,
                        maxLines: 1,
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          color: selected ? Colors.white : AppColors.textSecondary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}

class _TabScrollView extends StatelessWidget {
  final Widget child;
  final Widget currentTip;

  const _TabScrollView({
    required this.child,
    required this.currentTip,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      primary: false,
      physics: const ClampingScrollPhysics(),
      padding: EdgeInsets.zero,
      children: [
        child,
        const SizedBox(height: 14),
        currentTip,
        const SizedBox(height: 10),
      ],
    );
  }
}

class _PanelCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;

  const _PanelCard({
    required this.title,
    required this.subtitle,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowLight,
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        fontSize: 12,
                        height: 1.45,
                        color: AppColors.textSecondary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          child,
        ],
      ),
    );
  }
}

class _SubCard extends StatelessWidget {
  final String title;
  final Widget child;

  const _SubCard({
    required this.title,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surfaceSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }
}

class _NormalPanel extends StatelessWidget {
  final LottoAppState state;
  final Future<void> Function() onGenerate;
  final Future<void> Function()? onSave;
  final Future<void> Function()? onCopy;

  const _NormalPanel({
    required this.state,
    required this.onGenerate,
    required this.onSave,
    required this.onCopy,
  });

  @override
  Widget build(BuildContext context) {
    final lastTip = state.lastGeneratedTip;

    return _PanelCard(
      title: 'Normaler Generator',
      subtitle: 'Schneller Spielschein ohne Analysefilter – direkt erzeugen, prüfen und speichern.',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SubCard(
            title: 'Schnellstart',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Für einen schnellen Start wird hier ein klassischer Zufallstipp erzeugt. Ohne Sonderlogik, ohne Verzögerung, direkt spielbereit.',
                  style: TextStyle(
                    fontSize: 12,
                    height: 1.45,
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 14),
                PrimaryButton(
                  label: 'Zufallstipp generieren',
                  icon: Icons.casino_rounded,
                  onPressed: onGenerate,
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    SizedBox(
                      width: 180,
                      child: PrimaryButton(
                        label: 'Speichern',
                        icon: Icons.bookmark_add_rounded,
                        onPressed: onSave,
                      ),
                    ),
                    SizedBox(
                      width: 180,
                      child: OutlinedButton.icon(
                        onPressed: onCopy,
                        icon: const Icon(Icons.copy_rounded),
                        label: const Text('Kopieren'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _SubCard(
            title: 'Status',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _InlineInfo(
                  label: 'Modus',
                  value: 'Schneller Zufallstipp',
                ),
                const SizedBox(height: 6),
                _InlineInfo(
                  label: 'Letzter Tipp',
                  value: lastTip == null || lastTip.isEmpty
                      ? '-'
                      : lastTip.join(' • '),
                ),
                const SizedBox(height: 6),
                _InlineInfo(
                  label: 'Superzahl',
                  value: state.lastGeneratedSuperNumber?.toString() ?? '-',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AiPanel extends StatelessWidget {
  final LottoAppState state;
  final Future<void> Function() onGenerate;
  final Future<void> Function()? onApplyBest;

  const _AiPanel({
    required this.state,
    required this.onGenerate,
    required this.onApplyBest,
  });

  @override
  Widget build(BuildContext context) {
    final ai = state.analysisAiSummary;
    final bestTip = state.bestAnalyzedTip;
    final lastSimulation = state.bestCurrentTipWindow?.summary;
    final bestSimulation = state.bestAiTipWindow?.summary;

    return _PanelCard(
      title: 'KI-Analyse',
      subtitle: 'Analysezeitraum, Profil, AI-Bewertung und AI-Pro-Kandidat in einem stabilen Flow.',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SubCard(
            title: 'Analyse-Steuerung',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const _ControlLabel('Ziehungstag'),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _ChoiceButton(
                      label: 'Beide',
                      selected:
                      state.analysisDrawFilter == AnalysisDrawFilter.all,
                      onTap: () => context
                          .read<LottoAppState>()
                          .setAnalysisDrawFilter(AnalysisDrawFilter.all),
                    ),
                    _ChoiceButton(
                      label: 'Mittwoch',
                      selected: state.analysisDrawFilter ==
                          AnalysisDrawFilter.wednesday,
                      onTap: () => context
                          .read<LottoAppState>()
                          .setAnalysisDrawFilter(AnalysisDrawFilter.wednesday),
                    ),
                    _ChoiceButton(
                      label: 'Samstag',
                      selected: state.analysisDrawFilter ==
                          AnalysisDrawFilter.saturday,
                      onTap: () => context
                          .read<LottoAppState>()
                          .setAnalysisDrawFilter(AnalysisDrawFilter.saturday),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                const _ControlLabel('Analyse-Ziehungen'),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    _StepButton(
                      label: '-10',
                      onTap: () {
                        final s = context.read<LottoAppState>();
                        final next = s.analysisDrawCount - 10 < 1
                            ? 1
                            : s.analysisDrawCount - 10;
                        s.setAnalysisDrawCount(next);
                      },
                    ),
                    _StepButton(
                      label: '-1',
                      onTap: () {
                        final s = context.read<LottoAppState>();
                        final next = s.analysisDrawCount - 1 < 1
                            ? 1
                            : s.analysisDrawCount - 1;
                        s.setAnalysisDrawCount(next);
                      },
                    ),
                    SizedBox(
                      width: 220,
                      child: Slider(
                        value: state.analysisDrawCount.toDouble(),
                        min: 1,
                        max: state.maxAnalysisDrawCount.toDouble(),
                        divisions: state.maxAnalysisDrawCount > 1
                            ? state.maxAnalysisDrawCount - 1
                            : 1,
                        label: '${state.analysisDrawCount}',
                        onChanged: (value) {
                          context
                              .read<LottoAppState>()
                              .setAnalysisDrawCount(value.round());
                        },
                      ),
                    ),
                    _StepButton(
                      label: '+1',
                      onTap: () {
                        final s = context.read<LottoAppState>();
                        final next = s.analysisDrawCount + 1 >
                            s.maxAnalysisDrawCount
                            ? s.maxAnalysisDrawCount
                            : s.analysisDrawCount + 1;
                        s.setAnalysisDrawCount(next);
                      },
                    ),
                    _StepButton(
                      label: '+10',
                      onTap: () {
                        final s = context.read<LottoAppState>();
                        final next = s.analysisDrawCount + 10 >
                            s.maxAnalysisDrawCount
                            ? s.maxAnalysisDrawCount
                            : s.analysisDrawCount + 10;
                        s.setAnalysisDrawCount(next);
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    SizedBox(
                      width: 180,
                      child: OutlinedButton.icon(
                        onPressed: () {
                          context.read<LottoAppState>().setAnalysisToRecent52();
                        },
                        icon: const Icon(Icons.history_rounded),
                        label: const Text('Letzte 52'),
                      ),
                    ),
                    SizedBox(
                      width: 180,
                      child: OutlinedButton.icon(
                        onPressed: () {
                          context.read<LottoAppState>().setAnalysisToAllHistory();
                        },
                        icon: const Icon(Icons.all_inclusive_rounded),
                        label: const Text('Komplett'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                const _ControlLabel('Profil'),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _ChoiceButton(
                      label: 'Defensiv',
                      selected:
                      state.analysisProfile == AnalysisProfile.defensive,
                      onTap: () => context
                          .read<LottoAppState>()
                          .setAnalysisProfile(AnalysisProfile.defensive),
                    ),
                    _ChoiceButton(
                      label: 'Mittel',
                      selected:
                      state.analysisProfile == AnalysisProfile.balanced,
                      onTap: () => context
                          .read<LottoAppState>()
                          .setAnalysisProfile(AnalysisProfile.balanced),
                    ),
                    _ChoiceButton(
                      label: 'Aggressiv',
                      selected:
                      state.analysisProfile == AnalysisProfile.aggressive,
                      onTap: () => context
                          .read<LottoAppState>()
                          .setAnalysisProfile(AnalysisProfile.aggressive),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                _InlineInfo(label: 'Fenster', value: state.analysisWindowLabel),
                const SizedBox(height: 6),
                _InlineInfo(
                  label: 'Ziehungen',
                  value: '${state.analysisDrawCount}',
                ),
                const SizedBox(height: 6),
                _InlineInfo(
                  label: 'Qualität',
                  value: state.analysisStrengthLabel,
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          PrimaryButton(
            label: 'Analyse-Tipp berechnen',
            icon: Icons.auto_awesome_rounded,
            onPressed: onGenerate,
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              SizedBox(
                width: 180,
                child: PrimaryButton(
                  label: 'AI Max Mode',
                  icon: Icons.psychology_alt_rounded,
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const AiMaxModeScreen(),
                      ),
                    );
                  },
                ),
              ),
              SizedBox(
                width: 180,
                child: PrimaryButton(
                  label: 'Gewinnsimulation',
                  icon: Icons.query_stats_rounded,
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const WinSimulationScreen(),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _SubCard(
            title: 'AI-Bewertung',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _InlineInfo(label: 'Titel', value: ai.title),
                const SizedBox(height: 6),
                _InlineInfo(label: 'Confidence', value: ai.confidence),
                const SizedBox(height: 12),
                _ConfidenceBar(confidenceText: ai.confidence),
                const SizedBox(height: 12),
                _BallRow(title: 'Empfohlen', numbers: ai.recommendedNumbers),
                const SizedBox(height: 12),
                _BallRow(title: 'Eher meiden', numbers: ai.avoidNumbers),
                const SizedBox(height: 12),
                Text(
                  ai.reasoning,
                  style: const TextStyle(
                    fontSize: 12,
                    height: 1.45,
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _SubCard(
            title: 'AI-Pro-Kandidat',
            child: bestTip.length != 6
                ? const Text(
              'Noch kein AI-Pro-Tipp verfügbar.',
              style: TextStyle(
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w600,
              ),
            )
                : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _BallRow(title: 'Bester Tipp', numbers: bestTip),
                if (bestSimulation != null) ...[
                  const SizedBox(height: 12),
                  _SimulationSummaryCard(
                    title: 'Rücktest AI Pro',
                    simulation: bestSimulation,
                  ),
                ],
                const SizedBox(height: 12),
                PrimaryButton(
                  label: 'AI Pro Tipp übernehmen',
                  icon: Icons.download_done_rounded,
                  onPressed: onApplyBest,
                ),
                if (lastSimulation != null) ...[
                  const SizedBox(height: 12),
                  _SimulationSummaryCard(
                    title: 'Rücktest aktueller Tipp',
                    simulation: lastSimulation,
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _JackpotPanel extends StatelessWidget {
  final LottoAppState state;
  final Future<void> Function() onGenerate;
  final Future<void> Function()? onApplyBest;

  const _JackpotPanel({
    required this.state,
    required this.onGenerate,
    required this.onApplyBest,
  });

  @override
  Widget build(BuildContext context) {
    return _PanelCard(
      title: 'Jackpot-Fokus',
      subtitle: 'Aggressiverer Flow für chancenorientierte Tipps auf Basis deiner KI-Analyse.',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _JackpotModeInfo(),
          const SizedBox(height: 14),
          _SubCard(
            title: 'Strategie',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Diese Ansicht nutzt denselben stabilen Analysekern, setzt aber stärker auf seltenere, chancenorientierte Muster.',
                  style: TextStyle(
                    fontSize: 12,
                    height: 1.45,
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 12),
                _InlineInfo(
                  label: 'Strategie',
                  value: 'KI-Analyse + AI Pro + Gewinnsimulation',
                ),
                const SizedBox(height: 6),
                _InlineInfo(
                  label: 'Ziel',
                  value: 'aggressiver, jackpot-orientierter Stil',
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          PrimaryButton(
            label: 'Jackpot-Tipp berechnen',
            icon: Icons.local_fire_department_rounded,
            onPressed: onGenerate,
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              SizedBox(
                width: 180,
                child: PrimaryButton(
                  label: 'AI Max Mode öffnen',
                  icon: Icons.bolt_rounded,
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const AiMaxModeScreen(),
                      ),
                    );
                  },
                ),
              ),
              SizedBox(
                width: 180,
                child: PrimaryButton(
                  label: 'Gewinnsimulation',
                  icon: Icons.query_stats_rounded,
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const WinSimulationScreen(),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
          if (state.bestAnalyzedTip.length == 6) ...[
            const SizedBox(height: 14),
            _SubCard(
              title: 'Jackpot-Kandidat',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _BallRow(
                    title: 'AI-Pro-Kandidat',
                    numbers: state.bestAnalyzedTip,
                  ),
                  const SizedBox(height: 12),
                  PrimaryButton(
                    label: 'Kandidaten übernehmen',
                    icon: Icons.download_done_rounded,
                    onPressed: onApplyBest,
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _SystemEntryPanel extends StatelessWidget {
  final LottoAppState state;

  const _SystemEntryPanel({required this.state});

  @override
  Widget build(BuildContext context) {
    return _PanelCard(
      title: 'Systemspiele',
      subtitle: 'VEW und Vollsystem laufen in einem eigenen, sauberen Bereich.',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SubCard(
            title: 'Aktueller Stand',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _InlineInfo(label: 'Systemart', value: state.systemPlayTypeLabel),
                const SizedBox(height: 6),
                _InlineInfo(
                  label: 'Systemgröße',
                  value: '${state.selectedSystemSize}',
                ),
                const SizedBox(height: 6),
                _InlineInfo(
                  label: 'Manuell',
                  value: state.manualSystemNumbers.isEmpty
                      ? '-'
                      : state.manualSystemNumbers.join(' • '),
                ),
                const SizedBox(height: 6),
                _InlineInfo(label: 'Reihen', value: '${state.systemRows.length}'),
              ],
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            'Systemspiele haben ihren eigenen Flow: wählen → Zahlen setzen → erzeugen → PDF → Abgabe.',
            style: TextStyle(
              fontSize: 12,
              height: 1.45,
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 14),
          PrimaryButton(
            label: 'Zum Systembereich',
            icon: Icons.grid_view_rounded,
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const SystemGeneratorScreen(),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _CurrentTipPanel extends StatelessWidget {
  final LottoAppState state;
  final Future<void> Function()? onSave;
  final Future<void> Function()? onCopy;

  const _CurrentTipPanel({
    required this.state,
    required this.onSave,
    required this.onCopy,
  });

  @override
  Widget build(BuildContext context) {
    final tip = state.lastGeneratedTip;
    final superNumber = state.lastGeneratedSuperNumber;
    final lastSimulation = state.bestCurrentTipWindow?.summary;

    return _PanelCard(
      title: 'Aktueller Tipp',
      subtitle: 'Der zuletzt erzeugte Tipp mit Superzahl, Schnellaktionen und Bewertung.',
      child: tip == null || tip.isEmpty
          ? const Text(
        'Noch kein Tipp generiert.',
        style: TextStyle(
          color: AppColors.textSecondary,
          fontWeight: FontWeight.w600,
        ),
      )
          : Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SubCard(
            title: 'Spielschein',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _BallRow(title: 'Zahlen', numbers: tip),
                const SizedBox(height: 10),
                _InlineInfo(
                  label: 'Superzahl',
                  value: superNumber?.toString() ?? '-',
                ),
              ],
            ),
          ),
          if (lastSimulation != null) ...[
            const SizedBox(height: 12),
            _SimulationSummaryCard(
              title: 'Gewinn-Anzeige',
              simulation: lastSimulation,
            ),
          ],
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              SizedBox(
                width: 180,
                child: PrimaryButton(
                  label: 'Speichern',
                  icon: Icons.bookmark_add_rounded,
                  onPressed: onSave,
                ),
              ),
              SizedBox(
                width: 180,
                child: OutlinedButton.icon(
                  onPressed: onCopy,
                  icon: const Icon(Icons.copy_rounded),
                  label: const Text('Kopieren'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SimulationSummaryCard extends StatelessWidget {
  final String title;
  final dynamic simulation;

  const _SimulationSummaryCard({
    required this.title,
    required this.simulation,
  });

  num _numValue(String field, [num fallback = 0]) {
    try {
      final dynamic value;
      switch (field) {
        case 'weightedScore':
          value = simulation.weightedScore;
          break;
        case 'estimatedEuroTotalValue':
          value = simulation.estimatedEuroTotalValue;
          break;
        case 'totalDraws':
          value = simulation.totalDraws;
          break;
        case 'hit3':
          value = simulation.hit3;
          break;
        case 'hit4':
          value = simulation.hit4;
          break;
        case 'hit5':
          value = simulation.hit5;
          break;
        case 'hit6':
          value = simulation.hit6;
          break;
        default:
          value = fallback;
      }
      return value is num ? value : fallback;
    } catch (_) {
      return fallback;
    }
  }

  int _hitFromDistribution(int hit) {
    try {
      final map = simulation.hitDistribution;
      if (map is Map<int, int>) return map[hit] ?? 0;
      if (map is Map) {
        final value = map[hit];
        return value is int ? value : 0;
      }
      return 0;
    } catch (_) {
      return 0;
    }
  }

  String _riskLabel(num score) {
    if (score >= 12) return 'Niedriger';
    if (score >= 6) return 'Mittel';
    return 'Höher';
  }

  @override
  Widget build(BuildContext context) {
    final euro = _numValue('estimatedEuroTotalValue', 0).toDouble();
    final draws = _numValue('totalDraws', 0).toInt();
    final weighted = _numValue('weightedScore', 0).toDouble();

    final hit3 = _numValue('hit3', _hitFromDistribution(3)).toInt();
    final hit4 = _numValue('hit4', _hitFromDistribution(4)).toInt();
    final hit5 = _numValue('hit5', _hitFromDistribution(5)).toInt();
    final hit6 = _numValue('hit6', _hitFromDistribution(6)).toInt();

    final avg = draws > 0 ? euro / draws : 0.0;

    return _SubCard(
      title: title,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _InlineInfo(
            label: 'Modellwert',
            value: '${euro.toStringAsFixed(2).replaceAll('.', ',')} €',
          ),
          const SizedBox(height: 6),
          _InlineInfo(
            label: 'Ø pro Ziehung',
            value: '${avg.toStringAsFixed(2).replaceAll('.', ',')} €',
          ),
          const SizedBox(height: 6),
          _InlineInfo(label: 'Risiko', value: _riskLabel(weighted)),
          const SizedBox(height: 6),
          _InlineInfo(
            label: 'Treffer-Score',
            value: weighted.toStringAsFixed(1),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _HitPill(label: '3er', value: '$hit3'),
              _HitPill(label: '4er', value: '$hit4'),
              _HitPill(label: '5er', value: '$hit5'),
              _HitPill(label: '6er', value: '$hit6'),
            ],
          ),
        ],
      ),
    );
  }
}

class _HitPill extends StatelessWidget {
  final String label;
  final String value;

  const _HitPill({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColors.border),
      ),
      child: Text(
        '$label: $value',
        style: const TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w800,
          color: AppColors.textPrimary,
        ),
      ),
    );
  }
}

class _ControlLabel extends StatelessWidget {
  final String text;

  const _ControlLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w800,
        color: AppColors.textSecondary,
      ),
    );
  }
}

class _ChoiceButton extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _ChoiceButton({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          gradient: selected
              ? const LinearGradient(
            colors: [AppColors.primary, AppColors.primaryDark],
          )
              : null,
          color: selected ? null : AppColors.surfaceSoft,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? Colors.transparent : AppColors.border,
          ),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w800,
            color: selected ? Colors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }
}

class _StepButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;

  const _StepButton({
    required this.label,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: onTap == null ? 0.45 : 1,
      child: SizedBox(
        height: 36,
        child: OutlinedButton(
          onPressed: onTap,
          child: Text(label),
        ),
      ),
    );
  }
}

class _InlineInfo extends StatelessWidget {
  final String label;
  final String value;

  const _InlineInfo({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 260) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  fontSize: 12,
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 12,
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          );
        }

        return Row(
          children: [
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  fontSize: 12,
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Flexible(
              child: Text(
                value,
                textAlign: TextAlign.right,
                style: const TextStyle(
                  fontSize: 12,
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _BallRow extends StatelessWidget {
  final String title;
  final List<int> numbers;

  const _BallRow({
    required this.title,
    required this.numbers,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 12,
            color: AppColors.textSecondary,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 8),
        numbers.isEmpty
            ? const Text(
          '-',
          style: TextStyle(
            fontSize: 12,
            color: AppColors.textSecondary,
            fontWeight: FontWeight.w700,
          ),
        )
            : Wrap(
          spacing: 8,
          runSpacing: 8,
          children: numbers.map((n) => NumberBall(number: n)).toList(),
        ),
      ],
    );
  }
}

class _ConfidenceBar extends StatelessWidget {
  final String confidenceText;

  const _ConfidenceBar({required this.confidenceText});

  @override
  Widget build(BuildContext context) {
    double value;
    if (confidenceText.toLowerCase().contains('sehr')) {
      value = 1.0;
    } else if (confidenceText.toLowerCase().contains('stark')) {
      value = 0.8;
    } else if (confidenceText.toLowerCase().contains('mittel')) {
      value = 0.6;
    } else if (confidenceText.toLowerCase().contains('begrenzt')) {
      value = 0.35;
    } else {
      value = 0.18;
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(999),
      child: LinearProgressIndicator(
        value: value,
        minHeight: 10,
        backgroundColor: AppColors.surfaceSoft,
      ),
    );
  }
}

class _JackpotModeInfo extends StatelessWidget {
  const _JackpotModeInfo();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.deepOrange.withOpacity(0.08),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Colors.deepOrange.withOpacity(0.25),
        ),
      ),
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.local_fire_department_rounded,
            color: Colors.deepOrange,
            size: 22,
          ),
          SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Jackpot-Fokus',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    color: Colors.deepOrange,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Hier wird derselbe stabile Analysekern verwendet, aber mit stärkerem Fokus auf chancenorientierte Spielweise.',
                  style: TextStyle(
                    fontSize: 12,
                    height: 1.4,
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
