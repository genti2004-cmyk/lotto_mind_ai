import 'dart:math';

/// PRO AI Generator for Lotto Pro Analyzer.
///
/// This service creates 6 numbers based on:
/// - hot numbers
/// - cold numbers
/// - pair -> third number patterns
/// - balanced random fill
class ProAiGeneratorService {
  final Random _rng;

  ProAiGeneratorService({Random? random}) : _rng = random ?? Random();

  List<int> generate({
    required List<List<int>> draws,
    int count = 6,
  }) {
    if (count <= 0) return <int>[];
    if (draws.isEmpty) {
      return _randomUniqueNumbers(count);
    }

    final normalizedDraws = draws
        .map(
          (draw) => draw
          .where((n) => n >= 1 && n <= 49)
          .toSet()
          .toList()
        ..sort(),
    )
        .where((draw) => draw.isNotEmpty)
        .toList();

    if (normalizedDraws.isEmpty) {
      return _randomUniqueNumbers(count);
    }

    final frequency = _buildFrequency(normalizedDraws);
    final hot = _top(frequency, 15);
    final cold = _bottom(frequency, 15);
    final pairThirdCandidates = _pairThirdCandidates(normalizedDraws);

    final result = <int>{};

    final hotTarget = max(1, (count * 0.4).round());
    final coldTarget = max(hotTarget, (count * 0.6).round());
    final pairTarget = max(coldTarget, (count * 0.8).round());

    _fillFromPool(result, hot, hotTarget);
    _fillFromPool(result, cold, coldTarget);
    _fillFromPool(result, pairThirdCandidates, pairTarget);

    final weightedPool = _weightedPool(frequency);
    _fillFromPool(result, weightedPool, count);

    while (result.length < count) {
      result.add(_rng.nextInt(49) + 1);
    }

    final sorted = result.toList()..sort();
    return sorted.take(count).toList();
  }

  Map<int, int> _buildFrequency(List<List<int>> draws) {
    final map = <int, int>{};

    for (final draw in draws) {
      for (final n in draw) {
        map[n] = (map[n] ?? 0) + 1;
      }
    }

    for (int i = 1; i <= 49; i++) {
      map.putIfAbsent(i, () => 0);
    }

    return map;
  }

  List<int> _top(Map<int, int> freq, int takeCount) {
    final sorted = freq.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return sorted.take(takeCount).map((e) => e.key).toList();
  }

  List<int> _bottom(Map<int, int> freq, int takeCount) {
    final sorted = freq.entries.toList()
      ..sort((a, b) => a.value.compareTo(b.value));
    return sorted.take(takeCount).map((e) => e.key).toList();
  }

  List<int> _pairThirdCandidates(List<List<int>> draws) {
    final thirdCounts = <int, int>{};

    for (final draw in draws) {
      if (draw.length < 3) continue;

      for (int i = 0; i < draw.length; i++) {
        for (int j = i + 1; j < draw.length; j++) {
          for (final n in draw) {
            if (n != draw[i] && n != draw[j]) {
              thirdCounts[n] = (thirdCounts[n] ?? 0) + 1;
            }
          }
        }
      }
    }

    final sorted = thirdCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return sorted.take(15).map((e) => e.key).toList();
  }

  List<int> _weightedPool(Map<int, int> frequency) {
    final entries = frequency.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    final pool = <int>[];
    for (final entry in entries) {
      final repeats = max(1, entry.value);
      for (int i = 0; i < repeats; i++) {
        pool.add(entry.key);
      }
    }

    if (pool.isEmpty) {
      for (int i = 1; i <= 49; i++) {
        pool.add(i);
      }
    }

    return pool;
  }

  void _fillFromPool(Set<int> target, List<int> pool, int maxSize) {
    if (pool.isEmpty) return;

    int guard = 0;
    while (target.length < maxSize && guard < 500) {
      target.add(pool[_rng.nextInt(pool.length)]);
      guard++;
    }
  }

  List<int> _randomUniqueNumbers(int count) {
    final result = <int>{};
    while (result.length < count) {
      result.add(_rng.nextInt(49) + 1);
    }
    return result.toList()..sort();
  }
}
