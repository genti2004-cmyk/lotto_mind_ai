import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../generator/domain/tip_tracking_entry.dart';
import '../../generator/provider/lotto_app_state.dart';

class TipTrackingScreen extends StatelessWidget {
  const TipTrackingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LottoAppState>();
    final entries = state.recentTipTrackingEntries;
    final distribution = state.tipTrackingHitDistribution;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Treffer-Tracking'),
        actions: [
          IconButton(
            tooltip: 'Tracking aktualisieren',
            onPressed: () => context.read<LottoAppState>().rebuildTipTrackingNow(),
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
        children: [
          _HeroCard(
            summary: state.tipTrackingSummary,
            bestHit: state.bestTrackedHitCount,
            averageHits: state.averageTrackedHits,
            total: state.tipTrackingEntries.length,
          ),
          const SizedBox(height: 14),
          _DistributionCard(distribution: distribution),
          const SizedBox(height: 14),
          if (entries.isEmpty)
            const _EmptyTrackingCard()
          else
            ...entries.map((entry) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _TrackingEntryCard(entry: entry),
            )),
          if (entries.isNotEmpty) ...[
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () => context.read<LottoAppState>().clearTipTracking(),
              icon: const Icon(Icons.delete_outline_rounded),
              label: const Text('Treffer-Verlauf löschen'),
            ),
          ],
        ],
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard({required this.summary, required this.bestHit, required this.averageHits, required this.total});
  final String summary;
  final int bestHit;
  final double averageHits;
  final int total;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF0D47A1),
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [BoxShadow(color: Color(0x220D47A1), blurRadius: 18, offset: Offset(0, 10))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Treffer-Tracking', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text(summary, style: const TextStyle(color: Colors.white70, height: 1.35)),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: _HeroMetric(label: 'Prüfungen', value: '$total')),
              Expanded(child: _HeroMetric(label: 'Bester Treffer', value: '$bestHit')),
              Expanded(child: _HeroMetric(label: 'Ø Treffer', value: averageHits.toStringAsFixed(1))),
            ],
          ),
        ],
      ),
    );
  }
}

class _HeroMetric extends StatelessWidget {
  const _HeroMetric({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w600)),
      ],
    );
  }
}

class _DistributionCard extends StatelessWidget {
  const _DistributionCard({required this.distribution});
  final Map<int, int> distribution;

  @override
  Widget build(BuildContext context) {
    final maxValue = distribution.values.fold<int>(0, (a, b) => a > b ? a : b);
    return _WhiteCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Treffer-Verteilung', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          for (int hits = 6; hits >= 0; hits--)
            _DistributionRow(label: '$hits Treffer', value: distribution[hits] ?? 0, maxValue: maxValue),
        ],
      ),
    );
  }
}

class _DistributionRow extends StatelessWidget {
  const _DistributionRow({required this.label, required this.value, required this.maxValue});
  final String label;
  final int value;
  final int maxValue;

  @override
  Widget build(BuildContext context) {
    final factor = maxValue <= 0 ? 0.0 : value / maxValue;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          SizedBox(width: 74, child: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: LinearProgressIndicator(value: factor, minHeight: 8, backgroundColor: const Color(0xFFEFF3FA)),
            ),
          ),
          const SizedBox(width: 10),
          SizedBox(width: 28, child: Text('$value', textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w800))),
        ],
      ),
    );
  }
}

class _TrackingEntryCard extends StatelessWidget {
  const _TrackingEntryCard({required this.entry});
  final TipTrackingEntry entry;

  @override
  Widget build(BuildContext context) {
    return _WhiteCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  entry.hitLabel,
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: entry.isWinRelevant ? const Color(0xFF0D47A1) : const Color(0xFF1F2937)),
                ),
              ),
              Text(entry.drawDateLabel, style: const TextStyle(fontSize: 12, color: Color(0xFF64748B))),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: entry.tipNumbers.map((number) => _NumberChip(number: number, matched: entry.matchedNumbers.contains(number))).toList(),
          ),
          const SizedBox(height: 10),
          Text('Ziehung: ${entry.drawNumbers.join(' - ')}', style: const TextStyle(fontSize: 12, color: Color(0xFF64748B), fontWeight: FontWeight.w600)),
          if (entry.tipSuperNumber != null || entry.drawSuperNumber != null) ...[
            const SizedBox(height: 4),
            Text('Superzahl Tipp/Ziehung: ${entry.tipSuperNumber ?? '-'} / ${entry.drawSuperNumber ?? '-'}', style: const TextStyle(fontSize: 12, color: Color(0xFF64748B), fontWeight: FontWeight.w600)),
          ],
        ],
      ),
    );
  }
}

class _NumberChip extends StatelessWidget {
  const _NumberChip({required this.number, required this.matched});
  final int number;
  final bool matched;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 34,
      height: 34,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: matched ? const Color(0xFF0D47A1) : const Color(0xFFF4F7FB),
        border: Border.all(color: matched ? const Color(0xFF0D47A1) : const Color(0xFFE1E7F0)),
      ),
      child: Text('$number', style: TextStyle(color: matched ? Colors.white : const Color(0xFF1F2937), fontWeight: FontWeight.w900)),
    );
  }
}

class _EmptyTrackingCard extends StatelessWidget {
  const _EmptyTrackingCard();

  @override
  Widget build(BuildContext context) {
    return const _WhiteCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Noch kein Verlauf', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          SizedBox(height: 8),
          Text('Speichere Tipps und wähle in „Ziehungen/Prüfung“ eine Ziehung aus. Danach baut Lotto Mind AI automatisch den Treffer-Verlauf auf.', style: TextStyle(color: Color(0xFF64748B), height: 1.35)),
        ],
      ),
    );
  }
}

class _WhiteCard extends StatelessWidget {
  const _WhiteCard({required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFE1E7F0)),
        boxShadow: const [BoxShadow(color: Color(0x0F000000), blurRadius: 14, offset: Offset(0, 8))],
      ),
      child: child,
    );
  }
}
