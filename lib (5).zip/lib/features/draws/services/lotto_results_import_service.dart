import 'dart:convert';
import 'dart:io';

import '../domain/draw_result.dart';

class LottoResultsImportService {
  static const String _lottoNetLatestUrl = 'https://www.lotto.net/german-lotto/results';
  static const String _lottosterLatestUrl = 'https://www.lottoster.com/de/lotto-6aus49/results/';

  Future<List<DrawResult>> fetchLatestResults() async {
    final urls = <String>[
      _lottosterLatestUrl,
      _lottoNetLatestUrl,
      'https://www.lottozahlenonline.de/',
      'https://www.dielottozahlende.net/lotto-6-aus-49/year',
    ];

    return _downloadAndParseFirstWorking(urls);
  }

  Future<List<DrawResult>> fetchYearResults(int year) async {
    final urls = <String>[
      // Enthält üblicherweise Lotto 6aus49 + Spiel 77 + Super 6.
      'https://www.dielottozahlende.net/lotto-6-aus-49/year/$year',
      'https://www.dielottozahlende.net/lotto-6-aus-49/year?year=$year',
      'https://www.dielottozahlende.net/lotto-6-aus-49/year',

      // Archiv-Seiten als Fallback. Je nach Seitenstand können Parameter ignoriert werden,
      // deshalb wird anschließend hart nach Jahr gefiltert.
      'https://www.lottozahlenonline.de/statistik/beide-spieltage/lottozahlen-archiv.php?j=$year',
      'https://www.lottozahlenonline.de/statistik/beide-spieltage/lottozahlen-archiv.php?jahr=$year',
      'https://www.lottozahlenonline.de/statistik/beide-spieltage/lottozahlen-archiv.php',

      // Lotto.net bleibt nur Fallback, weil die Verbindung auf manchen Geräten abbricht
      // und die Seite Spiel 77/Super 6 oft nicht mitliefert.
      'https://www.lotto.net/german-lotto/results/$year',
    ];

    final parsed = await _downloadAndParseFirstWorking(urls);
    return parsed.where((draw) => draw.drawDate.year == year).toList()
      ..sort((a, b) => b.drawDate.compareTo(a.drawDate));
  }

  Future<List<DrawResult>> _downloadAndParseFirstWorking(List<String> urls) async {
    Object? lastError;

    for (final url in urls) {
      try {
        final body = await _download(url);
        final parsed = _parseResultsFromHtml(body);
        if (parsed.isNotEmpty) return parsed;
        lastError = Exception('Keine Ziehungen in Quelle gefunden: $url');
      } catch (error) {
        lastError = error;
      }
    }

    throw Exception('Import fehlgeschlagen: $lastError');
  }

  Future<String> _download(String url) async {
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 15)
      ..idleTimeout = const Duration(seconds: 15)
      ..autoUncompress = true;

    try {
      final request = await client.getUrl(Uri.parse(url));
      request.followRedirects = true;
      request.maxRedirects = 5;
      request.headers.set(HttpHeaders.userAgentHeader,
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36');
      request.headers.set(HttpHeaders.acceptHeader,
          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8');
      request.headers.set(HttpHeaders.acceptLanguageHeader, 'de-DE,de;q=0.9,en;q=0.8');
      request.headers.set(HttpHeaders.cacheControlHeader, 'no-cache');

      final response = await request.close().timeout(const Duration(seconds: 20));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('HTTP ${response.statusCode} bei $url');
      }

      final bytes = await response.expand((chunk) => chunk).toList()
          .timeout(const Duration(seconds: 30));
      return utf8.decode(bytes, allowMalformed: true);
    } finally {
      client.close(force: true);
    }
  }

  List<DrawResult> _parseResultsFromHtml(String html) {
    final text = _htmlToPlainText(html);
    final headings = _findHeadings(text);
    final results = <DrawResult>[];

    for (var i = 0; i < headings.length; i++) {
      final heading = headings[i];
      final start = heading.end;
      final end = i + 1 < headings.length ? headings[i + 1].start : text.length;
      final block = text.substring(start, end);

      final mainNumbers = _extractMainNumbers(block);
      if (mainNumbers.length != 6) continue;

      final superNumber = _extractSuperNumber(block);
      final spiel77 = _extractSpiel77(block);
      final super6 = _extractSuper6(block);

      results.add(
        DrawResult(
          id: '${heading.drawDate.toIso8601String()}-${mainNumbers.join('-')}',
          drawDate: heading.drawDate,
          numbers: mainNumbers,
          superNumber: superNumber,
          spiel77: spiel77,
          super6: super6,
        ),
      );
    }

    final deduped = <String, DrawResult>{};
    for (final draw in results) {
      final key = '${draw.drawDate.toIso8601String()}-${draw.numbers.join('-')}';
      final old = deduped[key];
      if (old == null) {
        deduped[key] = draw;
      } else {
        deduped[key] = old.copyWith(
          superNumber: old.superNumber ?? draw.superNumber,
          spiel77: old.spiel77 ?? draw.spiel77,
          super6: old.super6 ?? draw.super6,
        );
      }
    }

    return deduped.values.toList()
      ..sort((a, b) => b.drawDate.compareTo(a.drawDate));
  }

  List<_DrawHeading> _findHeadings(String text) {
    final headings = <_DrawHeading>[];

    void addMatches(RegExp regex, DateTime? Function(RegExpMatch match) parser) {
      for (final match in regex.allMatches(text)) {
        final date = parser(match);
        if (date == null) continue;
        headings.add(_DrawHeading(match.start, match.end, date));
      }
    }

    // English: Wednesday 22 April 2026 / Wednesday, 22 April 2026
    addMatches(
      RegExp(
        r'\b(?:Wednesday|Saturday),?\s+(\d{1,2})(?:st|nd|rd|th)?\s+([A-Za-z]+)\s+(\d{4})\b',
        caseSensitive: false,
      ),
          (m) {
        final day = int.tryParse(m.group(1) ?? '');
        final month = _monthFromEnglish(m.group(2) ?? '');
        final year = int.tryParse(m.group(3) ?? '');
        if (day == null || month == null || year == null) return null;
        return DateTime(year, month, day);
      },
    );

    // English old lotto.net: Wednesday April 22nd 2026
    addMatches(
      RegExp(
        r'\b(?:Wednesday|Saturday)\s+([A-Za-z]+)\s+(\d{1,2})(?:st|nd|rd|th)?\s+(\d{4})\b',
        caseSensitive: false,
      ),
          (m) {
        final month = _monthFromEnglish(m.group(1) ?? '');
        final day = int.tryParse(m.group(2) ?? '');
        final year = int.tryParse(m.group(3) ?? '');
        if (day == null || month == null || year == null) return null;
        return DateTime(year, month, day);
      },
    );

    // German: Lotto am Samstag den 03.01.2026 / Mittwoch, 22.04.2026
    addMatches(
      RegExp(
        r'\b(?:Lotto\s+am\s+)?(?:Samstag|Mittwoch)(?:\s+den|,)?\s+(\d{1,2})\.(\d{1,2})\.(\d{4})\b',
        caseSensitive: false,
      ),
          (m) {
        final day = int.tryParse(m.group(1) ?? '');
        final month = int.tryParse(m.group(2) ?? '');
        final year = int.tryParse(m.group(3) ?? '');
        if (day == null || month == null || year == null) return null;
        return DateTime(year, month, day);
      },
    );

    headings.sort((a, b) => a.start.compareTo(b.start));

    // Duplikate aus überlappenden Regex entfernen.
    final unique = <_DrawHeading>[];
    for (final heading in headings) {
      if (unique.any((h) => h.drawDate == heading.drawDate &&
          (heading.start - h.start).abs() < 40)) {
        continue;
      }
      unique.add(heading);
    }
    return unique;
  }

  List<int> _extractMainNumbers(String block) {
    final superMarker = RegExp(
      r'\b(?:S|Super|Superzahl)\s*[:\-]?\s*\d\b',
      caseSensitive: false,
    ).firstMatch(block);

    if (superMarker != null) {
      final beforeSuper = block.substring(0, superMarker.start);
      final beforeNumbers = _validLottoNumbers(beforeSuper);
      if (beforeNumbers.length >= 6) {
        return beforeNumbers.sublist(beforeNumbers.length - 6)..sort();
      }
    }

    // Fallback für Seiten, die die 6 Zahlen direkt nach der Überschrift listen.
    final cleanBlock = block
        .replaceAll(RegExp(r'Jackpot[^\n]*', caseSensitive: false), ' ')
        .replaceAll(RegExp(r'Gewinnquote[^\n]*', caseSensitive: false), ' ')
        .replaceAll(RegExp(r'Quoten[^\n]*', caseSensitive: false), ' ')
        .replaceAll(RegExp(r'Spiel\s*77[^\n]*', caseSensitive: false), ' ')
        .replaceAll(RegExp(r'Super\s*6[^\n]*', caseSensitive: false), ' ');

    final numbers = _validLottoNumbers(cleanBlock);
    if (numbers.length >= 6) return numbers.take(6).toList()..sort();
    return const [];
  }

  List<int> _validLottoNumbers(String text) {
    return RegExp(r'\b(\d{1,2})\b')
        .allMatches(text)
        .map((m) => int.tryParse(m.group(1) ?? ''))
        .whereType<int>()
        .where((n) => n >= 1 && n <= 49)
        .toList();
  }

  int? _extractSuperNumber(String block) {
    final patterns = <RegExp>[
      RegExp(r'\bS\s*[:\-]?\s*(\d)\b', caseSensitive: false),
      RegExp(r'\bSuperzahl\s*[:\-]?\s*(\d)\b', caseSensitive: false),
      RegExp(r'\bSuper\s*[:\-]?\s*(\d)\b', caseSensitive: false),
    ];

    for (final pattern in patterns) {
      final match = pattern.firstMatch(block);
      if (match != null) return int.tryParse(match.group(1) ?? '');
    }
    return null;
  }

  String? _extractSpiel77(String block) {
    return _extractDigitGame(
      block,
      labels: const ['Spiel 77', 'Spiel77'],
      length: 7,
    );
  }

  String? _extractSuper6(String block) {
    return _extractDigitGame(
      block,
      labels: const ['Super 6', 'SUPER 6', 'Super6', 'SUPER6'],
      length: 6,
    );
  }

  String? _extractDigitGame(
      String block, {
        required List<String> labels,
        required int length,
      }) {
    for (final label in labels) {
      final labelPattern = RegExp.escape(label).replaceAll(r'\ ', r'\s*');
      final match = RegExp(
        '$labelPattern\\s*[:\\-]?\\s*([0-9](?:\\s*[0-9]){${length - 1}})',
        caseSensitive: false,
      ).firstMatch(block);

      if (match != null) {
        final digits = (match.group(1) ?? '').replaceAll(RegExp(r'\D'), '');
        if (digits.length == length) return digits;
      }
    }
    return null;
  }

  String _htmlToPlainText(String html) {
    var text = html;

    text = text.replaceAll(RegExp(r'<script[\s\S]*?</script>', caseSensitive: false), ' ');
    text = text.replaceAll(RegExp(r'<style[\s\S]*?</style>', caseSensitive: false), ' ');
    text = text.replaceAll(RegExp(r'<!--[\s\S]*?-->'), ' ');

    text = text
        .replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n')
        .replaceAll(RegExp(r'</(?:div|p|li|tr|td|th|h1|h2|h3|h4)>', caseSensitive: false), '\n')
        .replaceAll(RegExp(r'<[^>]+>'), ' ');

    return text
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&amp;', '&')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&uuml;', 'ü')
        .replaceAll('&ouml;', 'ö')
        .replaceAll('&auml;', 'ä')
        .replaceAll('&Uuml;', 'Ü')
        .replaceAll('&Ouml;', 'Ö')
        .replaceAll('&Auml;', 'Ä')
        .replaceAll('&szlig;', 'ß')
        .replaceAll(RegExp(r'[ \t]+'), ' ')
        .replaceAll(RegExp(r'\n\s*\n+'), '\n')
        .trim();
  }

  int? _monthFromEnglish(String name) {
    switch (name.toLowerCase()) {
      case 'january':
        return 1;
      case 'february':
        return 2;
      case 'march':
        return 3;
      case 'april':
        return 4;
      case 'may':
        return 5;
      case 'june':
        return 6;
      case 'july':
        return 7;
      case 'august':
        return 8;
      case 'september':
        return 9;
      case 'october':
        return 10;
      case 'november':
        return 11;
      case 'december':
        return 12;
      default:
        return null;
    }
  }
}

class _DrawHeading {
  const _DrawHeading(this.start, this.end, this.drawDate);

  final int start;
  final int end;
  final DateTime drawDate;
}

