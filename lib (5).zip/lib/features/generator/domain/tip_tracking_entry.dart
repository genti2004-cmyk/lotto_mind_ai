import '../../draws/domain/draw_result.dart';
import 'lotto_tip.dart';

class TipTrackingEntry {
  final String id;
  final String tipId;
  final String drawId;
  final DateTime checkedAt;
  final DateTime drawDate;
  final List<int> tipNumbers;
  final List<int> drawNumbers;
  final List<int> matchedNumbers;
  final int? tipSuperNumber;
  final int? drawSuperNumber;
  final String tipSource;

  const TipTrackingEntry({
    required this.id,
    required this.tipId,
    required this.drawId,
    required this.checkedAt,
    required this.drawDate,
    required this.tipNumbers,
    required this.drawNumbers,
    required this.matchedNumbers,
    required this.tipSuperNumber,
    required this.drawSuperNumber,
    required this.tipSource,
  });

  int get hitCount => matchedNumbers.length;

  bool get superHit {
    final tip = tipSuperNumber;
    final draw = drawSuperNumber;
    return tip != null && draw != null && tip == draw;
  }

  String get hitLabel {
    final main = hitCount == 1 ? '1 Treffer' : '$hitCount Treffer';
    return superHit ? '$main + Superzahl' : main;
  }

  bool get isWinRelevant => hitCount >= 3 || (hitCount == 2 && superHit);

  String get drawDateLabel {
    final d = drawDate;
    return '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')}.${d.year}';
  }

  factory TipTrackingEntry.fromTipAndDraw({
    required LottoTip tip,
    required DrawResult draw,
    required List<int> matchedNumbers,
  }) {
    final normalizedTip = List<int>.from(tip.numbers)..sort();
    final normalizedDraw = List<int>.from(draw.numbers)..sort();
    final normalizedMatched = List<int>.from(matchedNumbers)..sort();
    return TipTrackingEntry(
      id: '${tip.id}_${draw.id}',
      tipId: tip.id,
      drawId: draw.id,
      checkedAt: DateTime.now(),
      drawDate: draw.drawDate,
      tipNumbers: normalizedTip,
      drawNumbers: normalizedDraw,
      matchedNumbers: normalizedMatched,
      tipSuperNumber: tip.superNumber,
      drawSuperNumber: draw.superNumber,
      tipSource: tip.source,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'tipId': tipId,
      'drawId': drawId,
      'checkedAt': checkedAt.toIso8601String(),
      'drawDate': drawDate.toIso8601String(),
      'tipNumbers': tipNumbers,
      'drawNumbers': drawNumbers,
      'matchedNumbers': matchedNumbers,
      'tipSuperNumber': tipSuperNumber,
      'drawSuperNumber': drawSuperNumber,
      'tipSource': tipSource,
    };
  }

  factory TipTrackingEntry.fromMap(Map<dynamic, dynamic> map) {
    List<int> parseNumbers(dynamic value) {
      return (value as List? ?? const [])
          .map((e) => int.tryParse(e.toString()) ?? 0)
          .where((e) => e > 0)
          .toList()
        ..sort();
    }

    int? parseNullableInt(dynamic value) {
      final parsed = int.tryParse(value?.toString() ?? '');
      return parsed;
    }

    return TipTrackingEntry(
      id: map['id']?.toString() ?? '',
      tipId: map['tipId']?.toString() ?? '',
      drawId: map['drawId']?.toString() ?? '',
      checkedAt: DateTime.tryParse(map['checkedAt']?.toString() ?? '') ?? DateTime.now(),
      drawDate: DateTime.tryParse(map['drawDate']?.toString() ?? '') ?? DateTime.now(),
      tipNumbers: parseNumbers(map['tipNumbers']),
      drawNumbers: parseNumbers(map['drawNumbers']),
      matchedNumbers: parseNumbers(map['matchedNumbers']),
      tipSuperNumber: parseNullableInt(map['tipSuperNumber']),
      drawSuperNumber: parseNullableInt(map['drawSuperNumber']),
      tipSource: map['tipSource']?.toString() ?? 'manual',
    );
  }
}
