class SavedSystemPlay {
  const SavedSystemPlay({
    required this.id,
    required this.createdAt,
    required this.type,
    required this.numbers,
    required this.rows,
    required this.pricePerRow,
    required this.superNumber,
    required this.spiel77,
    required this.super6,
    this.lastCheckedDrawId,
    this.lastCheckedAt,
    this.bestHits,
    this.winningRows,
    this.spiel77Matches,
    this.super6Matches,
  });

  final String id;
  final DateTime createdAt;
  final String type; // normal / full / vew
  final List<int> numbers;
  final List<List<int>> rows;
  final double pricePerRow;
  final int superNumber;
  final String spiel77;
  final String super6;

  final String? lastCheckedDrawId;
  final DateTime? lastCheckedAt;
  final int? bestHits;
  final int? winningRows;
  final int? spiel77Matches;
  final int? super6Matches;

  int get rowCount => rows.length;
  double get totalPrice => rowCount * pricePerRow;

  String get typeLabel {
    switch (type) {
      case 'normal':
        return 'Normalschein';
      case 'full':
        return 'Vollsystem';
      case 'vew':
        return 'VEW-System';
      default:
        return type;
    }
  }

  SavedSystemPlay copyWith({
    String? lastCheckedDrawId,
    DateTime? lastCheckedAt,
    int? bestHits,
    int? winningRows,
    int? spiel77Matches,
    int? super6Matches,
  }) {
    return SavedSystemPlay(
      id: id,
      createdAt: createdAt,
      type: type,
      numbers: numbers,
      rows: rows,
      pricePerRow: pricePerRow,
      superNumber: superNumber,
      spiel77: spiel77,
      super6: super6,
      lastCheckedDrawId: lastCheckedDrawId ?? this.lastCheckedDrawId,
      lastCheckedAt: lastCheckedAt ?? this.lastCheckedAt,
      bestHits: bestHits ?? this.bestHits,
      winningRows: winningRows ?? this.winningRows,
      spiel77Matches: spiel77Matches ?? this.spiel77Matches,
      super6Matches: super6Matches ?? this.super6Matches,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'createdAt': createdAt.toIso8601String(),
      'type': type,
      'numbers': numbers,
      'rows': rows,
      'pricePerRow': pricePerRow,
      'superNumber': superNumber,
      'spiel77': spiel77,
      'super6': super6,
      'lastCheckedDrawId': lastCheckedDrawId,
      'lastCheckedAt': lastCheckedAt?.toIso8601String(),
      'bestHits': bestHits,
      'winningRows': winningRows,
      'spiel77Matches': spiel77Matches,
      'super6Matches': super6Matches,
    };
  }

  factory SavedSystemPlay.fromMap(Map<dynamic, dynamic> map) {
    List<int> parseInts(dynamic value) {
      return (value as List? ?? const [])
          .map((e) => int.tryParse(e.toString()) ?? 0)
          .where((e) => e > 0)
          .toList()
        ..sort();
    }

    List<List<int>> parseRows(dynamic value) {
      return (value as List? ?? const [])
          .map((row) => parseInts(row))
          .where((row) => row.length == 6)
          .toList();
    }

    int? parseNullableInt(dynamic value) => int.tryParse(value?.toString() ?? '');

    return SavedSystemPlay(
      id: map['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
      createdAt: DateTime.tryParse(map['createdAt']?.toString() ?? '') ?? DateTime.now(),
      type: map['type']?.toString() ?? 'normal',
      numbers: parseInts(map['numbers']),
      rows: parseRows(map['rows']),
      pricePerRow: double.tryParse(map['pricePerRow']?.toString() ?? '') ?? 1.20,
      superNumber: int.tryParse(map['superNumber']?.toString() ?? '') ?? 0,
      spiel77: map['spiel77']?.toString() ?? '',
      super6: map['super6']?.toString() ?? '',
      lastCheckedDrawId: map['lastCheckedDrawId']?.toString(),
      lastCheckedAt: DateTime.tryParse(map['lastCheckedAt']?.toString() ?? ''),
      bestHits: parseNullableInt(map['bestHits']),
      winningRows: parseNullableInt(map['winningRows']),
      spiel77Matches: parseNullableInt(map['spiel77Matches']),
      super6Matches: parseNullableInt(map['super6Matches']),
    );
  }
}
