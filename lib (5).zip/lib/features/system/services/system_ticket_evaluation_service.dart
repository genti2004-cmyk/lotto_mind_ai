import 'dart:math';

import 'package:lotto_mind_ai/features/draws/domain/draw_result.dart';

class SystemTicketEvaluationService {
  const SystemTicketEvaluationService();

  static const int fullMaxNumbers = 10;
  static const int vewMaxNumbers = 12;

  List<List<int>> buildRows({
    required String type,
    required List<int> numbers,
  }) {
    final normalized = _normalize(numbers);
    if (type == 'normal') {
      return normalized.length == 6 ? [normalized] : const [];
    }
    if (type == 'full') {
      if (normalized.length < 6 || normalized.length > fullMaxNumbers) return const [];
      return _combinations(normalized, 6);
    }
    if (type == 'vew') {
      if (normalized.length < 6 || normalized.length > vewMaxNumbers) return const [];
      return _buildVewRows(normalized);
    }
    return const [];
  }

  SystemTicketEvaluation evaluate({
    required List<List<int>> rows,
    required DrawResult draw,
    required int superNumber,
    required String spiel77,
    required String super6,
  }) {
    final drawNumbers = draw.numbers.toSet();
    final drawSuper = draw.superNumber;
    final classCounts = <String, int>{};
    var bestHits = 0;
    var winningRows = 0;

    for (final row in rows) {
      final hits = row.where(drawNumbers.contains).length;
      bestHits = max(bestHits, hits);
      final superHit = drawSuper != null && superNumber == drawSuper;
      final label = _prizeClass(hits, superHit);
      if (label != null) {
        winningRows++;
        classCounts[label] = (classCounts[label] ?? 0) + 1;
      }
    }

    final s77 = _matchingTrailingDigits(spiel77, draw.spiel77 ?? '', expectedLength: 7);
    final s6 = _matchingTrailingDigits(super6, draw.super6 ?? '', expectedLength: 6);

    return SystemTicketEvaluation(
      rowsChecked: rows.length,
      winningRows: winningRows,
      bestHits: bestHits,
      classCounts: classCounts,
      spiel77Matches: s77,
      super6Matches: s6,
      spiel77Label: _optionalLabel('Spiel 77', s77, 7),
      super6Label: _optionalLabel('Super 6', s6, 6),
    );
  }

  String? _prizeClass(int hits, bool superHit) {
    if (hits == 6 && superHit) return 'GK 1: 6 + SZ';
    if (hits == 6) return 'GK 2: 6 Richtige';
    if (hits == 5 && superHit) return 'GK 3: 5 + SZ';
    if (hits == 5) return 'GK 4: 5 Richtige';
    if (hits == 4 && superHit) return 'GK 5: 4 + SZ';
    if (hits == 4) return 'GK 6: 4 Richtige';
    if (hits == 3 && superHit) return 'GK 7: 3 + SZ';
    if (hits == 3) return 'GK 8: 3 Richtige';
    if (hits == 2 && superHit) return 'GK 9: 2 + SZ';
    return null;
  }

  String _optionalLabel(String name, int matches, int max) {
    if (matches <= 0) return '$name: kein Treffer';
    if (matches >= max) return '$name: alle $max Endziffern richtig';
    return '$name: $matches Endziffer${matches == 1 ? '' : 'n'} richtig';
  }

  int _matchingTrailingDigits(String selected, String drawn, {required int expectedLength}) {
    final a = _digitsOnly(selected);
    final b = _digitsOnly(drawn);
    if (a.isEmpty || b.isEmpty) return 0;
    final left = a.padLeft(expectedLength, '0');
    final right = b.padLeft(expectedLength, '0');

    var matches = 0;
    for (var i = 1; i <= expectedLength; i++) {
      if (left[left.length - i] == right[right.length - i]) {
        matches++;
      } else {
        break;
      }
    }
    return matches;
  }

  List<int> _normalize(List<int> numbers) {
    return numbers.where((n) => n >= 1 && n <= 49).toSet().toList()..sort();
  }

  List<List<int>> _combinations(List<int> numbers, int k) {
    final result = <List<int>>[];

    void build(int start, List<int> current) {
      if (current.length == k) {
        result.add(List<int>.from(current)..sort());
        return;
      }
      for (var i = start; i < numbers.length; i++) {
        current.add(numbers[i]);
        build(i + 1, current);
        current.removeLast();
      }
    }

    build(0, <int>[]);
    return result;
  }

  List<List<int>> _buildVewRows(List<int> numbers) {
    final allRows = _combinations(numbers, 6);
    final target = _vewTargetRows(numbers.length);
    if (allRows.length <= target) return allRows;

    final scored = allRows
        .map((row) => _ScoredRow(row: row, score: _scoreRow(row, numbers)))
        .toList()
      ..sort((a, b) {
        final byScore = b.score.compareTo(a.score);
        if (byScore != 0) return byScore;
        return a.row.join('-').compareTo(b.row.join('-'));
      });

    final selected = <List<int>>[];
    final coverage = <int, int>{for (final n in numbers) n: 0};

    for (final item in scored) {
      if (selected.length >= target) break;
      final newCoverage = item.row.where((n) => coverage[n] == 0).length;
      if (selected.length < numbers.length ~/ 2 || newCoverage > 0) {
        selected.add(item.row);
        for (final n in item.row) {
          coverage[n] = (coverage[n] ?? 0) + 1;
        }
      }
    }

    for (final item in scored) {
      if (selected.length >= target) break;
      if (!selected.any((row) => row.join('-') == item.row.join('-'))) {
        selected.add(item.row);
      }
    }

    return selected..sort((a, b) => a.join('-').compareTo(b.join('-')));
  }

  int _vewTargetRows(int selectedCount) {
    switch (selectedCount) {
      case 6:
        return 1;
      case 7:
        return 3;
      case 8:
        return 4;
      case 9:
        return 5;
      case 10:
        return 6;
      case 11:
        return 8;
      case 12:
        return 10;
      default:
        return max(1, selectedCount - 4);
    }
  }

  double _scoreRow(List<int> row, List<int> pool) {
    final sum = row.fold<int>(0, (a, b) => a + b);
    final odd = row.where((n) => n.isOdd).length;
    final low = row.where((n) => n <= 24).length;
    final spread = row.last - row.first;
    final centerBias = row.map((n) => (25 - n).abs()).fold<int>(0, (a, b) => a + b);

    var score = 0.0;
    if (odd >= 2 && odd <= 4) score += 3;
    if (low >= 2 && low <= 4) score += 3;
    if (spread >= 18) score += 2;
    if (sum >= 90 && sum <= 180) score += 3;
    score += max(0, 30 - centerBias) * 0.05;

    final poolMiddle = pool[pool.length ~/ 2];
    final avg = row.reduce((a, b) => a + b) / row.length;
    score += 5.0 - (avg - poolMiddle).abs() * 0.1;
    return score;
  }

  String _digitsOnly(String value) => value.replaceAll(RegExp(r'[^0-9]'), '');
}

class SystemTicketEvaluation {
  const SystemTicketEvaluation({
    required this.rowsChecked,
    required this.winningRows,
    required this.bestHits,
    required this.classCounts,
    required this.spiel77Matches,
    required this.super6Matches,
    required this.spiel77Label,
    required this.super6Label,
  });

  final int rowsChecked;
  final int winningRows;
  final int bestHits;
  final Map<String, int> classCounts;
  final int spiel77Matches;
  final int super6Matches;
  final String spiel77Label;
  final String super6Label;

  bool get hasAnyWin => winningRows > 0 || spiel77Matches > 0 || super6Matches > 0;
}

class _ScoredRow {
  const _ScoredRow({required this.row, required this.score});
  final List<int> row;
  final double score;
}
